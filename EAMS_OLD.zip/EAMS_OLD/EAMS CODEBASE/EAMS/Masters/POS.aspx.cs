﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;
using WebApplication1;

public partial class Group : System.Web.UI.Page
{
    Workshop _ws;
    SP.ClientContext ctx;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        ctx = _ws.getClientContext();
        if (!Page.IsPostBack)
        {
            BindData();
        }

    }

    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.Trim().ToUpper())
        {
            //case "EDIT":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            //case "VIEW":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            case "ADD":
                AddRecord();
                break;


            case "CANCEL":
                gvGroup.EditIndex = -1;
                BindData();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("DelFlag", "0");
        ////DataTable gridRequest = _ws.getListAsGrid(givelistName: "SiteSectorHead", columns: new List<string>() { "ID", "Title", "Segment", "Sector", "SiteSectorHead" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        DataTable gridRequest = _ws.getListAsGridMultiUser(givelistName: "POS Master", columns: new List<string>() { "ID", "Segment", "Sector", "DelFlag", "POSManager", "POSHead" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        ////Title = POS Role, POSMaster = POS Master, DelFlag = DelFlag, POSManager = POS Manager, POSHead = POS Head
        if (Session["Group"] == null)
            SessionUtility.AddSessionValue(key: "Group", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "Group", value: gridRequest);
        gvGroup.DataSource = gridRequest;
        gvGroup.DataBind();
    }

    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }

    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string listName1 = "Segment";
        string keyColumnName1 = "ID";
        string valueColumnName1 = "Title";

        if (e.Row.RowType == DataControlRowType.DataRow && gvGroup.EditIndex == e.Row.RowIndex)
        {
            Label lblSegment = (Label)e.Row.FindControl("lblSegment");
            DropDownList ddlSegment = (DropDownList)e.Row.FindControl("ddlSegment");
            ddlSegment.DataSource = fillDropDown(_ws, listName1, keyColumnName1, valueColumnName1);
            ddlSegment.DataTextField = "Value";
            ddlSegment.DataValueField = "Key";
            ddlSegment.DataBind();

            if (lblSegment.Text.Trim() != "")//Added
            {
                ddlSegment.Items.FindByText(lblSegment.Text).Selected = true;
            }


            Label lblSector = (Label)e.Row.FindControl("lblSector");
            DropDownList ddlSector = (DropDownList)e.Row.FindControl("ddlSector");
            ddlSector.DataSource = fillDropDown(_ws, "Sector", "ID", "Title");
            ddlSector.DataTextField = "Value";
            ddlSector.DataValueField = "Key";
            ddlSector.DataBind();

            if (lblSector.Text.Trim() != "")//Added
            {
                ddlSector.Items.FindByText(lblSector.Text).Selected = true;
            }


            //Label lblSite = (Label)e.Row.FindControl("lblSite");
            //DropDownList ddlSite = (DropDownList)e.Row.FindControl("ddlSite");
            //ddlSite.DataSource = fillDropDown(_ws, "Site", "ID", "Title");
            //ddlSite.DataTextField = "Value";
            //ddlSite.DataValueField = "Key";
            //ddlSite.DataBind();
            //ddlSite.Items.FindByText(lblSite.Text).Selected = true;
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            DropDownList ddlSegment = (DropDownList)e.Row.FindControl("ddlSegment");
            ddlSegment.DataSource = fillDropDown(_ws, listName1, keyColumnName1, valueColumnName1);
            ddlSegment.DataTextField = "Value";
            ddlSegment.DataValueField = "Key";
            ddlSegment.DataBind();


            //DropDownList ddlSite = (DropDownList)e.Row.FindControl("ddlSite");
            //ddlSite.DataSource = fillDropDown(_ws, "Site", "ID", "Title");
            //ddlSite.DataTextField = "Value";
            //ddlSite.DataValueField = "Key";
            //ddlSite.DataBind();
        }
    }

    protected void ddlSegment_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        DropDownList ddlSegment = (DropDownList)sender;
        GridViewRow row = (GridViewRow)ddlSegment.NamingContainer;
        if (row != null)
        {
            DropDownList ddlSector = (DropDownList)row.FindControl("ddlSector");
            ddlSector.Items.Clear();
            string segmentId = ddlSegment.SelectedValue;
            ddlSector.Populateddl(ws: _ws, listName: "Sector", keyColumnName: "ID", valueColumnName: "Title", columnType: "Lookup", filter: new KeyValuePair<string, string>("Segment", segmentId));
        }
    }


    public void AddRecord()
    {
        string segment = ((DropDownList)gvGroup.FooterRow.FindControl("ddlSegment")).SelectedItem.ToString();
        string sector = ((DropDownList)gvGroup.FooterRow.FindControl("ddlSector")).SelectedItem.ToString();
        ////string site = ((DropDownList)gvGroup.FooterRow.FindControl("ddlSite")).SelectedItem.ToString();
        ////string siteSectorHead = ((TextBox)gvGroup.FooterRow.FindControl("txtSiteSectorHead")).Text;
        string POSManager = ((TextBox)gvGroup.FooterRow.FindControl("txtPOSManager")).Text;

        //--------------------------------------------  Add Multiple User -----------------------------------------------------------

        //SP.UserCollection userCollection = new SP.UserCollection();

        //SP.FieldUserValue

        //SP.SPFieldUserValueCollection usercollection = new SPFieldUserValueCollection();
        //string[] userarray = usercontrolvalue.Split(',');
        //for (int i = 0; i < userarray.Length; i++)
        //{
        //    SPFieldUserValue usertoadd = ConvertLoginName(userarray[i]);
        //    usercollection.Add(usertoadd);
        //}

        //------------------------------------------  End Here -------------------------------------------------------------

        string POSHead = ((TextBox)gvGroup.FooterRow.FindControl("txtPOSHead")).Text;
        SP.List list = ctx.Web.Lists.GetByTitle("POS Master");
        SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
        SP.ListItem listItem = list.AddItem(itemCreateInfo);
        ////listItem["Title"] = site;
        listItem["Segment"] = segment;
        listItem["Sector"] = sector;
        //listItem["SiteSectorHead"] = _ws.GetUser(siteSectorHead).Id;
        listItem["POSManager"] = _ws.GetUser(POSManager).Id;
        //listItem["POSManager"] = "dipak.d.kachhaway";
        listItem["POSHead"] = _ws.GetUser(POSHead).Id;
        listItem["DelFlag"] = "0";
        listItem.Update();
        _ws.executeClientContext(ctx);
        BindData();
    }

    protected void gvGroup_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        DropDownList ddlSegment = (DropDownList)gvGroup.Rows[e.RowIndex].FindControl("ddlSegment");
        DropDownList ddlSector = (DropDownList)gvGroup.Rows[e.RowIndex].FindControl("ddlSector");
        ////DropDownList ddlSite = (DropDownList)gvGroup.Rows[e.RowIndex].FindControl("ddlSite");
        ////TextBox txtSiteSectorHead = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtSiteSectorHead");
        TextBox txtPOSHead = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtPOSHead");
        TextBox txtPOSManager = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtPOSManager");
        //UpdateRecord(itemID: recordID, site: ddlSite.SelectedItem.ToString(), sector: ddlSector.SelectedItem.ToString(), segment: ddlSegment.SelectedItem.ToString(), SiteSectorHead: txtSiteSectorHead.Text);
        UpdateRecord(itemID: recordID, sector: ddlSector.SelectedItem.ToString(), segment: ddlSegment.SelectedItem.ToString(), POSManager: txtPOSManager.Text, POSHead: txtPOSHead.Text);
    }
    protected void gvGroup_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGroup.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        DeleteRecord(itemID: recordID);
    }
    protected void gvGroup_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvGroup.EditIndex = -1;
        BindData();
    }

    /// <summary>
    /// /
    /// </summary>
    /// <param name="itemID"></param>
    /// <param name="site"></param>
    /// <param name="sector"></param>
    /// <param name="segment"></param>
    /// <param name="SiteSectorHead"></param>
    ////public void UpdateRecord(string itemID, string site, string sector, string segment, string SiteSectorHead)
    /*{
        SP.List list = ctx.Web.Lists.GetByTitle("POS Master");
        SP.ListItem item = list.GetItemById(itemID);
        ctx.Load(item);
        item["Title"] = site;
        item["Segment"] = segment;
        item["Sector"] = sector;
        item["SiteSectorHead"] = _ws.GetUser(SiteSectorHead).Id;
        item["DelFlag"] = "0";
        item.Update();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }*/
    public void UpdateRecord(string itemID, string sector, string segment, string POSManager, string POSHead)
    {
        try
        {
            SP.List list = ctx.Web.Lists.GetByTitle("POS Master");
            SP.ListItem item = list.GetItemById(itemID);
            ctx.Load(item);

            item["Sector"] = sector;
            item["Segment"] = segment;
            item["POSHead"] = _ws.GetUser(POSHead).Id;

            List<FieldUserValue> usersList = new List<FieldUserValue>();

            string[] POSManagers = POSManager.Split(';').ToArray();
            string posManagers = string.Empty;
            foreach (string manager in POSManagers)
            {
                posManagers = _ws.GetUser(manager).LoginName;
                usersList.Add(FieldUserValue.FromUser(posManagers));
            }

            item["POSManager"] = usersList;
            item["DelFlag"] = "0";
            item.Update();
            _ws.executeClientContext(ctx);
            gvGroup.EditIndex = -1;
            BindData();
        }
        catch (Exception ex)
        {
            _ws.LogError("List Name:-POS Master;", "Error Msg:-" + ex.Message);
        }
    }
    public void DeleteRecord(string itemID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("POS Master");
        SP.ListItem item = list.GetItemById(itemID);
        item.DeleteObject();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }
    public object fillDropDown(Workshop ws, string listName, string keyColumnName, string valueColumnName)
    {
        var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionary(listName, keyColumnName, valueColumnName)
                       select new
                       {
                           Key = ddlRow.Key,
                           Value = ddlRow.Value
                       });
        return ddlData;
    }

}