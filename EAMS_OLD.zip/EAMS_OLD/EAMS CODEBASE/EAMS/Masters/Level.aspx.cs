﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using WebApplication1;

public partial class Level : System.Web.UI.Page
{
    Workshop _ws;
    SP.ClientContext ctx;
    int countRow = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        ctx = _ws.getClientContext();
        if (!Page.IsPostBack)
        {
            BindData();
        }

    }

    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.Trim().ToUpper())
        {
            //case "EDIT":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            //case "VIEW":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            case "ADD":
                AddRecord();
                break;


            case "CANCEL":
                gvGroup.EditIndex = -1;
                BindData();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        //filters.Add("DelFlag", "0");
        //, filterColumnType: new List<string>() { "Text" }, filters: filters
        //DataTable gridRequest = _ws.getListAsGrid(givelistName: "Group", columns: new List<string>() { "ID", "Title", "GrpSegment", "GrpSector", "FunctionCOEHead" });
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExtWFLevel", columns: new List<string>() { "ID", "Title", "Level", "LevelName" }, filterColumnType: new List<string>() { }, filters: filters);
        if (Session["ExtWFLevel"] == null)
            SessionUtility.AddSessionValue(key: "Group", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "Group", value: gridRequest);
        gvGroup.DataSource = gridRequest;
        gvGroup.DataBind();
    }

    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }

    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            countRow = countRow + 1;
            ViewState["State"] = countRow;
        }
    }

    public void AddRecord()
    {
        string State = ((TextBox)gvGroup.FooterRow.FindControl("txtState")).Text;
        string Level = ((TextBox)gvGroup.FooterRow.FindControl("txtLevel")).Text;
        string LevelName = ((TextBox)gvGroup.FooterRow.FindControl("txtLevelName")).Text;
        SP.List list = ctx.Web.Lists.GetByTitle("ExtWFLevel");
        SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
        SP.ListItem listItem = list.AddItem(itemCreateInfo);
        listItem["Title"] = ViewState["State"].ToString();
        listItem["Level"] = Level;
        listItem["LevelName"] = LevelName;
        listItem.Update();
        _ws.executeClientContext(ctx);
        BindData();
    }

    protected void gvGroup_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();

        TextBox txtState = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtState");
        TextBox txtLevel = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtLevel");
        TextBox txtLevelName = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtLevelName");

        UpdateRecord(itemID: recordID, Title: Convert.ToString(txtState.Text), Level: txtLevel.Text, LevelName: txtLevelName.Text);
    }
    protected void gvGroup_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGroup.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        DeleteRecord(itemID: recordID);
    }
    protected void gvGroup_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvGroup.EditIndex = -1;
        BindData();
    }

    public void UpdateRecord(string itemID, string Title, string Level, string LevelName)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("ExtWFLevel");
        SP.ListItem item = list.GetItemById(itemID);
        ctx.Load(item);
        item["Title"] = ViewState["State"].ToString();
        item["Level"] = Level;
        item["LevelName"] = LevelName;
        item.Update();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }
    public void DeleteRecord(string itemID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("ExtWFLevel");
        SP.ListItem item = list.GetItemById(itemID);
        item.DeleteObject();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }
}