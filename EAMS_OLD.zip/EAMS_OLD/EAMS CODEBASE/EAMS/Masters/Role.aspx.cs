﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using WebApplication1;

public partial class Role : System.Web.UI.Page
{
    Workshop _ws;
    SP.ClientContext ctx;
    ADService _ad;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        _ad = new ADService();
        ctx = _ws.getClientContext();
        if (!Page.IsPostBack)
        {
            BindData();
        }

    }

    protected void gvGrade_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.Trim().ToUpper())
        {

            case "ADD":
                AddRecord();
                break;


            case "CANCEL":
                gvGrade.EditIndex = -1;
                BindData();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExtRoleList", columns: new List<string>() { "ID", "Title", "RoleOwner", "RoleID","Active" }, filterColumnType: new List<string>() { }, filters: filters);
        gvGrade.DataSource = gridRequest;
        gvGrade.DataBind();
    }

    protected void gvGrade_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGrade.PageIndex = e.NewPageIndex;
        BindData();
    }

    protected void gvGrade_RowDataBound(object sender, GridViewRowEventArgs e)
    {
    }

    public void AddRecord()
    {
        try
        {
            int? user = null;
            string txtRole = ((TextBox)gvGrade.FooterRow.FindControl("txtRole")).Text;
            string txtRoleOwner = ((TextBox)gvGrade.FooterRow.FindControl("txtRoleOwner")).Text;
            string ddlActive = ((DropDownList)gvGrade.FooterRow.FindControl("ddlActive")).SelectedItem.ToString();

            if (!string.IsNullOrEmpty(txtRoleOwner))
            {
                string[] EmployeeSet = (Session["EmployeeSet"] != null ? (string[])Session["EmployeeSet"] : null);
                string empDomainName = (from name in EmployeeSet where name.Contains(txtRoleOwner) select name).FirstOrDefault<string>();

                SP.List list = ctx.Web.Lists.GetByTitle(empDomainName);
                SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
                SP.ListItem listItem = list.AddItem(itemCreateInfo);
                listItem["Title"] = txtRole;
                listItem["RoleOwner"] = (_ws.GetUser(txtRoleOwner).Id > 0 ? user : _ws.GetUser(txtRoleOwner).Id);
                listItem["UserID"] = _ws.GetUser(empDomainName).Id.ToString();
                listItem["Active"] = ddlActive;
                listItem.Update();
                _ws.executeClientContext(ctx);
                BindData();
            }
        }
        catch (Exception)
        {
            gvGrade.EditIndex = -1;
            BindData();
        }
    }

    protected void gvGrade_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            string recordID = gvGrade.DataKeys[e.RowIndex].Value.ToString();
            TextBox txtRole = (TextBox)gvGrade.Rows[e.RowIndex].FindControl("txtRole");
            TextBox txtRoleOwner = (TextBox)gvGrade.Rows[e.RowIndex].FindControl("txtRoleOwner");
            DropDownList ddlActive = (DropDownList)gvGrade.Rows[e.RowIndex].FindControl("ddlActive");
            if (!string.IsNullOrEmpty(txtRoleOwner.Text))
            {
                string[] EmployeeSet = (Session["EmployeeSet"] != null ? (string[])Session["EmployeeSet"] : null);
                string empDomainName = (from name in EmployeeSet where name.Contains(txtRoleOwner.Text) select name).FirstOrDefault<string>();
                int roleOwner = _ws.GetUser(empDomainName.Substring(0, empDomainName.IndexOf("["))).Id;
                UpdateRecord(itemID: recordID, role: txtRole.Text, roleOwner: _ws.GetUser(empDomainName.Substring(0, empDomainName.IndexOf("["))).Id, empDomainName: empDomainName.Substring(0, empDomainName.IndexOf("[")),active:ddlActive.SelectedItem.ToString());
            }
        }
        catch (Exception)
        {
            gvGrade.EditIndex = -1;
            BindData();
        }
    }
    protected void gvGrade_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGrade.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvGrade_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //string recordID = gvGrade.DataKeys[e.RowIndex].Value.ToString();
        //DeleteRecord(itemID: recordID);
    }
    protected void gvGrade_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvGrade.EditIndex = -1;
        BindData();
    }

    public void UpdateRecord(string itemID, string role, int roleOwner, string empDomainName, string active)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("ExtRoleList");
        SP.ListItem item = list.GetItemById(itemID);
        ctx.Load(item);
        item["Title"] = role;
        item["RoleOwner"] = roleOwner;
        item["UserID"] = _ws.GetUser(empDomainName).Id.ToString();
        item["Active"] = active;
        item.Update();
        _ws.executeClientContext(ctx);
        gvGrade.EditIndex = -1;
        BindData();
    }
    public void DeleteRecord(string itemID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("ExtRoleList");
        SP.ListItem item = list.GetItemById(itemID);
        item.DeleteObject();
        _ws.executeClientContext(ctx);
        gvGrade.EditIndex = -1;
        BindData();
    }


}