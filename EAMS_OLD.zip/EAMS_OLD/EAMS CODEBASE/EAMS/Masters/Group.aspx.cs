﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using WebApplication1;

public partial class Group : System.Web.UI.Page
{
    Workshop _ws;
    SP.ClientContext ctx;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        ctx = _ws.getClientContext();
        if(!Page.IsPostBack)
        {
            BindData();
        }
       
    }

    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {       
        switch (e.CommandName.Trim().ToUpper())
        {
            //case "EDIT":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            //case "VIEW":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            case "ADD":
                AddRecord();
                break;


            case "CANCEL":
                 gvGroup.EditIndex = -1;
                    BindData();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("DelFlag", "0");
        //, filterColumnType: new List<string>() { "Text" }, filters: filters
        //DataTable gridRequest = _ws.getListAsGrid(givelistName: "Group", columns: new List<string>() { "ID", "Title", "GrpSegment", "GrpSector", "FunctionCOEHead" });
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "Group", columns: new List<string>() { "ID", "Title", "GrpSegment", "Sector", "FunctionCOEHead" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        if (Session["Group"] == null)
            SessionUtility.AddSessionValue(key: "Group", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "Group", value: gridRequest);        
        gvGroup.DataSource = gridRequest;
        gvGroup.DataBind();
    }

    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }

    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string listName1 = "Segment";
        string keyColumnName1 = "ID";
        string valueColumnName1 = "Title";
       // string listName2 = "Sector";
        //string keyColumnName2 = "ID";
       // string valueColumnName2 = "Title";

        if (e.Row.RowType == DataControlRowType.DataRow && gvGroup.EditIndex == e.Row.RowIndex)
        {
            Label lblSegment = (Label)e.Row.FindControl("lblSegment");
            DropDownList ddlSegment = (DropDownList)e.Row.FindControl("ddlSegment");
            ddlSegment.DataSource = fillDropDown(_ws, listName1, keyColumnName1, valueColumnName1);
            ddlSegment.DataTextField = "Value";
            ddlSegment.DataValueField = "Key";
            ddlSegment.DataBind();
            ddlSegment.Items.FindByText(lblSegment.Text).Selected = true;

            //Label lblSector = (Label)e.Row.FindControl("lblSector");
            //DropDownList ddlSector = (DropDownList)e.Row.FindControl("ddlSector");
            //ddlSector.DataSource = fillDropDown(_ws, listName2, keyColumnName2, valueColumnName2);
            //ddlSector.DataTextField = "Value";
            //ddlSector.DataValueField = "Key";
            //ddlSector.DataBind();
            //ddlSector.Items.FindByText(lblSector.Text).Selected = true;
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            DropDownList ddlSegment = (DropDownList)e.Row.FindControl("ddlSegment");
            ddlSegment.DataSource = fillDropDown(_ws, listName1, keyColumnName1, valueColumnName1);
            ddlSegment.DataTextField = "Value";
            ddlSegment.DataValueField = "Key";
            ddlSegment.DataBind();

            //DropDownList ddlsector = (DropDownList)e.Row.FindControl("ddlSector");
            //ddlsector.DataSource = fillDropDown(_ws, listName2, keyColumnName2, valueColumnName2);
            //ddlsector.DataTextField = "Value";
            //ddlsector.DataValueField = "Key";
            //ddlsector.DataBind();
        }
    }

    protected void  ddlSegment_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        DropDownList ddlSegment = (DropDownList)sender;
        GridViewRow row = (GridViewRow)ddlSegment.NamingContainer;
        if (row != null)
        {
            DropDownList ddlSector = (DropDownList)row.FindControl("ddlSector");
            ddlSector.Items.Clear();
            string segmentId = ddlSegment.SelectedValue;
            ddlSector.Populateddl(ws: _ws, listName: "Sector", keyColumnName: "ID", valueColumnName: "Title", columnType: "Lookup", filter: new KeyValuePair<string, string>("Segment", segmentId));
        }
    }


    public void AddRecord()
    {
        string group = ((TextBox)gvGroup.FooterRow.FindControl("txtgroup")).Text;
        string segment = ((DropDownList)gvGroup.FooterRow.FindControl("ddlSegment")).SelectedValue.ToString();
        string sector = ((DropDownList)gvGroup.FooterRow.FindControl("ddlSector")).SelectedValue.ToString();
        string coeHead = ((TextBox)gvGroup.FooterRow.FindControl("txtCOEHead")).Text;
        SP.List list = ctx.Web.Lists.GetByTitle("Group");
        SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
        SP.ListItem listItem = list.AddItem(itemCreateInfo);
        listItem["Title"] = group;
        listItem["GrpSegment"] = segment;
        listItem["Sector"] = sector;
        listItem["FunctionCOEHead"] = _ws.GetUser(coeHead).Id;
        listItem["DelFlag"] = "0";
        listItem.Update();
        _ws.executeClientContext(ctx);
        BindData();
    }

    protected void gvGroup_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        TextBox txtGroup = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtgroup");
        DropDownList ddlSegment = (DropDownList)gvGroup.Rows[e.RowIndex].FindControl("ddlSegment");
        DropDownList ddlSector = (DropDownList)gvGroup.Rows[e.RowIndex].FindControl("ddlSector");
        TextBox txtcoeHead = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtCOEHead");
        UpdateRecord(itemID: recordID,group:txtGroup.Text, sector: ddlSector.Text, segment: ddlSegment.SelectedValue.ToString(), coeHead: txtcoeHead.Text);
    }
    protected void gvGroup_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGroup.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        DeleteRecord(itemID: recordID);
    }
    protected void gvGroup_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvGroup.EditIndex = -1;
        BindData();
    }

    public void UpdateRecord(string itemID,string group,string sector,string segment,string coeHead)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("Group");
        SP.ListItem item = list.GetItemById(itemID);
        ctx.Load(item);
        item["Title"] = group;
        item["GrpSegment"] = segment;
        item["Sector"] = sector;
        item["FunctionCOEHead"] = _ws.GetUser(coeHead).Id;
        item["DelFlag"] = "0";
        item.Update();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }
    public void DeleteRecord(string itemID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("Group");
        SP.ListItem item = list.GetItemById(itemID);
        item.DeleteObject();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }
    public object fillDropDown( Workshop ws, string listName, string keyColumnName, string valueColumnName)
    {
        var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionary(listName, keyColumnName, valueColumnName)
                       select new
                       {
                           Key = ddlRow.Key,
                           Value = ddlRow.Value
                       });
        return ddlData;
    }

}