﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;

public partial class CIPT : System.Web.UI.Page
{
    Workshop _ws;
    ADService service;
    SP.ClientContext ctx;
    int ciptGroup = int.Parse(WebConfigurationManager.AppSettings["CIPTGroup"]);

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        ctx = _ws.getClientContext();
        if (!Page.IsPostBack)
        {
            BindData();
        }
    }

    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.Trim().ToUpper())
        {
            case "ADD":
                AddRecord();
                break;

            case "CANCEL":
                gvGroup.EditIndex = -1;
                BindData();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("DelFlag", "0");
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "CIPT", columns: new List<string>() { "ID", "CIPT", "Title", "DomainID", "Email" }, filterColumnType: new List<string>() { "Text" }, filters: filters);

        string output = string.Empty;
        for (int i = 0; i < gridRequest.Rows.Count; i++)
        {
            output = output + gridRequest.Rows[i]["Email"].ToString();
            output += (i < gridRequest.Rows.Count) ? ";" : string.Empty;
        }

        Session["User"] = output;

        if (Session["CIPT"] == null)
            SessionUtility.AddSessionValue(key: "CIPT", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "CIPT", value: gridRequest);
        gvGroup.DataSource = gridRequest;
        gvGroup.DataBind();
    }

    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }

    /// <summary>
    /// Method to delete Item/Record
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("CIPT", int.Parse(Session["_itemID"].ToString()));
        BindData();
    }

    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
        }
    }

    public void AddRecord()
    {
        string DomainID = ((Label)gvGroup.FooterRow.FindControl("lblDomainID")).Text;
        string CIPTID = ((Label)gvGroup.FooterRow.FindControl("lblCIPTID")).Text;
        string cipt = ((TextBox)gvGroup.FooterRow.FindControl("txtCIPT")).Text;

        if (!string.IsNullOrEmpty(cipt))
        {
            SP.List list = ctx.Web.Lists.GetByTitle("CIPT");
            SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
            SP.ListItem listItem = list.AddItem(itemCreateInfo);
            listItem["Title"] = CIPTID;
            listItem["CIPT"] = _ws.GetUser(DomainID).Id;
            listItem["DomainID"] = DomainID;
            listItem["Email"] = _ws.GetUser(DomainID).Email;
            listItem["Users"] = Convert.ToString(Session["User"]);
            listItem["UserID"] = _ws.GetUser(DomainID).Id;
            listItem["Group"] = _ws.GetUser(DomainID).Id;
            listItem["DelFlag"] = "0";
            listItem.Update();
            _ws.executeClientContext(ctx);
            BindData();
            AddUserToGroup(_ws.GetUser(DomainID));
            _ws.UpdateCIPTUser(Convert.ToString(Session["User"]));
        }
    }

    public string getAllUserFromUser()
    {

        return "";
    }

    protected void gvGroup_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        Label lblDomainID = (Label)gvGroup.Rows[e.RowIndex].FindControl("lblDomainID");
        SP.User user = _ws.GetUser(lblDomainID.Text.Trim());
        UpdateRecord(itemID: recordID, user: user, domainID: lblDomainID.Text.Trim());
    }
    protected void gvGroup_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGroup.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        Label lblDomainID = (Label)gvGroup.Rows[e.RowIndex].FindControl("lblDomainID");
        DeleteRecord(itemID: recordID, user: _ws.GetUser(lblDomainID.Text));
    }
    protected void gvGroup_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvGroup.EditIndex = -1;
        BindData();
    }

    public void UpdateRecord(string itemID, SP.User user, string domainID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("CIPT");
        SP.ListItem item = list.GetItemById(itemID);
        ctx.Load(item);
        item["Title"] = user.Id.ToString();
        item["CIPT"] = user.Id;
        item["DomainID"] = domainID;
        item["Email"] = user.Email;
        item["Users"] = Convert.ToString(Session["User"]);
        item["UserID"] = _ws.GetUser(domainID).Id;
        item["DelFlag"] = "0";
        item.Update();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
        _ws.UpdateCIPTUser(Convert.ToString(Session["User"]));
    }
    public void DeleteRecord(string itemID, SP.User user)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("CIPT");
        SP.ListItem item = list.GetItemById(itemID);
        item.DeleteObject();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
        RemoveUserFromGroup(user);
        _ws.UpdateCIPTUser(Convert.ToString(Session["User"]));
    }

    public void RemoveUserFromGroup(SP.User user)
    {
        SP.GroupCollection oGroupColl = ctx.Web.SiteGroups;
        SP.Group oGroup = oGroupColl.GetById(ciptGroup);
        SP.UserCollection collUser = oGroup.Users;
        SP.User userVal = ctx.Web.EnsureUser(user.Email);

        ctx.Load(oGroup);
        ctx.Load(userVal);

        collUser.Remove(userVal);
        _ws.executeClientContext(ctx);
    }

    public void AddUserToGroup(SP.User usr)
    {
        SP.GroupCollection oGroupColl = ctx.Web.SiteGroups;
        SP.Group oGroup = oGroupColl.GetById(ciptGroup);
        SP.UserCollection collUser = oGroup.Users;
        SP.User userVal = ctx.Web.EnsureUser(usr.Email);

        ctx.Load(oGroup);
        ctx.Load(userVal);

        collUser.AddUser(userVal);
        _ws.executeClientContext(ctx);


    }

    protected void txtName_OnTextChange(object sender, EventArgs e)
    {
        service = new ADService();
        GridViewRow currentRow = (GridViewRow)((TextBox)sender).Parent.Parent;

        TextBox txtEmpName = ((TextBox)sender);
        string empName = txtEmpName.Text;
        Label lblECNo = (Label)currentRow.FindControl("lblCIPTID");
        Label lblDomainID = (Label)currentRow.FindControl("lblDomainID");
        Button btnAdd = gvGroup.FooterRow.FindControl("btnAdd") as Button;
        try
        {
            string[] EmployeeSet = (Session["EmployeeSet"] != null ? (string[])Session["EmployeeSet"] : null);
            string empDomainName = (from name in EmployeeSet where name.Contains(empName) select name).FirstOrDefault<string>();
            DataTable dtProfile = service.getUserDetailsByDomainId(empDomainName.Substring(0, empDomainName.IndexOf("[")));

            lblDomainID.Text = dtProfile.Rows[0]["domainId"].ToString();
            lblECNo.Text = dtProfile.Rows[0]["employeeId"].ToString();

            txtEmpName.BorderColor = System.Drawing.ColorTranslator.FromHtml("#DEDFDE");
            currentRow.ForeColor = System.Drawing.ColorTranslator.FromHtml("#393839");
            btnAdd.Enabled = true;
        }
        catch (Exception)
        {
            lblECNo.Text = "--------";
            txtEmpName.BorderColor = System.Drawing.Color.Red;
            currentRow.ForeColor = System.Drawing.Color.Red;
            txtEmpName.Focus();
            btnAdd.Enabled = false;
        }
    }

}