﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;

public partial class Segment : System.Web.UI.Page
{
    Workshop _ws;
    SP.ClientContext ctx;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        ctx = _ws.getClientContext();
        if(!Page.IsPostBack)
        {
            BindData();
        }
       
    }

    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {       
        switch (e.CommandName.Trim().ToUpper())
        {
            //case "EDIT":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            //case "VIEW":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            case "ADD":
                AddRecord();
                break;


            case "CANCEL":
                 gvGroup.EditIndex = -1;
                    BindData();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("DelFlag", "0");
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "Segment", columns: new List<string>() { "ID", "SegmentID", "Title", "SeniorManagement" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        if (Session["Segment"] == null)
            SessionUtility.AddSessionValue(key: "Segment", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "Segment", value: gridRequest);        
        gvGroup.DataSource = gridRequest;
        gvGroup.DataBind();
    }

    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }

    /// <summary>
    /// Method to delete Item/Record
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("Segment", int.Parse(Session["_itemID"].ToString()));
        BindData();
    }
    

    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {           
           // DataRow dr = ((DataRowView)e.Row.DataItem).Row;
          //  LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
          //  lnkView.Text = dr["WorkshopID"].ToString();
          //  Label lblReqDate = e.Row.FindControl("lblReqDate") as Label;
          //  lblReqDate.Text = Convert.ToDateTime(lblReqDate.Text).ToShortDateString();
        }
   
    }


    public void AddRecord()
    {
        string segmentID = ((TextBox)gvGroup.FooterRow.FindControl("txtSegmentID")).Text;
        string segment = ((TextBox)gvGroup.FooterRow.FindControl("txtSegment")).Text;
        string manager = ((TextBox)gvGroup.FooterRow.FindControl("txtManager")).Text;
        SP.List list = ctx.Web.Lists.GetByTitle("Segment");
        SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
        SP.ListItem listItem = list.AddItem(itemCreateInfo);
        listItem["SegmentID"] = segmentID;
        listItem["Title"] = segment;
        listItem["SeniorManagement"] = _ws.GetUser(manager).Id;
        listItem["DelFlag"] = "0";
        listItem.Update();
        _ws.executeClientContext(ctx);
        BindData();
    }

    protected void gvGroup_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        TextBox txtSegmentID = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtSegmentID");
        TextBox txtSegment = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtSegment");
        TextBox txtManager = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtManager");
        UpdateRecord(itemID: recordID, segment: txtSegment.Text, manger: txtManager.Text,SegmentID:txtSegmentID.Text);
    }
    protected void gvGroup_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGroup.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        DeleteRecord(itemID: recordID);
    }
    protected void gvGroup_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvGroup.EditIndex = -1;
        BindData();
    }

    public void UpdateRecord(string itemID, string segment, string manger, string SegmentID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("Segment");
        SP.ListItem item = list.GetItemById(itemID);
        ctx.Load(item);
        item["SegmentID"] = SegmentID;
        item["Title"] = segment;
        item["SeniorManagement"] = _ws.GetUser(manger).Id;
        item["DelFlag"] = "0";
        item.Update();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }
    public void DeleteRecord(string itemID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("Segment");
        SP.ListItem item = list.GetItemById(itemID);
        item.DeleteObject();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }

}