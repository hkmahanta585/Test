﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;

public partial class Site : System.Web.UI.Page
{
    Workshop _ws;
    SP.ClientContext ctx;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        ctx = _ws.getClientContext();
        if(!Page.IsPostBack)
        {
            BindData();
        }
       
    }

    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {       
        switch (e.CommandName.Trim().ToUpper())
        {
            //case "EDIT":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            //case "VIEW":
            //    Response.Redirect("workshop.aspx?ID=" + e.CommandArgument.ToString(), true);
            //    break;

            case "ADD":
                AddRecord();
                break;


            case "CANCEL":
                 gvGroup.EditIndex = -1;
                    BindData();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("DelFlag", "0");
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "Site", columns: new List<string>() { "ID","SiteID", "Title", "SiteCTSHead", "SitePresident" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        
        if (Session["Site"] == null)
            SessionUtility.AddSessionValue(key: "Site", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "Site", value: gridRequest);

        DataView dv = new DataView(gridRequest);
        dv.Sort = "Title";

        gvGroup.DataSource = dv;
        gvGroup.DataBind();
    }

    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }

    /// <summary>
    /// Method to delete Item/Record
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("Site", int.Parse(Session["_itemID"].ToString()));
        BindData();
    }
    

    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {           
           // DataRow dr = ((DataRowView)e.Row.DataItem).Row;
          //  LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
          //  lnkView.Text = dr["WorkshopID"].ToString();
          //  Label lblReqDate = e.Row.FindControl("lblReqDate") as Label;
          //  lblReqDate.Text = Convert.ToDateTime(lblReqDate.Text).ToShortDateString();
        }
   
    }


    public void AddRecord()
    {
        string siteID = ((TextBox)gvGroup.FooterRow.FindControl("txtSiteID")).Text;
        string site = ((TextBox)gvGroup.FooterRow.FindControl("txtSite")).Text;
        string SiteHead = ((TextBox)gvGroup.FooterRow.FindControl("txtFSiteHead")).Text;
        string SitePresident = ((TextBox)gvGroup.FooterRow.FindControl("txtSitePress")).Text;
        SP.List list = ctx.Web.Lists.GetByTitle("Site");
        SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
        SP.ListItem listItem = list.AddItem(itemCreateInfo);
        listItem["Title"] = site;
        listItem["SiteID"] = siteID;
        listItem["SiteCTSHead"] = _ws.GetUser(SiteHead).Id;
        listItem["SitePresident"] = _ws.GetUser(SitePresident).Id;
        listItem["DelFlag"] = "0";
        listItem.Update();
        _ws.executeClientContext(ctx);
        BindData();
    }

    protected void gvGroup_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        TextBox txtSiteID = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtSiteID");
        TextBox txtSite = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtSite");
        TextBox txtSiteHead = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtSiteHead");
        TextBox txtsitePres = (TextBox)gvGroup.Rows[e.RowIndex].FindControl("txtSitePress");
        UpdateRecord(itemID: recordID, site: txtSite.Text, siteHead: txtSiteHead.Text, sitePress: txtsitePres.Text,SiteID:txtSiteID.Text);
    }
    protected void gvGroup_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGroup.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string recordID = gvGroup.DataKeys[e.RowIndex].Value.ToString();
        DeleteRecord(itemID: recordID);
    }
    protected void gvGroup_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvGroup.EditIndex = -1;
        BindData();
    }

    public void UpdateRecord(string itemID,string site,string siteHead,string sitePress,string SiteID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("Site");
        SP.ListItem item = list.GetItemById(itemID);
        ctx.Load(item);
        item["SiteID"] = SiteID;
        item["Title"] = site;
        item["SiteCTSHead"] = _ws.GetUser(siteHead).Id;
        item["SitePresident"] = _ws.GetUser(sitePress).Id;
        item["DelFlag"] = "0";
        item.Update();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }
    public void DeleteRecord(string itemID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("Site");
        SP.ListItem item = list.GetItemById(itemID);
        item.DeleteObject();
        _ws.executeClientContext(ctx);
        gvGroup.EditIndex = -1;
        BindData();
    }

}