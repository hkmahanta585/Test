﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using WebApplication1;

public partial class Grade : System.Web.UI.Page
{
    Workshop _ws;
    SP.ClientContext ctx;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        ctx = _ws.getClientContext();
        if (!Page.IsPostBack)
        {
            BindData();
        }

    }

    protected void gvGrade_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.Trim().ToUpper())
        {
            case "ADD":
                AddRecord();
                break;

            case "CANCEL":
                gvGrade.EditIndex = -1;
                BindData();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExtGradeList", columns: new List<string>() { "ID", "Title", "LevelA", "LevelB", "LevelC", "LevelD", "LevelE", "ActiveFlag" }, filterColumnType: new List<string>() { }, filters: filters);
        gvGrade.DataSource = gridRequest;
        gvGrade.DataBind();
    }

    protected void gvGrade_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGrade.PageIndex = e.NewPageIndex;
        BindData();
    }

    protected void gvGrade_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow && gvGrade.EditIndex == e.Row.RowIndex)
        {
            DataRow dr = ((DataRowView)e.Row.DataItem).Row;

            DropDownList ddlLevel1 = (DropDownList)e.Row.FindControl("ddlLevel1");
            ddlLevel1.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel1.DataTextField = "Value";
            ddlLevel1.DataValueField = "Key";
            ddlLevel1.DataBind();
            ddlLevel1.Items.Insert(0, "--Select--");
            ddlLevel1.Items.FindByText(Convert.ToString(dr["LevelA"])).Selected = true;


            DropDownList ddlLevel2 = (DropDownList)e.Row.FindControl("ddlLevel2");
            ddlLevel2.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel2.DataTextField = "Value";
            ddlLevel2.DataValueField = "Key";
            ddlLevel2.DataBind();
            ddlLevel2.Items.Insert(0, "--Select--");
            ddlLevel2.Items.FindByText(Convert.ToString(dr["LevelB"])).Selected = true;

            DropDownList ddlLevel3 = (DropDownList)e.Row.FindControl("ddlLevel3");
            ddlLevel3.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel3.DataTextField = "Value";
            ddlLevel3.DataValueField = "Key";
            ddlLevel3.DataBind();
            ddlLevel3.Items.Insert(0, "--Select--");
            ddlLevel3.Items.FindByText(Convert.ToString(dr["LevelC"])).Selected = true;

            DropDownList ddlLevel4 = (DropDownList)e.Row.FindControl("ddlLevel4");
            ddlLevel4.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel4.DataTextField = "Value";
            ddlLevel4.DataValueField = "Key";
            ddlLevel4.DataBind();
            ddlLevel4.Items.Insert(0, "--Select--");
            ddlLevel4.Items.FindByText(Convert.ToString(dr["LevelD"])).Selected = true;

            DropDownList ddlLevel5 = (DropDownList)e.Row.FindControl("ddlLevel5");
            ddlLevel5.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel5.DataTextField = "Value";
            ddlLevel5.DataValueField = "Key";
            ddlLevel5.DataBind();
            ddlLevel5.Items.Insert(0, "--Select--");
            ddlLevel5.Items.FindByText(Convert.ToString(dr["LevelE"])).Selected = true;
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            DropDownList ddlLevel1 = (DropDownList)e.Row.FindControl("ddlLevel1");
            ddlLevel1.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel1.DataTextField = "Value";
            ddlLevel1.DataValueField = "Key";
            ddlLevel1.DataBind();
            ddlLevel1.Items.Insert(0, "--Select--");

            DropDownList ddlLevel2 = (DropDownList)e.Row.FindControl("ddlLevel2");
            ddlLevel2.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel2.DataTextField = "Value";
            ddlLevel2.DataValueField = "Key";
            ddlLevel2.DataBind();
            ddlLevel2.Items.Insert(0, "--Select--");

            DropDownList ddlLevel3 = (DropDownList)e.Row.FindControl("ddlLevel3");
            ddlLevel3.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel3.DataTextField = "Value";
            ddlLevel3.DataValueField = "Key";
            ddlLevel3.DataBind();
            ddlLevel3.Items.Insert(0, "--Select--");

            DropDownList ddlLevel4 = (DropDownList)e.Row.FindControl("ddlLevel4");
            ddlLevel4.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel4.DataTextField = "Value";
            ddlLevel4.DataValueField = "Key";
            ddlLevel4.DataBind();
            ddlLevel4.Items.Insert(0, "--Select--");

            DropDownList ddlLevel5 = (DropDownList)e.Row.FindControl("ddlLevel5");
            ddlLevel5.DataSource = fillDropDown(_ws, "ExtRoleList", "RoleID", "Title");
            ddlLevel5.DataTextField = "Value";
            ddlLevel5.DataValueField = "Key";
            ddlLevel5.DataBind();
            ddlLevel5.Items.Insert(0, "--Select--");
        }
    }

    public void AddRecord()
    {
        string group = ((TextBox)gvGrade.FooterRow.FindControl("txtGrade")).Text;
         string vLevel1 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel1")).SelectedValue.ToString();
        string vLevel2 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel2")).SelectedValue.ToString();
        string vLevel3 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel3")).SelectedValue.ToString();
        string vLevel4 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel4")).SelectedValue.ToString();
        string vLevel5 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel5")).SelectedValue.ToString();

        string tLevel1 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel1")).SelectedItem.Text;
        string tLevel2 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel2")).SelectedItem.Text;
        string tLevel3 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel3")).SelectedItem.Text;
        string tLevel4 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel4")).SelectedItem.Text;
        string tLevel5 = ((DropDownList)gvGrade.FooterRow.FindControl("ddlLevel5")).SelectedItem.Text;


        string gradeKey = (tLevel1.Contains("Select") ? string.Empty : vLevel1) + (tLevel1.Contains("Select") ? string.Empty : ";") + (tLevel2.Contains("Select") ? string.Empty : vLevel2) + (tLevel2.Contains("Select") ? string.Empty : ";") + (tLevel3.Contains("Select") ? string.Empty : vLevel3) + (tLevel3.Contains("Select") ? string.Empty : ";") + (tLevel4.Contains("Select") ? string.Empty : vLevel4) + (tLevel4.Contains("Select") ? string.Empty : ";") + (tLevel5.Contains("Select") ? string.Empty : vLevel5);
        if (_ws.CheckGradeExist(gradeKey,true))
        {
            SP.List list = ctx.Web.Lists.GetByTitle("ExtGradeList");
            SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
            SP.ListItem listItem = list.AddItem(itemCreateInfo);
            listItem["Title"] = group;
            listItem["LevelA"] = tLevel1;
            listItem["LevelB"] = tLevel2;
            listItem["LevelC"] = tLevel3;
            listItem["LevelD"] = tLevel4;
            listItem["LevelE"] = tLevel5;
            listItem["GradeKey"] = gradeKey;
           
            listItem.Update();
            _ws.executeClientContext(ctx);
            BindData();
        }
        else
        {
            this.mdlSuccess.Show();
            msgHeadings.Text = "Error!";
            msgBody.Text = "Allready grade with same configuration is available, Please change configuration.";
        }

    }

    protected void gvGrade_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string recordID = gvGrade.DataKeys[e.RowIndex].Value.ToString();
        TextBox txtGrade = (TextBox)gvGrade.Rows[e.RowIndex].FindControl("txtGrade");
        DropDownList ddlLevel1 = (DropDownList)gvGrade.Rows[e.RowIndex].FindControl("ddlLevel1");
        DropDownList ddlLevel2 = (DropDownList)gvGrade.Rows[e.RowIndex].FindControl("ddlLevel2");
        DropDownList ddlLevel3 = (DropDownList)gvGrade.Rows[e.RowIndex].FindControl("ddlLevel3");
        DropDownList ddlLevel4 = (DropDownList)gvGrade.Rows[e.RowIndex].FindControl("ddlLevel4");
        DropDownList ddlLevel5 = (DropDownList)gvGrade.Rows[e.RowIndex].FindControl("ddlLevel5");
        DropDownList ddlActiveFlag = (DropDownList)gvGrade.Rows[e.RowIndex].FindControl("ddlActiveFlag");

        string gradeKey = (ddlLevel1.SelectedItem.Text.Contains("Select") ? string.Empty : ddlLevel1.SelectedValue.ToString()) + (ddlLevel1.SelectedItem.Text.Contains("Select") ? string.Empty : ";") + (ddlLevel2.SelectedItem.Text.Contains("Select") ? string.Empty : ddlLevel2.SelectedValue.ToString()) + (ddlLevel2.SelectedItem.Text.Contains("Select") ? string.Empty : ";") + (ddlLevel3.SelectedItem.Text.Contains("Select") ? string.Empty : ddlLevel3.SelectedValue.ToString()) + (ddlLevel3.SelectedItem.Text.Contains("Select") ? string.Empty : ";") + (ddlLevel4.SelectedItem.Text.Contains("Select") ? string.Empty : ddlLevel4.SelectedValue.ToString()) + (ddlLevel4.SelectedItem.Text.Contains("Select") ? string.Empty : ";") + (ddlLevel5.SelectedItem.Text.Contains("Select") ? string.Empty : ddlLevel5.SelectedValue.ToString());

        UpdateRecord(itemID: recordID, grade: txtGrade.Text, level1: ddlLevel1.SelectedItem.Text, level2: ddlLevel2.SelectedItem.Text, level3: ddlLevel3.SelectedItem.Text, level4: ddlLevel4.SelectedItem.Text, level5: ddlLevel5.SelectedItem.Text, gradeKey: gradeKey, active: ddlActiveFlag.SelectedItem.Text);
    }
    protected void gvGrade_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGrade.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvGrade_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string recordID = gvGrade.DataKeys[e.RowIndex].Value.ToString();
        DeleteRecord(itemID: recordID);
    }
    protected void gvGrade_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvGrade.EditIndex = -1;
        BindData();
    }

    public void UpdateRecord(string itemID, string grade, string level1, string level2, string level3, string level4, string level5,string gradeKey,string active)
    {
        if (_ws.CheckGradeExist(gradeKey,false,itemID))
        {
            SP.List list = ctx.Web.Lists.GetByTitle("ExtGradeList");
            SP.ListItem item = list.GetItemById(itemID);
            ctx.Load(item);
            item["Title"] = grade;
            item["LevelA"] = level1;
            item["LevelB"] = level2;
            item["LevelC"] = level3;
            item["LevelD"] = level4;
            item["LevelE"] = level5;
            item["GradeKey"] = gradeKey;
            item["ActiveFlag"] = active;
            item.Update();
            _ws.executeClientContext(ctx);
            gvGrade.EditIndex = -1;
            BindData();
        }
        else
        {
            this.mdlSuccess.Show();
            msgHeadings.Text = "Error!";
            msgBody.Text = "Allready grade with same configuration is available, Please change configuration.";
        }
      
    }
    public void DeleteRecord(string itemID)
    {
        SP.List list = ctx.Web.Lists.GetByTitle("ExtGradeList");
        SP.ListItem item = list.GetItemById(itemID);
        item.DeleteObject();
        _ws.executeClientContext(ctx);
        gvGrade.EditIndex = -1;
        BindData();
    }
    public object fillDropDown(Workshop ws, string listName, string keyColumnName, string valueColumnName)
    {

        var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionary(listName, keyColumnName, valueColumnName, "Text", new KeyValuePair<string, string>("Active", "Yes"))
                       select new
                       {
                           Key = ddlRow.Key,
                           Value = ddlRow.Value
                       });
        return ddlData;
    }

}