﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;

public partial class MyPublDocuments : System.Web.UI.Page
{
    Workshop _ws;
    //string _itemID;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (!Page.IsPostBack)
        {
            BindData();
        }
    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        Session["ID"] = e.CommandArgument.ToString();
        switch (e.CommandName.Trim().ToUpper())
        {
            case "DELETE":
                lblMassage.Text = "Are you sure you want to delete this doc.?";
                this.mdlModelDialog.Show();
                break;
        }
    }
   
    protected void lnkFileName_Click(object sender, EventArgs e)
    {
        LinkButton button = (LinkButton)sender;
        GridViewRow row = (GridViewRow)button.NamingContainer;
        if (row != null)
        {
          string itemID = ((LinkButton)sender).CommandArgument.ToString();
          Session["ID"] = itemID;
          DownloadDocument();
        }
    }

    public void BindData()
    {
        try
        {
            Dictionary<string, string> filters = new Dictionary<string, string>();
            filters.Add("DelFlag", "0");
            filters.Add("Requstor", _ws.GetCurrentUserEmail());
            DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExtUploadDocs", columns: new List<string>() { "ID", "Requstor", "JournalName", "VolumeNo", "PageNo", "DateOfPubl", "UpldDate", "RequestID", "FileLeafRef" }, filterColumnType: new List<string>() { "Text", "Text" }, filters: filters);

            DataView dv = new DataView(gridRequest);
            dv.Sort = "RequestID DESC";

            gvGroup.DataSource = dv;
            gvGroup.DataBind();
        }
        catch (Exception ex)
        {
            _ws.LogError("MyPubDocuments (BindData) :-", ex.Message.ToString());
        }
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("ExtUploadDocs", int.Parse(Session["ID"].ToString()));
        BindData();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        // _ws.DeleteItem("WorkshopDocs", int.Parse(Session["_itemID"].ToString()));
        // BindData();
    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        //_ws.DeleteItem("WorkshopDocs", int.Parse(Session["_itemID"].ToString()));
        // BindData();
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                //DataRow dr = ((DataRowView)e.Row.DataItem).Row;

                //LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
                //lnkView.Text = dr["RequestID"].ToString();

                //Label lblReqDate = e.Row.FindControl("lblReqDate") as Label;
                //lblReqDate.Text = Convert.ToDateTime(lblReqDate.Text).ToShortDateString();


                ////Prevent from Deleting
                //int wfLevel = Int32.Parse(dr["WFLevel"].ToString());
                //string rStatus = dr["WFLevel"].ToString();
                //if (wfLevel > 0)
                //{
                //    LinkButton lnkDel = e.Row.FindControl("lnkDelete") as LinkButton;
                //    LinkButton lnkEdit = e.Row.FindControl("lnkEdit") as LinkButton;
                //    if (lnkDel != null && lnkEdit != null)
                //    {
                //        lnkDel.ToolTip = "Sorry you can not 'DELETE' this record..";
                //        lnkDel.CommandName = "EDITDELETE";
                //        lnkEdit.ToolTip = "Sorry you can not 'EDIT' this record..";
                //        lnkEdit.CommandName = "EDITDELETE";
                //    }
                //}
            }
            catch (Exception)
            {
            }
        }

    }

    public void DownloadDocument()
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExtUploadDocs");
            SP.ListItem item = list.GetItemById(int.Parse(Session["ID"].ToString()));
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            //context.ExecuteQuery();
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);

            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }

}
