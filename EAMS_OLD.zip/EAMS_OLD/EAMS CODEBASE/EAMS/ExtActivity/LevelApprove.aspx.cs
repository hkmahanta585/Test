﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Configuration;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using EAMSBusiness;
using WebApplication1;
using System.Text;

public partial class LevelApprove : System.Web.UI.Page
{
    #region Private Members
    string _editItemID;
    string _level;
    string _levelKey;
    Workshop _ws;
    int _wfLevel;
    string _role;
    #endregion

    #region Event Handlers
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (Session["ID"] != null)
        {
            _editItemID = Session["ID"].ToString();
        }
        if (Session["LevelFlag"] != null && Session["LevelKey"] != null)
        {
            _level = Session["LevelFlag"].ToString();
            _levelKey = Session["LevelKey"].ToString();
        }
        if (!IsPostBack && _editItemID != null)
        {
            PopulatePageWithData();
        }
    }

    protected void lnkAttachedFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExternalActivity");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }

    protected void btnApprove_Click(object sender, EventArgs e)
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("WFLevel", "1");
        string gradeKey = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("ID", _editItemID), "GradeKey");
        string[] gradeKeySet = gradeKey.Split(';').Select(x => Convert.ToString(x)).ToArray();

        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            string listTitle = string.Empty;
            switch (_levelKey)
            {
                case "R1":
                    listTitle = "ExtLevelAFeedback";
                    _role = _ws.getColumnValue("ExtRoleList", new KeyValuePair<string, string>("RoleID", Convert.ToString(gradeKeySet[0])), "Title");
                    break;
                case "R2":
                    listTitle = "ExtLevelBFeedback";
                    _role = _ws.getColumnValue("ExtRoleList", new KeyValuePair<string, string>("RoleID", Convert.ToString(gradeKeySet[1])), "Title");
                    break;
                case "R3":
                    listTitle = "ExtLevelCFeedback";
                    _role = _ws.getColumnValue("ExtRoleList", new KeyValuePair<string, string>("RoleID", Convert.ToString(gradeKeySet[2])), "Title");
                    break;
                case "R4":
                    listTitle = "ExtLevelDFeedback";
                    _role = _ws.getColumnValue("ExtRoleList", new KeyValuePair<string, string>("RoleID", Convert.ToString(gradeKeySet[3])), "Title");
                    break;
                case "R5":
                    listTitle = "ExtLevelEFeedback";
                    _role = _ws.getColumnValue("ExtRoleList", new KeyValuePair<string, string>("RoleID", Convert.ToString(gradeKeySet[4])), "Title");
                    break;
            }

            SP.List list = site.Lists.GetByTitle(listTitle);
            SP.ListItemCreationInformation itemCreationInfo = new SP.ListItemCreationInformation();
            SP.ListItem item = list.AddItem(itemCreationInfo);
            item["Title"] = lblRequestID.Text;
            item["Status"] = ddlStatus.SelectedItem.Text;
            item["Comment"] = txtComment.Text;
            item["Level"] = _levelKey;
            item.Update();
            _ws.executeClientContext(context);

            //Update status in Attendance Library (Main List)
            UpdateRequestStatus(context);
        }
        Response.Redirect("Summary.aspx");
    }
    #endregion

    #region Private Methods
    void PopulatePageWithData()
    {
        string EditMode = string.Empty;
        DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("GridRequest");
        DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();
        lblRequestID.Text = drGridRequest["RequestID"].ToString();

        gvStatus.DataSource = _ws.GetRequestStatusDetails(Convert.ToString(drGridRequest["RequestID"]));
        gvStatus.DataBind();
        
        lblSegment.Text = drGridRequest["Segment"].ToString();
        lblSector.Text = drGridRequest["Sector"].ToString();
        lblBusiness.Text = drGridRequest["Business"].ToString();
        lblSite.Text = drGridRequest["site"].ToString();
        lblTitle.Text = drGridRequest["Title"].ToString();

        lblCategory.Text = drGridRequest["Category"].ToString();
        if (drGridRequest["FileLeafRef"].ToString().ToLower().Contains("xxxxx"))
        {
            lnkAttachedFile.Text = string.Empty;
        }
        else
        {
            lnkAttachedFile.Text = drGridRequest["FileLeafRef"].ToString();
        }
        if (drGridRequest["IPCLReportName"].ToString().Length > 0)
        {
            lnkIpClReport.Text = drGridRequest["IPCLReportName"].ToString();
            rowIpClReport.Visible = true;
        }
        else
        {
            lnkIpClReport.Text = string.Empty;
            rowIpClReport.Visible = false;
        }
        lblAbstract.Text = drGridRequest["Abstract"].ToString();

        lblJournal.Text = drGridRequest["JournalConfDetail"].ToString().Replace(";", "<br />"); 

        lblValueCost.Text = drGridRequest["RilValue"].ToString();

        lblKeayReason.Text = drGridRequest["KeyReason"].ToString();
        _wfLevel = Int32.Parse(drGridRequest["WFLevel"].ToString());

        lblApprover.Text = _ws.GetApprover(lblRequestID.Text, lblTitle.Text);

        lblAprovPrestion.Text = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? "Abstract (Only for presentation)" : "Full Paper/Presentation (Final manuscript, Final presentation, award application, etc.)");

        lblTakingApproval1.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? true : false);
        lblTakingApproval2.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("2") ? true : false);
        
        lblPatent.Text = (Convert.ToString(drGridRequest["Patent"]).Contains("0") ? "Yes" : (Convert.ToString(drGridRequest["Patent"]).Contains("1") ? "No" : "Don't Know"));
        lblA.Text = (Convert.ToString(drGridRequest["PatentA"]).Contains("0") ? "Yes" : "No");
        lblB.Text = (Convert.ToString(drGridRequest["PatentB"]).Contains("0") ? "Yes" : "No");

        lblC.Text = drGridRequest["PatentC"].ToString();
        lblD.Text = drGridRequest["PatentD"].ToString();
        lblE.Text = drGridRequest["PatentE"].ToString();
        lblAA.Text = drGridRequest["PatentF"].ToString();

        //------------------------------------------------
        EditMode = (drGridRequest["PatentA"].ToString().Length > 0 ? "A" : "");
        EditMode += (drGridRequest["PatentB"].ToString().Length > 0 ? "B" : "");
        EditMode += (drGridRequest["PatentC"].ToString().Length > 0 ? "C" : "");
        EditMode += (drGridRequest["PatentD"].ToString().Length > 0 ? "D" : "");
        EditMode += (drGridRequest["PatentE"].ToString().Length > 0 ? "E" : "");
        EditMode += (drGridRequest["PatentF"].ToString().Length > 0 ? "F" : "");
        lblEditMode.Text = EditMode;
        //------------------------------------------------
        string disclosure = Convert.ToString(drGridRequest["Disclosure"]);
        /*rowA.Visible = false;
        rowB.Visible = false;
        rowC.Visible = false;
        rowD.Visible = false;
        rowE.Visible = false;
        rowF.Visible = false;
        rowG.Visible = false;*/
        rdbA.Enabled = false;
        rdbB.Enabled = false;
        rdbC.Enabled = false;
        rdbD.Enabled = false;
        rdbE.Enabled = false;
        rdbF.Enabled = false;
        rdbG.Enabled = false;


        switch (disclosure)
        {
            case "A":
                rdbA.Checked = true;
                //rowA.Visible = true;
                rowA.Style.Add("font-weight", "bold");
                break;
            case "B":
                rdbB.Checked = true;
                //rowB.Visible = true;
                rowB.Style.Add("font-weight", "bold");
                break;
            case "C":
                rdbC.Checked = true;
                //rowC.Visible = true;
                rowC.Style.Add("font-weight", "bold");
                break;
            case "D":
                rdbD.Checked = true;
                //rowD.Visible = true;
                rowD.Style.Add("font-weight", "bold");
                break;
            case "E":
                rdbE.Checked = true;
                //rowE.Visible = true;
                rowE.Style.Add("font-weight", "bold");
                break;
            case "F":
                rdbF.Checked = true;
                //rowF.Visible = true;
                rowF.Style.Add("font-weight", "bold");
                break;
            case "G":
                rdbG.Checked = true;
                //rowG.Visible = true;
                rowG.Style.Add("font-weight", "bold");
                break;
        }

        rwDateOfConf.Visible = false;
        rwConfIs.Visible = false;
        if (!((Convert.ToString(drGridRequest["Category"]).Contains("PUB")) || (Convert.ToString(drGridRequest["Category"]).Length == 0)))
        {
            lblDateOfConf.Text = Convert.ToString(drGridRequest["ConfDate"]);
            lblConfIs.Text = (Convert.ToString(drGridRequest["ConfType"]).Contains("0") ? "National" : "International");
            rwDateOfConf.Visible = true;
            rwConfIs.Visible = true;
        }
        //------------------------------------------------
        Session["_wfLevel"] = _wfLevel.ToString();
        //Following statement are used to fill grid view:
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters = new Dictionary<string, string>();
        filters.Add("Title", drGridRequest["RequestID"].ToString());
        DataTable ExtEmpGrid = _ws.getListAsGrid(givelistName: "ExtEmpList", columns: new List<string>() { "ID", "AuthorType", "AuthorName", "ECNo", "EmailID", "Reporting", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        gvEmp.DataSource = ExtEmpGrid;
        gvEmp.DataBind();

        filters.Clear();
        filters.Add("Title", drGridRequest["RequestID"].ToString());
        DataTable ExtNonEmpGrid = _ws.getListAsGrid(givelistName: "ExtNonEmpList", columns: new List<string>() { "ID", "CoAuthorName", "Orgnization", "EmailID", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        gvNonEmp.DataSource = ExtNonEmpGrid;
        gvNonEmp.DataBind();

        HideControls();
    }

    void HideControls()
    {
        string comment = string.Empty;
        string status = string.Empty;
        //switch (wFLevel)
        switch (_level)
        {
            case "0":
                comment = _ws.GetFeedBack(listName: "ExtLevelAFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "ExtLevelAFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
            case "1":
                comment = _ws.GetFeedBack(listName: "ExtLevelBFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "ExtLevelBFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
            case "2":
                comment = _ws.GetFeedBack(listName: "ExtLevelCFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "ExtLevelCFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
            case "3":
                comment = _ws.GetFeedBack(listName: "ExtLevelDFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "ExtLevelDFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
            case "4":
                comment = _ws.GetFeedBack(listName: "ExtLevelEFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "ExtLevelEFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
            default:
                break;
        }

        if (status.Equals("Pending", StringComparison.OrdinalIgnoreCase) || string.IsNullOrEmpty(status))
        {

            ddlStatus.Visible = true;
            txtComment.Visible = true;
            ddlStatus.Items.FindByText(string.IsNullOrEmpty(status) ? "Pending" : status).Selected = true;
            txtComment.Text = comment;
        }
        else
        {
            ddlStatus.Visible = false;
            txtComment.Visible = false;
            divStatus.InnerText = status;
            divComment.InnerText = comment;
            btnApprove.Visible = false;
            btnReject.Text = "OK";
        }

    }

    void UpdateRequestStatus(SP.ClientContext context)
    {
        SP.List list = context.Web.Lists.GetByTitle("ExternalActivity");
        SP.ListItem item = list.GetItemById(_editItemID);
        context.Load(item, editItem => editItem["LevelCount"]);
        _ws.executeClientContext(context);

        int levelCount = Int32.Parse(item["LevelCount"].ToString());
        int levelFlag = Int32.Parse(_level);
        string doneFlag = (levelCount == levelFlag + 1) ? "Completed" : "Open";

        switch (ddlStatus.SelectedItem.Text.ToLower())
        {
            case "pending":
                item["RStatus"] = "Open";
                item["ReqStatus"] = "Pending By " + _role;
                item["LevelFlag"] = levelFlag;
                break;

            case "rejected":
                item["RStatus"] = "Closed";
                item["ReqStatus"] = "Rejected By " + _role;
                break;

            case "approved":
                item["RStatus"] = doneFlag;
                item["ReqStatus"] = "Approved By " + _role;
                item["LevelFlag"] = levelFlag + 1;
                break;
        }
        item["EmailFlag"] = _role;
        item["StatusDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
        item["Status"] = ddlStatus.SelectedItem.Text;
        item["Comment"] = txtComment.Text;
        item.Update();
        _ws.executeClientContext(context);
    }
    #endregion

    protected void btnReject_Click(object sender, EventArgs e)
    {
        Response.Redirect("LevelView.aspx");
    }
    //protected void btnShowPopup_Click(object sender, EventArgs e)
    //{
    //    string message = "Message from server side";
    //    ClientScript.RegisterStartupScript(this.GetType(), "Popup", "ShowPopup('" + message + "');", true);

    //}
    protected void lnkIPCLReport_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("IPClerReport");

            SP.CamlQuery caml = new SP.CamlQuery();
            StringBuilder query = new StringBuilder(string.Empty);
            query.AppendFormat("<View><Query><Where><Eq><FieldRef Name = RequestID/><Value Type = 'Text'>{0}</Value></Eq></Where></Query></View>", lblRequestID.Text.Trim());
            caml.ViewXml = query.ToString();

            SP.ListItemCollection listItems = list.GetItems(caml);
            context.Load(listItems);
            _ws.executeClientContext(context);

            SP.ListItem item = listItems[0];
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
}