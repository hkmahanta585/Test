﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ExtActivity_HTML : System.Web.UI.Page
{
    Panel pnlTextBox;
    protected void Page_PreInit(object sender, EventArgs e)
    {
        //Create a Dynamic Panel
        pnlTextBox = new Panel();
        pnlTextBox.ID = "pnlTextBox";
        pnlTextBox.BorderWidth = 1;
        pnlTextBox.Width = 300;
        this.form1.Controls.Add(pnlTextBox);

        //Create a LinkDynamic Button to Add TextBoxes
        LinkButton btnAddtxt = new LinkButton();
        btnAddtxt.ID = "btnAddTxt";
        btnAddtxt.Text = "Add TextBox";
        btnAddtxt.Click += new System.EventHandler(btnAdd_Click);
        this.form1.Controls.Add(btnAddtxt);

        //Recreate Controls
        RecreateControls("txtDynamic", "TextBox");
        //RecreateControls("lblDynamic", "Label");
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        int txt = FindOccurence("txtDynamic");
        CreateTextBox("txtDynamic-" + Convert.ToString(txt + 1));
        //int lbl = FindOccurence("lblDynamic");
        //CreateTextBox("lblDynamic-" + Convert.ToString(lbl + 1));

    }
    private int FindOccurence(string substr)
    {
        string reqstr = Request.Form.ToString();
        return ((reqstr.Length - reqstr.Replace(substr, "").Length) / substr.Length);
    }
    private void RecreateControls(string ctrlPrefix, string ctrlType)
    {
        string[] ctrls = Request.Form.ToString().Split('&');
        int cnt = FindOccurence(ctrlPrefix);
        if (cnt > 0)
        {
            for (int k = 1; k <= cnt; k++)
            {
                for (int i = 0; i < ctrls.Length; i++)
                {
                    if (ctrls[i].Contains(ctrlPrefix + "-" + k.ToString()) && !ctrls[i].Contains("EVENTTARGET"))
                    {
                        string ctrlID = ctrls[i].Split('=')[0];

                        if (ctrlType == "TextBox")
                        {
                            CreateTextBox(ctrlID);
                        }
                        break;
                    }
                }
            }
        }
    }
    private void CreateTextBox(string ID)
    {
        //TextBox txt = new TextBox();
        //txt.ID = ID;
        //txt.AutoPostBack = true;
        //txt.TextChanged += new EventHandler(OnTextChanged);
        //pnlTextBox.Controls.Add(txt);

        //Literal lt = new Literal();
        //lt.Text = "<br />";
        //pnlTextBox.Controls.Add(lt);
        ///----------------------------------------------------------------



        //int number_Of_Controls = Convert.ToInt32(TextBox1.Text);
        HtmlTableRow Row = new HtmlTableRow();

        //retrieving the values of textboxes

        // string[] arr = hdField.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        //for (int i = 0; i < 3; i++)
        //{
        Label lbl1 = new Label();
        lbl1.ID = ID + "A";
        lbl1.Text = "Head Name:   ";
        HtmlTableCell cell = new HtmlTableCell();
        cell.Controls.Add(lbl1);
        //Row.Cells.Add(cell);

        TextBox txt1 = new TextBox();
        txt1.ID = ID;
        //HtmlTableCell cell = new HtmlTableCell();
        cell.Controls.Add(txt1);


        AjaxControlToolkit.AutoCompleteExtender ate = new AjaxControlToolkit.AutoCompleteExtender();
        ate.ID = ID + "B";
        ate.TargetControlID = ID;
        ate.ServiceMethod = "searchDomainId";
        ate.ServicePath = "~/ADService.asmx";
        ate.MinimumPrefixLength = 1;
        ate.DelimiterCharacters = ";";
        cell.Controls.Add(ate);

        Row.Cells.Add(cell);
        // }
        tblDynamic.Rows.Add(Row);

    }
    protected void OnTextChanged(object sender, EventArgs e)
    {
        TextBox txt = (TextBox)sender;
        string ID = txt.ID;
        ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", "<script type = 'text/javascript'>alert('" + ID + " fired OnTextChanged event');</script>");
        //Place the functionality here
    }
    protected void txtCheck_Click(object sender, EventArgs e)
    {

    }
}
