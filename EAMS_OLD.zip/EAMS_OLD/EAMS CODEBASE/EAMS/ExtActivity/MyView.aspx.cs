﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;

public partial class Workshop_MyView : System.Web.UI.Page
{
    Workshop _ws;
    //    KeyValuePair<string, string> filter;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        BindData();

    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.Trim().ToUpper())
        {
            case "EDIT":
                Response.Redirect("Request.aspx?ID=" + e.CommandArgument.ToString(), true);
                break;

            case "VIEW":
                Response.Redirect("MdlView.aspx?ID=" + e.CommandArgument.ToString(), true);
                break;

            case "EDITDELETE":
                this.mdlError.Show();
                break;

            case "DELETE":
                Session["_itemID"] = e.CommandArgument.ToString();
                this.mdlExtendar.Show();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        //filters.Add("RStatus", "Close");
        filters.Add("DelFlag", "0");
        filters.Add("Author", string.Empty);

        DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "Category", "RequestID", "ReqDate", "DelFlag", "WFLevel", "Status", "RStatus", "KeyReason", "RilValue", "JournalConfDetail", "ApproveWith", "Abstract", "ReqStatus", "Comment", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "Disclosure", "ConfDate", "ConfType", "StatusDate", "MDFLevel", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "Text", "User" }, filters: filters);
        if (Session["GridRequest"] == null)
            SessionUtility.AddSessionValue(key: "GridRequest", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "GridRequest", value: gridRequest);

        DataView dv = new DataView(gridRequest);
        dv.Sort = "ID DESC";

        gvGroup.DataSource = dv;
        gvGroup.DataBind();
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("ExternalActivity", int.Parse(Session["_itemID"].ToString()));
        BindData();
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;

                LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
                lnkView.Text = dr["RequestID"].ToString();

                DropDownList ddlCoAuthor = e.Row.FindControl("ddlCoAuthor") as DropDownList;
                ddlCoAuthor.DataSource = _ws.getCoAuthor(new KeyValuePair<string, string>("Title", lnkView.Text.Trim()));
                ddlCoAuthor.DataBind();
                string authorName = ddlCoAuthor.Items[0].ToString();
                ddlCoAuthor.Items.RemoveAt(0);
                ddlCoAuthor.Items.Insert(0, authorName + " (A)");

                int wfLevel = (Convert.ToString(dr["WFLevel"]).Length > 0 ? Int32.Parse(Convert.ToString(dr["WFLevel"])) : 0);
                string rStatus = dr["WFLevel"].ToString();
                if (wfLevel > 0)
                {
                    LinkButton lnkDel = e.Row.FindControl("lnkDelete") as LinkButton;
                    LinkButton lnkEdit = e.Row.FindControl("lnkEdit") as LinkButton;
                    if (lnkDel != null && lnkEdit != null)
                    {
                        lnkDel.ToolTip = "Sorry you can not 'DELETE' this record..";
                        lnkDel.CommandName = "EDITDELETE";
                        lnkEdit.ToolTip = "Sorry you can not 'EDIT' this record..";
                        lnkEdit.CommandName = "EDITDELETE";
                    }
                }
            }
            catch (Exception)
            {
            }
        }

    }

}
