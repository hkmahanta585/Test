﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;

public partial class DraftView : System.Web.UI.Page
{
    Workshop _ws;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        BindData();

    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.Trim().ToUpper())
        {
            case "EDIT":
                Session["Status"] = "Draft";
                Response.Redirect("Request.aspx?ID=" + e.CommandArgument.ToString(), true);
                break;

            case "VIEW":
                Response.Redirect("MdlView.aspx?ID=" + e.CommandArgument.ToString(), true);
                break;

            case "DELETE":
                Session["_itemID"] = e.CommandArgument.ToString();
                this.mdlExtendar.Show();
                break;
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("DelFlag", "0");
        filters.Add("RStatus", "Draft");
        filters.Add("Author", string.Empty);

        DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Category", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "KeyReason", "RilValue", "JournalConfDetail", "ApproveWith", "Abstract", "ConfDate", "ConfType", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "ReqStatus", "Disclosure", "StatusDate", "MDFLevel", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "Text", "Text", "User" }, filters: filters);
        if (Session["GridRequest"] == null)
            SessionUtility.AddSessionValue(key: "GridRequest", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "GridRequest", value: gridRequest);
        if (gridRequest.Rows.Count > 0)
        {
            DataView dv = new DataView(gridRequest);
            dv.Sort = "RequestID DESC";

            gvGroup.DataSource = dv;
            gvGroup.DataBind();
        }
        else
        {
            gvGroup.DataSource = null;
            gvGroup.DataBind();
        }
    }

    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("ExternalActivity", int.Parse(Session["_itemID"].ToString()));
        BindData();
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;

                LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
                lnkView.Text = dr["RequestID"].ToString();

                DropDownList ddlCoAuthor = e.Row.FindControl("ddlCoAuthor") as DropDownList;
                ddlCoAuthor.DataSource = _ws.getCoAuthor(new KeyValuePair<string, string>("Title", lnkView.Text.Trim()));
                ddlCoAuthor.DataBind();
                string authorName = ddlCoAuthor.Items[0].ToString();
                ddlCoAuthor.Items.RemoveAt(0);
                ddlCoAuthor.Items.Insert(0, authorName + " (A)");
            }
            catch (Exception ex)
            {
            }
        }
    }

}
