﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;
using System.IO;
using EAMSBusiness;
using System.Data;
using EAMSUtility;




public partial class PublUploadDocs : System.Web.UI.Page
{

    #region Private Variables
    Workshop _ws;
    RILUser _rilUser;
    ADService objAD;
    string _editItemID;
    #endregion

    #region Global Variable
    string requestId = string.Empty;
    string WFLevel = string.Empty;
    string _ExtUploadDocs = WebConfigurationManager.AppSettings["_ExtUploadDocs"].ToString();
    #endregion

    public void PopulatePageControls()
    {
        string listName = "ExternalActivity";
        string keyColumnName = "ID";
        string valueColumnName = "RequestID";
        Dictionary<string, string> populateDictionary = new Dictionary<string, string>();
        ddlRequestID.PopulateReqID_EXT_DOC(ws: _ws, listName: listName, listName2: "ExtUploadDocs", keyColumnName: keyColumnName, valueColumnName: valueColumnName, columnType: "Text", filter: new KeyValuePair<string, string>("EmpName", _ws.GetCurrentUserName()), containsFilter: "PUB");
    }
    public void PopulatePageControlsWithExisting()
    {
        //DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("GridRequest");
        //DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();
        //(from ListItem lst in ddlRequestID.Items where lst.Text == Convert.ToString(drGridRequest["Segment"]) select (lst.Selected = true)).ToList();
    }

    #region Event Handlers

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        _rilUser = new RILUser();
        objAD = new ADService();

        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }
        if (!IsPostBack)
        {
            PopulatePageControls();
            if (_editItemID != null)
            {
                PopulatePageControlsWithExisting();
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //Populate Other value
        WFLevel = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("ID", ddlRequestID.SelectedValue), "WFLevel");

        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("Title", ddlRequestID.SelectedItem.Text);
        filters.Add("AuthorType", "Lead-Author");
        DataTable gridAuthor = _ws.getListAsGrid(givelistName: "ExtEmpList", columns: new List<string>() { "ID", "EmailID" }, filterColumnType: new List<string>() { "Text", "Text" }, filters: filters);
        DataRow drgridAuthor = (from DataRow dr in gridAuthor.Rows select dr).FirstOrDefault<DataRow>();


        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExtUploadDocs");
            byte[] contentByteArray;
            string newfile = string.Empty;
            string fileName = string.Empty;

            if (fldFileUpload.HasFile)
            {
                contentByteArray = new byte[fldFileUpload.PostedFile.ContentLength];
                newfile = fldFileUpload.PostedFile.FileName;
                fileName = ddlRequestID.Text.Trim() + "_" + fldFileUpload.FileName;
            }
            else
            {
                contentByteArray = new byte[10 * 10];
                fileName = "XXXXX" + DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            fldFileUpload.PostedFile.InputStream.Read(contentByteArray, 0, fldFileUpload.PostedFile.ContentLength - 1);
            SP.File file = null;
            if (_editItemID == null)
            {
                SP.FileCreationInformation fci = new SP.FileCreationInformation();
                fci.Content = contentByteArray;
                fci.Overwrite = true;
                string fileExte = System.IO.Path.GetExtension(fldFileUpload.FileName);

                fci.Url = _ExtUploadDocs + fileName;
                file = list.RootFolder.Files.Add(fci);
                context.Load(file.ListItemAllFields);
                _ws.executeClientContext(context);

                string requestId = ddlRequestID.Text.Trim() + "-" + file.ListItemAllFields.Id.ToString("000");

                if (fldFileUpload.HasFile)
                    SetFileName(Id: file.ListItemAllFields.Id, fileName: requestId + "-" + fldFileUpload.FileName, context: context, list: list);
                file.ListItemAllFields["RequestID"] = requestId;
            }
            else
            {
                SP.ListItem item = list.GetItemById(_editItemID);
                context.Load(item, itemOld => itemOld.File);
                _ws.executeClientContext(context);
                //context.ExecuteQuery();
                file = item.File;
                if (fldFileUpload.HasFile)
                {
                    file.MoveTo(_ExtUploadDocs + fileName, SP.MoveOperations.Overwrite);
                    file.SaveBinary(new SP.FileSaveBinaryInformation { Content = contentByteArray });
                }
            }
            file.ListItemAllFields["RequestID"] = ddlRequestID.SelectedItem.Text;
            file.ListItemAllFields["JournalName"] = txtJournalName.Text;
            file.ListItemAllFields["VolumeNo"] = txtVolumeNo.Text;
            file.ListItemAllFields["DateOfPubl"] = txtDateOfPubl.Text;
            file.ListItemAllFields["PageNo"] = txtPageNo.Text;
            file.ListItemAllFields["WFLevel"] = WFLevel;
            file.ListItemAllFields["DelFlag"] = "0";
            file.ListItemAllFields["AuthorName"] = Convert.ToString(drgridAuthor["EmailID"]);
            file.ListItemAllFields["Requstor"] = _ws.GetCurrentUserEmail();
            file.ListItemAllFields["UpldDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
            file.ListItemAllFields.Update();
            _ws.executeClientContext(context);
            Response.Redirect("MyPublDocuments.aspx", true);
        }
    }
    protected void ddlRequestID_DataBound(object sender, EventArgs e)
    {
        ddlRequestID.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyPublDocuments.aspx", true);
    }
    protected void lnkAttachFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExtUploadDocs");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);

            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    protected void btnSuccess_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyPublDocuments.aspx", false);
    }
    public void SetFileName(int Id, string fileName, SP.ClientContext context, SP.List list)
    {
        SP.ListItem item = list.GetItemById(Id);
        context.Load(item, itemOld => itemOld.File);
        _ws.executeClientContext(context);
        SP.File file = item.File;
        if (fldFileUpload.HasFile)
        {
            file.MoveTo(_ExtUploadDocs + fileName, SP.MoveOperations.Overwrite);
        }
    }


    protected void ddlRequestID_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblTitle.Text = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("ID", ddlRequestID.SelectedValue), "Title");
            lblStatus.Text = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("ID", ddlRequestID.SelectedValue), "Status");

        }
        catch (Exception ex)
        {
        }
    }
}
