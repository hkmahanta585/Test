﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Configuration;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using EAMSBusiness;
using WebApplication1;
using System.Text;

public partial class MgrApprove : System.Web.UI.Page
{
    #region Private Members
    string _editItemID;
    string _level;
    Workshop _ws;
    int _wfLevel;
    string _role;
    string _IPClerReport = WebConfigurationManager.AppSettings["_IPClerReport"].ToString();
    #endregion

    #region Event Handlers
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }

        if (Request.QueryString["Level"] != null)
        {
            _level = Request.QueryString["Level"].ToString();
        }

        if (!Page.IsPostBack)
        {
            string listName = "ExtGradeList";
            string keyColumnName = "GradeKey";
            string valueColumnName = "Title";
            ddlGrade.Populateddl(_ws, listName, keyColumnName, valueColumnName, "Text", new KeyValuePair<string, string>("ActiveFlag", "Yes"));
        }
        if (!IsPostBack && _editItemID != null)
        {
            PopulatePageWithData();
        }
    }

    protected void lnkAttachedFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExternalActivity");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }

    protected void lnkIPCLReport_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("IPClerReport");

            SP.CamlQuery caml = new SP.CamlQuery();
            StringBuilder query = new StringBuilder(string.Empty);
            query.AppendFormat("<View><Query><Where><Eq><FieldRef Name = RequestID/><Value Type = 'Text'>{0}</Value></Eq></Where></Query></View>", lblRequestID.Text.Trim());
            caml.ViewXml = query.ToString();

            SP.ListItemCollection listItems = list.GetItems(caml);
            context.Load(listItems);
            _ws.executeClientContext(context);

            SP.ListItem item = listItems[0];
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    protected void btnApprove_Click(object sender, EventArgs e)
    {
        if (ddlStatus.SelectedItem.Text.Equals("Approved") && txtComment.Text.Length == 0 && !fldFileUpload.HasFile)
        {
            AddErrorMessage("Please enter comments and upload IP report.");
        }
        else if (ddlStatus.SelectedItem.Text.Equals("Approved") && txtComment.Text.Length == 0)
        {
            AddErrorMessage("Please enter comments.");
        }
        else if (ddlStatus.SelectedItem.Text.Equals("Approved") && !fldFileUpload.HasFile)
        {
            AddErrorMessage("Upload IP report.");
        }

        if (Page.IsValid)
        {
            using (SP.ClientContext context = _ws.getClientContext())
            {
                SP.Web site = context.Web;
                string listTitle;

                listTitle = "ExtCIPTFeedBack";
                _role = "by CIPT";

                SP.List list = site.Lists.GetByTitle(listTitle);
                SP.ListItemCreationInformation itemCreationInfo = new SP.ListItemCreationInformation();
                SP.ListItem item = list.AddItem(itemCreationInfo);
                item["Title"] = lblRequestID.Text;
                item["Status"] = ddlStatus.SelectedItem.Text;
                item["Comment"] = txtComment.Text;
                item.Update();
                _ws.executeClientContext(context);

                //Upload IP Clearance Report
                UploadIPCLReport();

                //Update status in Attendance Library (Main List)
                UpdateRequestStatus(context);
            }
            Response.Redirect("Summary.aspx");
        }
    }

    public void AddErrorMessage(string errorMessage)
    {
        var validator = new CustomValidator();
        validator.IsValid = false;
        validator.ErrorMessage = errorMessage;
        Page.Validators.Add(validator);
    }

    public void UploadIPCLReport()
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("IPClerReport");
            byte[] contentByteArray;
            string newfile = string.Empty;
            string fileName = string.Empty;

            if (fldFileUpload.HasFile)
            {
                contentByteArray = new byte[fldFileUpload.PostedFile.ContentLength];
                newfile = fldFileUpload.PostedFile.FileName;
                fileName = fldFileUpload.FileName;

                fldFileUpload.PostedFile.InputStream.Read(contentByteArray, 0, fldFileUpload.PostedFile.ContentLength - 1);
                SP.File file = null;

                SP.FileCreationInformation fci = new SP.FileCreationInformation();
                fci.Content = contentByteArray;
                fci.Overwrite = true;
                string fileExte = System.IO.Path.GetExtension(fldFileUpload.FileName);

                fci.Url = _IPClerReport + lblRequestID.Text + "_IPR_" + fileName;
                file = list.RootFolder.Files.Add(fci);
                context.Load(file.ListItemAllFields);
                _ws.DeleteMultipleItemByField("IPClerReport", "RequestID", lblRequestID.Text.Trim());
                _ws.executeClientContext(context);
                file.ListItemAllFields["RequestID"] = lblRequestID.Text;
                file.ListItemAllFields["AbsCLSReport"] = "Yes";
                file.ListItemAllFields.Update();
                _ws.executeClientContext(context);
            }
        }
    }

    #endregion

    #region Private Methods
    void PopulatePageWithData()
    {
        string EditMode = string.Empty;
        DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("GridRequest");
        DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();
        lblRequestID.Text = drGridRequest["RequestID"].ToString();

        gvStatus.DataSource = _ws.GetRequestStatusDetails(Convert.ToString(drGridRequest["RequestID"]));
        gvStatus.DataBind();


        lblSegment.Text = drGridRequest["Segment"].ToString();
        lblSector.Text = drGridRequest["Sector"].ToString();
        lblBusiness.Text = drGridRequest["Business"].ToString();
        lblSite.Text = drGridRequest["site"].ToString();

        lblTitle.Text = drGridRequest["Title"].ToString();



        rwDateOfConf.Visible = false;
        rwConfIs.Visible = false;
        if (!((Convert.ToString(drGridRequest["Category"]).Contains("PUB")) || (Convert.ToString(drGridRequest["Category"]).Length == 0)))
        {
            lblDateOfConf.Text = Convert.ToString(drGridRequest["ConfDate"]);
            lblConfIs.Text = (Convert.ToString(drGridRequest["ConfType"]).Contains("0") ? "National" : "International");
            rwDateOfConf.Visible = true;
            rwConfIs.Visible = true;
        }

        if (!string.IsNullOrEmpty(drGridRequest["Grade"].ToString()))
        {
            ddlGrade.Items.FindByText(drGridRequest["Grade"].ToString()).Selected = true;
        }

        lblCategory.Text = drGridRequest["Category"].ToString();
        if (drGridRequest["FileLeafRef"].ToString().ToLower().Contains("xxxxx"))
        {
            lnkAttachedFile.Text = string.Empty;
        }
        else
        {
            lnkAttachedFile.Text = drGridRequest["FileLeafRef"].ToString();
        }

        if (drGridRequest["IPCLReportName"].ToString().Length > 0)
        {
            lnkIpClReport.Text = drGridRequest["IPCLReportName"].ToString();
        }
        else
        {
            lnkIpClReport.Text = string.Empty;
        }

        lblApprover.Text = _ws.GetApprover(lblRequestID.Text, lblTitle.Text);

        lblAbstract.Text = drGridRequest["Abstract"].ToString();
        lblValue.Text = drGridRequest["RilValue"].ToString();
        lblConfDetail.Text = drGridRequest["JournalConfDetail"].ToString().Replace(";", "<br />"); 
        lblKeayReason.Text = drGridRequest["KeyReason"].ToString();
        _wfLevel = Int32.Parse(drGridRequest["WFLevel"].ToString());

        lblAprovPrestion.Text = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? "Abstract (Only for presentation)" : "Full Paper/Presentation (Final manuscript, Final presentation, award application, etc.)");

        lblTakingApproval1.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? true : false);
        lblTakingApproval2.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("2") ? true : false);

        Session["Grade"] = drGridRequest["Grade"].ToString();

        lblPatent.Text = (Convert.ToString(drGridRequest["Patent"]).Contains("0") ? "Yes" : (Convert.ToString(drGridRequest["Patent"]).Contains("1") ? "No" : "Don't Know"));
        lblA.Text = (Convert.ToString(drGridRequest["PatentA"]).Contains("0") ? "Yes" : "No");
        lblB.Text = (Convert.ToString(drGridRequest["PatentB"]).Contains("0") ? "Yes" : "No");
        lblC.Text = drGridRequest["PatentC"].ToString();
        lblD.Text = drGridRequest["PatentD"].ToString();
        lblE.Text = drGridRequest["PatentE"].ToString();
        lblAA.Text = drGridRequest["PatentF"].ToString();

        //------------------------------------------------
        EditMode = (drGridRequest["PatentA"].ToString().Length > 0 ? "A" : "");
        EditMode += (drGridRequest["PatentB"].ToString().Length > 0 ? "B" : "");
        EditMode += (drGridRequest["PatentC"].ToString().Length > 0 ? "C" : "");
        EditMode += (drGridRequest["PatentD"].ToString().Length > 0 ? "D" : "");
        EditMode += (drGridRequest["PatentE"].ToString().Length > 0 ? "E" : "");
        EditMode += (drGridRequest["PatentF"].ToString().Length > 0 ? "F" : "");
        lblEditMode.Text = EditMode;
        //------------------------------------------------
        Session["_wfLevel"] = _wfLevel.ToString();
        string disclosure = Convert.ToString(drGridRequest["Disclosure"]);
        /*rowA.Visible = false;
        rowB.Visible = false;
        rowC.Visible = false;
        rowD.Visible = false;
        rowE.Visible = false;
        rowF.Visible = false;
        rowG.Visible = false;*/
        rdbA.Enabled = false;
        rdbB.Enabled = false;
        rdbC.Enabled = false;
        rdbD.Enabled = false;
        rdbE.Enabled = false;
        rdbF.Enabled = false;
        rdbG.Enabled = false;

        switch (disclosure)
        {
            case "A":
                rdbA.Checked = true;
                //rowA.Visible = true;
                rowA.Style.Add("font-weight", "bold");
                break;
            case "B":
                rdbB.Checked = true;
                //rowB.Visible = true;
                rowB.Style.Add("font-weight", "bold");
                break;
            case "C":
                rdbC.Checked = true;
                //rowC.Visible = true;
                rowC.Style.Add("font-weight", "bold");
                break;
            case "D":
                rdbD.Checked = true;
                //rowD.Visible = true;
                rowD.Style.Add("font-weight", "bold");
                break;
            case "E":
                rdbE.Checked = true;
                //rowE.Visible = true;
                rowE.Style.Add("font-weight", "bold");
                break;
            case "F":
                rdbF.Checked = true;
                //rowF.Visible = true;
                rowF.Style.Add("font-weight", "bold");
                break;
            case "G":
                rdbG.Checked = true;
                //rowG.Visible = true;
                rowG.Style.Add("font-weight", "bold");
                break;
        }
        //------------------------------------------------

        //Following statement are used to fill grid view:
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters = new Dictionary<string, string>();
        filters.Add("Title", drGridRequest["RequestID"].ToString());
        DataTable ExtEmpGrid = _ws.getListAsGrid(givelistName: "ExtEmpList", columns: new List<string>() { "ID", "AuthorType", "AuthorName", "ECNo", "EmailID", "Reporting", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        gvEmp.DataSource = ExtEmpGrid;
        gvEmp.DataBind();

        filters.Clear();
        filters.Add("Title", drGridRequest["RequestID"].ToString());
        DataTable ExtNonEmpGrid = _ws.getListAsGrid(givelistName: "ExtNonEmpList", columns: new List<string>() { "ID", "CoAuthorName", "Orgnization", "EmailID", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        gvNonEmp.DataSource = ExtNonEmpGrid;
        gvNonEmp.DataBind();

        HideControls();
    }

    void HideControls()
    {
        string comment = _ws.GetFeedBack(listName: "ExtCIPTFeedBack", returnColumn: "Comment", requestID: lblRequestID.Text);
        string status = _ws.GetFeedBack(listName: "ExtCIPTFeedBack", returnColumn: "Status", requestID: lblRequestID.Text);

        if (status.Equals("Pending", StringComparison.OrdinalIgnoreCase) || status.Equals("Modify", StringComparison.OrdinalIgnoreCase) || string.IsNullOrEmpty(status))
        {

            ddlGrade.Visible = true;
            ddlStatus.Visible = true;
            txtComment.Visible = true;
            // ddlStatus.Items.FindByText(string.IsNullOrEmpty(status) ? "Pending" : status).Selected = true;
            //ddlStatus.SelectedItem.Text = string.IsNullOrEmpty(status) ? "Pending" : status;
            //  txtComment.Text = comment;
        }
        else
        {
            ddlGrade.Visible = false;
            ddlStatus.Visible = false;
            txtComment.Visible = false;
            divStatus.InnerText = status;
            divComment.InnerText = comment;
            divGrade.InnerText = string.IsNullOrEmpty(Convert.ToString(Session["Grade"])) ? "Pending" : "GRADE 1";
            btnApprove.Visible = false;
            btnReject.Text = "OK";
        }
    }

    void UpdateRequestStatus(SP.ClientContext context)
    {
        SP.List list = context.Web.Lists.GetByTitle("ExternalActivity");
        SP.ListItem item = list.GetItemById(_editItemID);
        context.Load(item, editItem => editItem["WFLevel"], editItem => editItem["Status"]);
        _ws.executeClientContext(context);


        switch (ddlStatus.SelectedItem.Text.ToLower())
        {
            case "pending":
                item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
                item["RStatus"] = "Open";
                item["draftFlag"] = "No";
                item["ReqStatus"] = "Pending " + _role;
                break;

            case "rejected":
                item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
                item["RStatus"] = "Closed";
                item["draftFlag"] = "No";
                item["ReqStatus"] = "Rejected " + _role;
                break;

            case "approved":
                item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString()) + 1;
                item["RStatus"] = "Open";
                item["draftFlag"] = "No";
                item["ReqStatus"] = "Approved " + _role;
                item["LevelFlag"] = "0";
                break;

            case "modify":
                item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
                item["RStatus"] = "Open";
                item["draftFlag"] = "Yes";
                item["ReqStatus"] = "Modification required (" + _role + ")";
                item["MDFLevel"] = Int32.Parse(item["WFLevel"].ToString());
                break;
        }

        item["EmailFlag"] = "CIPT";
        item["StatusDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
        item["Status"] = ddlStatus.SelectedItem.Text;
        item["Grade"] = (ddlStatus.SelectedItem.Text.Equals("Approved") ? ddlGrade.SelectedItem.Text : "");

        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("Title", ddlGrade.SelectedItem.Text);


        string[] gradeKeySet = ddlGrade.SelectedValue.ToString().Split(';')
            .Select(x => Convert.ToString(x)).ToArray();

        int LevelCount = (from string role in gradeKeySet where (role != string.Empty) select role).Count();

        int? noUser = null;
        int levelA = (0 < gradeKeySet.Length ? GetUserFromRole(Convert.ToString(gradeKeySet[0])) : 0);
        int levelB = (1 < gradeKeySet.Length ? GetUserFromRole(Convert.ToString(gradeKeySet[1])) : 0);
        int levelC = (2 < gradeKeySet.Length ? GetUserFromRole(Convert.ToString(gradeKeySet[2])) : 0);
        int levelD = (3 < gradeKeySet.Length ? GetUserFromRole(Convert.ToString(gradeKeySet[3])) : 0);
        int levelE = (4 < gradeKeySet.Length ? GetUserFromRole(Convert.ToString(gradeKeySet[4])) : 0);

        string levelARole = (0 < gradeKeySet.Length ? GetUserRoleFromRole(Convert.ToString(gradeKeySet[0])) : "");
        string levelBRole = (1 < gradeKeySet.Length ? GetUserRoleFromRole(Convert.ToString(gradeKeySet[1])) : "");
        string levelCRole = (2 < gradeKeySet.Length ? GetUserRoleFromRole(Convert.ToString(gradeKeySet[2])) : "");
        string levelDRole = (3 < gradeKeySet.Length ? GetUserRoleFromRole(Convert.ToString(gradeKeySet[3])) : "");
        string levelERole = (4 < gradeKeySet.Length ? GetUserRoleFromRole(Convert.ToString(gradeKeySet[4])) : "");


        item["LevelA"] = levelA > 0 ? levelA : noUser;
        item["LevelB"] = levelB > 0 ? levelB : noUser;
        item["LevelC"] = levelC > 0 ? levelC : noUser;
        item["LevelD"] = levelD > 0 ? levelD : noUser;
        item["LevelE"] = levelE > 0 ? levelE : noUser;

        item["LevelARole"] = levelARole;
        item["LevelBRole"] = levelBRole;
        item["LevelCRole"] = levelCRole;
        item["LevelDRole"] = levelDRole;
        item["LevelERole"] = levelERole;

        item["Comment"] = txtComment.Text;
        item["IPCLReportName"] = (fldFileUpload.FileName.Length > 0 ? fldFileUpload.FileName : lnkIpClReport.Text);
        item["GradeKey"] = Convert.ToString(ddlGrade.SelectedValue);
        item["LevelCount"] = LevelCount;
        item.Update();
        _ws.executeClientContext(context);
    }

    public int GetUserFromRole(string role)
    {
        int userID = 0;
        if (!string.IsNullOrEmpty(role))
        {
            switch (role)
            {
                case "R1":
                    userID = _ws.getUserFromList("ExternalActivity", new KeyValuePair<string, string>("ID", _editItemID), "TechSitePress").Id;
                    break;

                case "R2":
                    userID = _ws.getUserFromList("ExternalActivity", new KeyValuePair<string, string>("ID", _editItemID), "GMSHead").Id;
                    break;

                default:
                    var user = _ws.getUserFromList("ExtRoleList", new KeyValuePair<string, string>("RoleID", role), "RoleOwner").Id;
                    if (user > 0)
                    {
                        userID = int.Parse(Convert.ToString(user));
                    }
                    break;
            }
        }
        return userID;
    }


    public string GetUserRoleFromRole(string role)
    {
        string userRole = string.Empty;
        if (!string.IsNullOrEmpty(role))
        {
            userRole = _ws.getColumnValue("ExtRoleList", new KeyValuePair<string, string>("RoleID", role), "Title");
        }
        return (!string.IsNullOrEmpty(userRole) ? userRole : "");
    }

    #endregion

    protected void btnReject_Click(object sender, EventArgs e)
    {
        Response.Redirect("Summary.aspx");
    }

}