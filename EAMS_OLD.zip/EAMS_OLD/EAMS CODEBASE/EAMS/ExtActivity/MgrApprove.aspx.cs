﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Configuration;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using EAMSBusiness;
using WebApplication1;

public partial class MgrApprove : System.Web.UI.Page
{
    #region Private Members
    string _editItemID;
    string _level;
    Workshop _ws;
    int _wfLevel;
    string _role;
    string rflag = string.Empty;
    ADService service;

    #endregion

    #region Event Handlers
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        try
        {
            if (Request.QueryString["ID"] != null)
            {
                _editItemID = Request.QueryString["ID"].ToString();
            }
            if (Request.QueryString["Level"] != null)
            {
                _level = Request.QueryString["Level"].ToString();
            }
            if (!IsPostBack && _editItemID != null)
            {
                PopulatePageWithData();
            }
        }
        catch (Exception ex)
        {
            _ws.LogError("PageLoad Event :-" + ex.Message, Convert.ToString(Session["ERMassage"]));
        }
    }

    protected void lnkAttachedFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExternalActivity");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    protected void btnSuccess_Click(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["Redirect"]) == "True")
        {
            Response.Redirect("Summary.aspx");
        }
    }
    protected void btnApprove_Click(object sender, EventArgs e)
    {
        // _ws.LogError("Check 01 ; ", "Issue 1:-");
        try
        {
            bool flag = true;
            if (ddlPeers.SelectedItem.Text.Contains("Yes"))
            {
                //lblDomainID
                foreach (GridViewRow row in gvPeers.Rows)
                {
                    if (((Label)row.FindControl("lblCorrect")).Text.Contains("OK"))
                    {
                        // Session[row.RowIndex.ToString()] = ((Label)row.FindControl("lblDomainID")).Text;
                    }
                    if (((Label)row.FindControl("lblCorrect")).Text.Contains("Please") || ((Label)row.FindControl("lblECNo")).Text.Length == 0)
                    {
                        flag = false;
                        break;
                    }
                }
            }
            if (flag)
            {
                //_ws.LogError("Check 02 ; ", "Issue 1:-");
                using (SP.ClientContext context = _ws.getClientContext())
                {
                    SP.Web site = context.Web;
                    string listTitle;
                    switch (int.Parse(Session["_wfLevel"].ToString()))
                    {
                        case 0:
                            listTitle = "ExtMgrFeedback";
                            _role = "by L1";
                            break;
                        case 1:
                            listTitle = "HODFeedback";
                            _role = "by L1";
                            break;
                        case 2:
                            listTitle = "PlanNSFeedback";
                            _role = "by L1";
                            break;
                        default:
                            listTitle = "RNTFeedback";
                            break;
                    }

                    SP.List list = site.Lists.GetByTitle(listTitle);
                    SP.ListItemCreationInformation itemCreationInfo = new SP.ListItemCreationInformation();
                    SP.ListItem item = list.AddItem(itemCreationInfo);
                    item["Title"] = lblRequestID.Text;
                    item["Status"] = ddlStatus.SelectedItem.Text;
                    item["Comment"] = txtComment.Text;

                    // _ws.LogError("Check 1 ; ", "Issue 1:-");

                    item.Update();
                    _ws.executeClientContext(context);
                    // _ws.LogError("Check 2 ; ", "Issue 1:-");
                    //Update status in Attendance Library (Main List)
                    UpdateRequestStatus(context);
                    // _ws.LogError("Check 3 ; ", "Issue 1:-");
                }
                Session["Redirect"] = "True";
                msgHeadings.Text = "Information!";
                msgBody.Text = "Record is saved..";
                this.mdlSuccess.Show();
            }
            else
            {
                Session["Redirect"] = "False";
                msgHeadings.Text = "Error!";
                msgBody.Text = "Please enter valid peer's name..";
                this.mdlSuccess.Show();
            }
        }
        catch (Exception ex)
        {
            _ws.LogError("Fun Name - btnApprove_Click() :-", "Issue 1:-" + ex.Message + "   Issue 2:-" + Convert.ToString(Session["ERMassage"]));
            // msgHeadings.Text = "Error!";
            //  msgBody.Text = "Fun Name : - btnApprove_Click(); " + ex.Message;
            // this.mdlSuccess.Show();
        }
    }
    #endregion

    #region Private Methods
    void PopulatePageWithData()
    {
        string EditMode = string.Empty;
        DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("GridRequest");
        DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();
        lblRequestID.Text = drGridRequest["RequestID"].ToString();

        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("Title", lblRequestID.Text.Trim());

        DataTable dtPeers = _ws.getListAsGrid(givelistName: "ExtPeersList", columns: new List<string>() { "ID", "Title", "DomainID", "DisName", "IsValid", "ECNo", "Email" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        if (dtPeers.Rows.Count > 0)
        {
            gvPeers.DataSource = dtPeers;
            gvPeers.DataBind();
        }
        else
        {
            gvPeers.DataSource = getPeersName();
            gvPeers.DataBind();
        }

        ddlPeers.Items.FindByText("Yes").Selected = (Convert.ToString(drGridRequest["PeerStatus"]).Contains("Yes") ? true : false);

        lblSegment.Text = drGridRequest["Segment"].ToString();
        lblSector.Text = drGridRequest["Sector"].ToString();
        lblBusiness.Text = drGridRequest["Business"].ToString();
        lblSite.Text = drGridRequest["site"].ToString();
        lblTitle.Text = drGridRequest["Title"].ToString();
        lblCategory.Text = drGridRequest["Category"].ToString();
        if (drGridRequest["FileLeafRef"].ToString().ToLower().Contains("xxxxx"))
        {
            lnkAttachedFile.Text = string.Empty;
        }
        else
        {
            lnkAttachedFile.Text = drGridRequest["FileLeafRef"].ToString();
        }

        lblConfDetail.Text = drGridRequest["JournalConfDetail"].ToString().Replace(";", "<br />");

        lblAbstract.Text = drGridRequest["Abstract"].ToString();
        lblValue.Text = drGridRequest["RilValue"].ToString();
        lblKeayReason.Text = drGridRequest["KeyReason"].ToString();
        _wfLevel = Int32.Parse(drGridRequest["WFLevel"].ToString());

        rflag = drGridRequest["RFlag"].ToString();

        lblAprovPrestion.Text = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? "Abstract (Only for presentation)" : "Full Paper/Presentation (Final manuscript, Final presentation, award application, etc.)");

        lblApprover.Text = _ws.GetApprover(lblRequestID.Text, lblTitle.Text);

        lblTakingApproval1.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? true : false);
        lblTakingApproval2.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("2") ? true : false);

        rwDateOfConf.Visible = false;
        rwConfIs.Visible = false;
        if (!((Convert.ToString(drGridRequest["Category"]).Contains("PUB")) || (Convert.ToString(drGridRequest["Category"]).Length == 0)))
        {
            lblDateOfConf.Text = Convert.ToString(drGridRequest["ConfDate"]);
            lblConfIs.Text = (Convert.ToString(drGridRequest["ConfType"]).Contains("0") ? "National" : "International");
            rwDateOfConf.Visible = true;
            rwConfIs.Visible = true;
        }

        string disclosure = Convert.ToString(drGridRequest["Disclosure"]);
        /*rowA.Visible = false;
        rowB.Visible = false;
        rowC.Visible = false;
        rowD.Visible = false;
        rowE.Visible = false;
        rowF.Visible = false;
        rowG.Visible = false;*/
        rdbA.Enabled = false;
        rdbB.Enabled = false;
        rdbC.Enabled = false;
        rdbD.Enabled = false;
        rdbE.Enabled = false;
        rdbF.Enabled = false;
        rdbG.Enabled = false;

        switch (disclosure)
        {
            case "A":
                rdbA.Checked = true;
                //rowA.Visible = true;
                rowA.Style.Add("font-weight", "bold");
                break;
            case "B":
                rdbB.Checked = true;
                //rowB.Visible = true;
                rowB.Style.Add("font-weight", "bold");
                break;
            case "C":
                rdbC.Checked = true;
                //rowC.Visible = true;
                rowC.Style.Add("font-weight", "bold");
                break;
            case "D":
                rdbD.Checked = true;
                //rowD.Visible = true;
                rowD.Style.Add("font-weight", "bold");
                break;
            case "E":
                rdbE.Checked = true;
                //rowE.Visible = true;
                rowE.Style.Add("font-weight", "bold");
                break;
            case "F":
                rdbF.Checked = true;
                //rowF.Visible = true;
                rowF.Style.Add("font-weight", "bold");
                break;
            case "G":
                rdbG.Checked = true;
                //rowG.Visible = true;
                rowG.Style.Add("font-weight", "bold");
                break;
        }

        lblPatent.Text = (Convert.ToString(drGridRequest["Patent"]).Contains("0") ? "Yes" : (Convert.ToString(drGridRequest["Patent"]).Contains("1") ? "No" : "Don't Know"));
        lblA.Text = (Convert.ToString(drGridRequest["PatentA"]).Contains("0") ? "Yes" : "No");
        lblB.Text = (Convert.ToString(drGridRequest["PatentB"]).Contains("0") ? "Yes" : "No");
        lblC.Text = drGridRequest["PatentC"].ToString();
        lblD.Text = drGridRequest["PatentD"].ToString();
        lblE.Text = drGridRequest["PatentE"].ToString();
        lblAA.Text = drGridRequest["PatentF"].ToString();

        //------------------------------------------------
        EditMode = (drGridRequest["PatentA"].ToString().Length > 0 ? "A" : "");
        EditMode += (drGridRequest["PatentB"].ToString().Length > 0 ? "B" : "");
        EditMode += (drGridRequest["PatentC"].ToString().Length > 0 ? "C" : "");
        EditMode += (drGridRequest["PatentD"].ToString().Length > 0 ? "D" : "");
        EditMode += (drGridRequest["PatentE"].ToString().Length > 0 ? "E" : "");
        EditMode += (drGridRequest["PatentF"].ToString().Length > 0 ? "F" : "");
        lblEditMode.Text = EditMode;
        //------------------------------------------------
        //txtPeers1.Text = drGridRequest["PeerName1"].ToString();
        //txtPeers2.Text = drGridRequest["PeerName2"].ToString();
        //txtPeers3.Text = drGridRequest["PeerName3"].ToString();

        Session["_wfLevel"] = _wfLevel.ToString();

        //Following statement are used to fill grid view:

        filters.Clear();
        filters = new Dictionary<string, string>();
        filters.Add("Title", drGridRequest["RequestID"].ToString());
        DataTable ExtEmpGrid = _ws.getListAsGrid(givelistName: "ExtEmpList", columns: new List<string>() { "ID", "AuthorType", "AuthorName", "ECNo", "EmailID", "Reporting", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        gvEmp.DataSource = ExtEmpGrid;
        gvEmp.DataBind();

        filters.Clear();
        filters.Add("Title", drGridRequest["RequestID"].ToString());
        DataTable ExtNonEmpGrid = _ws.getListAsGrid(givelistName: "ExtNonEmpList", columns: new List<string>() { "ID", "CoAuthorName", "Orgnization", "EmailID", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        gvNonEmp.DataSource = ExtNonEmpGrid;
        gvNonEmp.DataBind();

        HideControls();
    }

    void HideControls()
    {
        string comment = string.Empty;
        string status = string.Empty;
        //switch (wFLevel)
        switch (_level.Trim().ToUpper())
        {
            case "MGR":
                comment = _ws.GetFeedBack(listName: "ExtMgrFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "ExtMgrFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
            case "HOD":
                comment = _ws.GetFeedBack(listName: "HODFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "HODFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
            case "PLAN":
                comment = _ws.GetFeedBack(listName: "PlanNSFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "PlanNSFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
            case "RNT":
                comment = _ws.GetFeedBack(listName: "RNTFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                status = _ws.GetFeedBack(listName: "RNTFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                break;
        }

        if (status.Equals("Pending", StringComparison.OrdinalIgnoreCase) || status.Equals("Modify", StringComparison.OrdinalIgnoreCase) || string.IsNullOrEmpty(status))
        {

            ddlStatus.Visible = true;
            txtComment.Visible = true;
            //ddlStatus.Items.FindByText(string.IsNullOrEmpty(status) ? "Pending" : status).Selected = true;
            // txtComment.Text = comment;
        }
        else
        {
            ddlStatus.Visible = false;
            txtComment.Visible = false;
            divStatus.InnerText = status;
            divComment.InnerText = comment;
            btnApprove.Visible = false;
            btnReject.Text = "OK";
        }

    }

    void UpdateRequestStatus(SP.ClientContext context)
    {
        try
        {
            //_ws.LogError("UpdateRequestStatus(); Check 4 ; ", "Issue 1:-");
            string reqStatus = string.Empty;
            string draftFlag = string.Empty;
            string rStatus = string.Empty;
            int mdfLevel = 0;
            int wfLevel = 0;

            SP.List list = context.Web.Lists.GetByTitle("ExternalActivity");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, editItem => editItem["WFLevel"], editItem => editItem["Status"]);
            _ws.executeClientContext(context);

            rflag = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("ID", _editItemID), "RFlag");
            string rntFlag = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("ID", _editItemID), "RNTFlag");

            SP.Web site = context.Web;
            switch (ddlStatus.SelectedItem.Text.ToLower())
            {
                case "pending":
                    wfLevel = Int32.Parse(item["WFLevel"].ToString());
                    rStatus = "Open";
                    reqStatus = "Pending " + _role;
                    break;

                case "rejected":
                    wfLevel = Int32.Parse(item["WFLevel"].ToString());
                    rStatus = "Closed";
                    reqStatus = "Rejected " + _role;
                    break;

                case "approved":
                    if (rflag.Equals("SITE") && rntFlag.Equals("No"))
                    {
                        wfLevel = Int32.Parse(item["WFLevel"].ToString()) + 2;
                        rStatus = "Open";
                        reqStatus = "Approved by Site Functional Head";
                        
                        //Update Site Fun Head Status
                        SP.List list1 = site.Lists.GetByTitle("ExtSiteFHead");
                        SP.ListItemCreationInformation itemCreationInfo = new SP.ListItemCreationInformation();
                        SP.ListItem item1 = list1.AddItem(itemCreationInfo);
                        item1["Title"] = lblRequestID.Text;
                        item1["Status"] = ddlStatus.SelectedItem.Text;
                        item1["Comment"] = txtComment.Text;
                        item1.Update();
                        _ws.executeClientContext(context);
                    }
                    else if (rflag.Equals("COE"))
                    {
                        wfLevel = Int32.Parse(item["WFLevel"].ToString()) + 2;
                        rStatus = "Open";
                        reqStatus = "Approved by COE Functional Head";

                        //Update COE Fun Head Status
                        SP.List list1 = site.Lists.GetByTitle("ExtCOEFHead");
                        SP.ListItemCreationInformation itemCreationInfo = new SP.ListItemCreationInformation();
                        SP.ListItem item1 = list1.AddItem(itemCreationInfo);
                        item1["Title"] = lblRequestID.Text;
                        item1["Status"] = ddlStatus.SelectedItem.Text;
                        item1["Comment"] = txtComment.Text;
                        item1.Update();
                        _ws.executeClientContext(context);
                        //_ws.LogError("Check 8 ; ", "Issue 1:-");
                    }
                    else
                    {
                        wfLevel = Int32.Parse(item["WFLevel"].ToString()) + 1;
                        rStatus = "Open";
                        reqStatus = "Approved " + _role;
                    }
                    break;

                case "modify":
                    wfLevel = Int32.Parse(item["WFLevel"].ToString());
                    rStatus = "Open";
                    draftFlag = "Yes";
                    reqStatus = "Modification required (" + _role + ")";
                    mdfLevel = Int32.Parse(item["WFLevel"].ToString());
                    break;
            }

            if (ddlPeers.SelectedItem.Text.Contains("Yes"))
            {
                foreach (GridViewRow row in gvPeers.Rows)
                {
                    Session[row.RowIndex.ToString()] = ((Label)row.FindControl("lblDomainID")).Text;
                }
                item["PeerName1"] = _ws.GetUser(Session["1"].ToString()).Id;
                item["PeerName2"] = _ws.GetUser(Session["1"].ToString()).Id;
                item["PeerName3"] = _ws.GetUser(Session["2"].ToString()).Id;
                _ws.DeleteMultipleItem("ExtPeersList", "Title", lblRequestID.Text.Trim());
                UpdatePeersList(context);
                //_ws.LogError("Check 10 ; ", "Issue 1:-" + Convert.ToString(Session["ERMassage"]));
            }
            else
            {
                _ws.DeleteMultipleItem("ExtPeersList", "Title", lblRequestID.Text.Trim());
            }

            if (wfLevel > 0)
                item["WFLevel"] = wfLevel;

            if (rStatus.Length > 0)
                item["RStatus"] = rStatus;

            if (draftFlag.Length > 0)
                item["draftFlag"] = draftFlag;

            if (reqStatus.Length > 0)
                item["ReqStatus"] = reqStatus;

            if (mdfLevel >= 0)
                item["MDFLevel"] = mdfLevel;

            item["StatusDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
            item["Status"] = ddlStatus.SelectedItem.Text;
            item["PeerStatus"] = ddlPeers.SelectedItem.Text;
            item["Comment"] = txtComment.Text;
            item["EmailFlag"] = "Manager";
            item["ReqStatus"] = reqStatus;

            item.Update();
            Session.Remove("Status");
            _ws.executeClientContext(context);
        }
        catch (Exception ex)
        {
            _ws.LogError("Fun Name - UpdateRequestStatus() :-", "Issue 1:-" + ex.Message + "   Issue 2:-" + Convert.ToString(Session["ERMassage"]));
        }
    }

    void UpdatePeersList(SP.ClientContext context)
    {

        try
        {
            SP.List list = context.Web.Lists.GetByTitle("ExtPeersList");

            foreach (GridViewRow row in gvPeers.Rows)
            {
                SP.ListItemCreationInformation itemCreationInfo = new SP.ListItemCreationInformation();
                SP.ListItem item = list.AddItem(itemCreationInfo);

                item["Title"] = lblRequestID.Text.Trim();
                item["ECNo"] = ((Label)row.FindControl("lblECNo")).Text;
                item["DomainID"] = ((Label)row.FindControl("lblDomainID")).Text;
                item["DisName"] = ((TextBox)row.FindControl("txtPeersName")).Text;
                item["Email"] = ((Label)row.FindControl("lblEmailID")).Text;
                item["IsValid"] = ((Label)row.FindControl("lblCorrect")).Text;

                item.Update();
                _ws.executeClientContext(context);

            }
        }
        catch (Exception ex)
        {
            _ws.LogError("Fun Name - UpdatePeersList() :-", "Issue 1:-" + ex.Message + "   Issue 2:-" + Convert.ToString(Session["ERMassage"]));
            //msgHeadings.Text = "Error!";
            //msgBody.Text = "Fun Name :- UpdatePeersList(); " + ex.Message + "---" + Convert.ToString(Session["ERMassage"]);
            //this.mdlSuccess.Show();
        }

    }
    #endregion

    protected void txtPeersName_OnTextChange(object sender, EventArgs e)
    {
        service = new ADService();
        GridViewRow currentRow = (GridViewRow)((TextBox)sender).Parent.Parent;

        TextBox txtPeersName = ((TextBox)sender);
        string peersname = txtPeersName.Text;
        Label lblECNo = (Label)currentRow.FindControl("lblECNo");
        Label lblEmailID = (Label)currentRow.FindControl("lblEmailID");
        Label lblDomainID = (Label)currentRow.FindControl("lblDomainID");
        Label lblCorrect = (Label)currentRow.FindControl("lblCorrect");
        try
        {
            string[] EmployeeSet = (Session["EmployeeSet"] != null ? (string[])Session["EmployeeSet"] : null);
            string empDomainName = (from name in EmployeeSet where name.Contains(peersname) select name).FirstOrDefault<string>();

            DataTable dtProfile = null;

            string userName = WebConfigurationManager.AppSettings["UserName"].ToString();
            string password = WebConfigurationManager.AppSettings["Password"].ToString();

            try
            {
                using (new Impersonation("IN", userName, password))
                {
                    dtProfile = service.getUserDetailsByDomainId(empDomainName.Substring(0, empDomainName.IndexOf("[")));
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Mgr Approve :-" + ex.Message, ex.ToString());
            }

            lblDomainID.Text = dtProfile.Rows[0]["domainId"].ToString();
            lblECNo.Text = dtProfile.Rows[0]["employeeId"].ToString();
            lblEmailID.Text = dtProfile.Rows[0]["email"].ToString();
            lblCorrect.Text = "OK";
            txtPeersName.BorderColor = System.Drawing.ColorTranslator.FromHtml("#DEDFDE");
            currentRow.ForeColor = System.Drawing.ColorTranslator.FromHtml("#393839");

        }
        catch (Exception)
        {
            lblECNo.Text = "--------";
            lblEmailID.Text = "--------";
            lblCorrect.Text = "Please check again.";
            txtPeersName.BorderColor = System.Drawing.Color.Red;
            currentRow.ForeColor = System.Drawing.Color.Red;
            txtPeersName.Focus();
        }
    }

    protected void btnReject_Click(object sender, EventArgs e)
    {
        Response.Redirect("Summary.aspx");
    }

    public DataTable getPeersName()
    {
        DataTable dt = new DataTable();
        DataRow dr, dr1, dr2;

        dt.Columns.Add("ID");
        dt.Columns.Add("DisName");
        dt.Columns.Add("ECNo");
        dt.Columns.Add("DomainID");
        dt.Columns.Add("Email");
        dt.Columns.Add("IsValid");


        dr = dt.NewRow();
        dr["ID"] = "";
        dr["DisName"] = "";
        dr["ECNo"] = "";
        dr["DomainID"] = "";
        dr["Email"] = "";
        dr["IsValid"] = "";
        dt.Rows.Add(dr);

        dr1 = dt.NewRow();
        dr["ID"] = "";
        dr["DisName"] = "";
        dr["ECNo"] = "";
        dr["DomainID"] = "";
        dr["Email"] = "";
        dr["IsValid"] = "";
        dt.Rows.Add(dr1);

        dr2 = dt.NewRow();
        dr["ID"] = "";
        dr["DisName"] = "";
        dr["ECNo"] = "";
        dr["DomainID"] = "";
        dr["Email"] = "";
        dr["IsValid"] = "";
        dt.Rows.Add(dr2);


        return dt;
    }
    //protected void btnShowPopup_Click(object sender, EventArgs e)
    //{
    //    string message = "Message from server side";
    //    ClientScript.RegisterStartupScript(this.GetType(), "Popup", "ShowPopup('" + message + "');", true);

    //}
}