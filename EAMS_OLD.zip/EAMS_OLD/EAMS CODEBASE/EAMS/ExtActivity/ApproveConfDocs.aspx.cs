﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;

public partial class MyConfDocuments : System.Web.UI.Page
{
    Workshop _ws;
    //string _itemID;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (!Page.IsPostBack)
        {
            BindData();
        }
    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        Session["ID"] = e.CommandArgument.ToString();
        switch (e.CommandName.Trim().ToUpper())
        {
            case "DELETE":
                lblMassage.Text = "Are you sure you want to delete this doc.?";
                this.mdlModelDialog.Show();
                break;

                case "REDIRECT":
                Response.Redirect("ConfDocsDetails.aspx");
                break;
        }
    }

    protected void lnkFileName_Click(object sender, EventArgs e)
    {
        LinkButton button = (LinkButton)sender;
        GridViewRow row = (GridViewRow)button.NamingContainer;
        if (row != null)
        {
            string itemID = ((LinkButton)sender).CommandArgument.ToString();
            Session["ID"] = itemID;
            DownloadDocument();
        }
    }

    protected void chkApprove_checked(object sender, EventArgs e)
    {
        //int selRowIndex = ((GridViewRow)(((CheckBox)sender).Parent.Parent.Parent.Parent)).RowIndex;
        //string ID = gvGroup.DataKeys[selRowIndex].Value.ToString();

        //CheckBox chkApprove = (CheckBox)sender;
        //if (chkApprove.Checked)
        //{
        //    _ws.UpdateExtConfDocStaus("ExtConfDocs", ID, "True");
        //}
        //else
        //{
        //    _ws.UpdateExtConfDocStaus("ExtConfDocs", ID, "False");
        //}
        //BindData();
    }

    protected void chkChecked_checked(object sender, EventArgs e)
    {
        int selRowIndex = ((GridViewRow)(((CheckBox)sender).Parent.Parent.Parent.Parent)).RowIndex;
        string ID = gvGroup.DataKeys[selRowIndex].Value.ToString();

        CheckBox chkChecked = (CheckBox)sender;
        if (chkChecked.Checked)
        {
            _ws.UpdateExtCheckInOutHistory("ExtConfDocs", ID, _ws.GetCurrentUserEmail(), "True");
        }
        else
        {
            _ws.UpdateExtCheckInOutHistory("ExtConfDocs", ID, _ws.GetCurrentUserEmail(), "False");
        }
        BindData();
    }

    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        //if (_ws.IsInGroup(20043))
        if (_ws.IsInCIPT(_ws.GetCurrentUserID()))
        {
            filters.Add("DelFlag", "0");
            filters.Add("Approve", "ABC");
            DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExtConfDocs", columns: new List<string>() { "ID", "Requstor", "UpldDate", "RequestID", "FileLeafRef", "Approve", "CheckedBy", "CheckOut" }, filterColumnType: new List<string>() { "Text", "Text" }, filters: filters);
            gvGroup.DataSource = gridRequest;
            gvGroup.DataBind();

            if (Session["GridRequest"] == null)
                SessionUtility.AddSessionValue(key: "GridRequest", value: gridRequest);
            else
                SessionUtility.UpdateSessionValue(key: "GridRequest", value: gridRequest);
        }
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("ExtConfDocs", int.Parse(Session["ID"].ToString()));
        BindData();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        // _ws.DeleteItem("WorkshopDocs", int.Parse(Session["_itemID"].ToString()));
        // BindData();
    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        //_ws.DeleteItem("WorkshopDocs", int.Parse(Session["_itemID"].ToString()));
        // BindData();
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;
                Label lblApprove = e.Row.FindControl("lblApprove") as Label;
                lblApprove.Text = (Convert.ToString(dr["Approve"]).Contains("Approve") ? "Approved" : "Pending");

                CheckBox chkApprove = e.Row.FindControl("chkApprove") as CheckBox;
                LinkButton lnkRequestID = e.Row.FindControl("lnkRequestID") as LinkButton;

                Label lblCheckedBy = e.Row.FindControl("lblCheckedBy") as Label;
                Label lblChecked = e.Row.FindControl("lblChecked") as Label;
                CheckBox chkChecked = e.Row.FindControl("chkChecked") as CheckBox;

                if (lblApprove.Text.Equals("Pending"))
                {
                    if (lblChecked.Text.Equals("True"))
                    {
                        lnkRequestID.Enabled = true;
                        chkChecked.Checked = true;
                    }
                    else
                    {
                        lnkRequestID.Enabled = false;
                    }
                    lblCheckedBy.Visible = false;
                    lblApprove.Visible = true;
                    chkApprove.Visible = false;
                }
                else
                {
                    lnkRequestID.Enabled = false;
                    if (lblChecked.Text.Equals("True"))
                    {
                        if (lblCheckedBy.Text.Contains(_ws.GetCurrentUserEmail()))
                        {
                            chkChecked.Visible = true;
                            chkChecked.Checked = true;
                            lnkRequestID.Enabled = true;
                            lblApprove.Visible = false;
                            lblCheckedBy.Visible = false;
                        }
                        else
                        {

                            chkChecked.Visible = false;
                            //chkApprove.Visible = false;
                            lnkRequestID.Enabled = false;
                            lblApprove.Visible = true;
                            lblCheckedBy.Visible = true;
                        }
                    }
                    else
                    {
                        chkChecked.Visible = true;
                        lnkRequestID.Visible = true;
                        lblApprove.Enabled = false;
                        lblCheckedBy.Visible = false;
                    }
                }
            }
            catch (Exception)
            {
            }
        }

    }

    public void DownloadDocument()
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExtConfDocs");
            SP.ListItem item = list.GetItemById(int.Parse(Session["ID"].ToString()));
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            //context.ExecuteQuery();
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);

            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }

}
