﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;

public partial class LevelView : System.Web.UI.Page
{
    Workshop _ws;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        BindData();
    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "View")
        {
            GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
            Label lblGradeKey = row.FindControl("lblGradeKey") as Label;
            string[] keys = lblGradeKey.Text.Split(';');
            string levelFlag = (e.CommandArgument.ToString().Trim().Length > 0 ? e.CommandArgument.ToString() : "0");
            string statusKey = keys[int.Parse(levelFlag)];
            Session["LevelKey"] = statusKey;
            Session["LevelFlag"] = Convert.ToString(e.CommandArgument);
            Session["ID"] = gvGroup.DataKeys[row.RowIndex].Value.ToString();
            Response.Redirect("LevelApprove.aspx", true);
        }

    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();

        filters.Add("LevelA", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "0");
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "DisclosureType", "DisclosureDef", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "LevelFlag", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "GradeKey", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        filters.Clear();
        filters.Add("LevelB", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "1");
        DataTable gridRequest1 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "DisclosureType", "DisclosureDef", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "LevelFlag", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "GradeKey", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        filters.Clear();
        filters.Add("LevelC", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "2");
        DataTable gridRequest2 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "DisclosureType", "DisclosureDef", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "LevelFlag", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "GradeKey", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        filters.Clear();
        filters.Add("LevelD", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "3");
        DataTable gridRequest3 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "DisclosureType", "DisclosureDef", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "LevelFlag", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "GradeKey", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        filters.Clear();
        filters.Add("LevelE", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "4");
        DataTable gridRequest4 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "DisclosureType", "DisclosureDef", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "LevelFlag", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "GradeKey", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);


        gridRequest.Merge(gridRequest1);
        gridRequest.Merge(gridRequest2);
        gridRequest.Merge(gridRequest3);
        gridRequest.Merge(gridRequest4);

        if (Session["GridRequest"] == null)
            SessionUtility.AddSessionValue(key: "GridRequest", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "GridRequest", value: gridRequest);

        DataView dv = new DataView(gridRequest);
        dv.Sort = "ID DESC";

        gvGroup.DataSource = dv;
        gvGroup.DataBind();
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;
                LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
                lnkView.Text = dr["RequestID"].ToString();
                DropDownList ddlCoAuthor = e.Row.FindControl("ddlCoAuthor") as DropDownList;
                ddlCoAuthor.DataSource = _ws.getCoAuthor(new KeyValuePair<string, string>("Title", lnkView.Text.Trim()));
                ddlCoAuthor.DataBind();
                ddlCoAuthor.Items.RemoveAt(0);
                ddlCoAuthor.Items.Insert(0, Convert.ToString(dr[1]) + " (A)");
            }
            catch (Exception)
            {
            }
        }
    }
}