﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;
using System.IO;
using EAMSBusiness;
using System.Data;
using EAMSUtility;




public partial class PublUploadDocs : System.Web.UI.Page
{

    #region Private Variables
    Workshop _ws;
    RILUser _rilUser;
    ADService objAD;
    string _editItemID;
    #endregion

    #region Global Variable
    string requestId = string.Empty;
    string _ExtConfDocs = WebConfigurationManager.AppSettings["_ExtConfDocs"].ToString();
    #endregion

    public void PopulatePageControls()
    {
        string listName = "ExternalActivity";
        string keyColumnName = "ID";
        string valueColumnName = "RequestID";
        if (!string.IsNullOrEmpty(_editItemID))
            ddlRequestID.PopulateReqID_PRE(ws: _ws, listName: listName, keyColumnName: keyColumnName, valueColumnName: valueColumnName, columnType: "Text", filter: new KeyValuePair<string, string>("EmpName", _ws.GetCurrentUserName()), containsFilter: "PRE");
        else
            ddlRequestID.PopulateReqID_EXT_DOC_PRE(ws: _ws, listName: listName, listName2: "ExtConfDocs", keyColumnName: keyColumnName, valueColumnName: valueColumnName, columnType: "Text", filter: new KeyValuePair<string, string>("EmpName", _ws.GetCurrentUserName()), containsFilter: "PRE");
    }
    public void PopulatePageControlsWithExisting()
    {
        try
        {
            ddlRequestID.Items.FindByText(Request.QueryString["ReqID"].ToString()).Selected = true;
            lblTitle.Text = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("RequestID", Request.QueryString["ReqID"].ToString()), "Title");
            lblStatus.Text = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("RequestID", Request.QueryString["ReqID"].ToString()), "Status");
            lblComments.Text = _ws.getColumnValue("ExtConfDocs", new KeyValuePair<string, string>("RequestID", Request.QueryString["ReqID"].ToString()), "Comment");
            ddlRequestID.Enabled = false;
        }
        catch (Exception ex)
        {
        }
    }

    #region Event Handlers

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        _rilUser = new RILUser();
        objAD = new ADService();

        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }
        if (!IsPostBack)
        {
            PopulatePageControls();
            statusCol.Visible = false;
            if (_editItemID != null)
            {
                statusCol.Visible = true;
                PopulatePageControlsWithExisting();
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (!fldFileUpload.HasFile)
        {
            AddErrorMessage("Please upload the Final Presentation.");
        }

        if (Page.IsValid)
        {
            using (SP.ClientContext context = _ws.getClientContext())
            {
                SP.Web site = context.Web;
                SP.List list = site.Lists.GetByTitle("ExtConfDocs");
                byte[] contentByteArray;
                string newfile = string.Empty;
                string fileName = string.Empty;

                if (fldFileUpload.HasFile)
                {
                    contentByteArray = new byte[fldFileUpload.PostedFile.ContentLength];
                    newfile = fldFileUpload.PostedFile.FileName;
                    fileName = ddlRequestID.Text.Trim() + "_" + fldFileUpload.FileName;
                }
                else
                {
                    contentByteArray = new byte[10 * 10];
                    fileName = "XXXXX" + DateTime.Now.ToString("yyyyMMddHHmmss");
                }
                fldFileUpload.PostedFile.InputStream.Read(contentByteArray, 0, fldFileUpload.PostedFile.ContentLength - 1);
                SP.File file = null;
                if (_editItemID == null)
                {
                    SP.FileCreationInformation fci = new SP.FileCreationInformation();
                    fci.Content = contentByteArray;
                    fci.Overwrite = true;
                    string fileExte = System.IO.Path.GetExtension(fldFileUpload.FileName);

                    fci.Url = _ExtConfDocs + fileName;
                    file = list.RootFolder.Files.Add(fci);
                    context.Load(file.ListItemAllFields);
                    _ws.executeClientContext(context);
                    //string requestId = Session["ConfID"].ToString() + "-" + file.ListItemAllFields.Id.ToString("000");
                    string requestId = ddlRequestID.Text.Trim() + "-" + file.ListItemAllFields.Id.ToString("000");

                    if (fldFileUpload.HasFile)
                        SetFileName(Id: file.ListItemAllFields.Id, fileName: requestId + "-" + fldFileUpload.FileName, context: context, list: list);
                    file.ListItemAllFields["RequestID"] = requestId;
                }
                else
                {
                    SP.ListItem item = list.GetItemById(_editItemID);
                    context.Load(item, itemOld => itemOld.File);
                    _ws.executeClientContext(context);
                    //context.ExecuteQuery();
                    file = item.File;
                    if (fldFileUpload.HasFile)
                    {
                        file.MoveTo(_ExtConfDocs + fileName, SP.MoveOperations.Overwrite);
                        file.SaveBinary(new SP.FileSaveBinaryInformation { Content = contentByteArray });
                    }
                }
                file.ListItemAllFields["RequestID"] = ddlRequestID.SelectedItem.Text;
                //file.ListItemAllFields["JournalName"] = txtJournalName.Text;
                //file.ListItemAllFields["VolumeNo"] = txtVolumeNo.Text;
                file.ListItemAllFields["DelFlag"] = "0";
                file.ListItemAllFields["Approve"] = "ABC";
                file.ListItemAllFields["CheckOut"] = "False";
                file.ListItemAllFields["Requstor"] = _ws.GetCurrentUserEmail();
                file.ListItemAllFields["UpldDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
                file.ListItemAllFields.Update();
                _ws.executeClientContext(context);
            }
            mdlSuccess.Show();
        }
    }

    public void AddErrorMessage(string errorMessage)
    {
        var validator = new CustomValidator();
        validator.IsValid = false;
        validator.ErrorMessage = errorMessage;
        Page.Validators.Add(validator);
    }

    protected void ddlRequestID_DataBound(object sender, EventArgs e)
    {
        ddlRequestID.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyConfDocuments.aspx", true);
    }
    protected void lnkAttachFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExtConfDocs");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            //context.ExecuteQuery();
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);

            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    protected void btnSuccess_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyConfDocuments.aspx", false);
    }
    public void SetFileName(int Id, string fileName, SP.ClientContext context, SP.List list)
    {
        SP.ListItem item = list.GetItemById(Id);
        context.Load(item, itemOld => itemOld.File);
        _ws.executeClientContext(context);
        SP.File file = item.File;
        if (fldFileUpload.HasFile)
        {
            file.MoveTo(_ExtConfDocs + fileName, SP.MoveOperations.Overwrite);
        }
    }


    protected void ddlRequestID_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblTitle.Text = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("ID", ddlRequestID.SelectedValue), "Title");
            lblStatus.Text = _ws.getColumnValue("ExternalActivity", new KeyValuePair<string, string>("ID", ddlRequestID.SelectedValue), "Status");
            lblComments.Text = _ws.getColumnValue("ExtConfDocs", new KeyValuePair<string, string>("RequestID", Request.QueryString["ReqID"].ToString()), "Comment");
        }
        catch (Exception ex)
        {

        }
    }
}
