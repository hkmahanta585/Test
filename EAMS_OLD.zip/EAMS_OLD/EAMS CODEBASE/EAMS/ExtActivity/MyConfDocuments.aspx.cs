﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;

public partial class MyConfDocuments : System.Web.UI.Page
{
    Workshop _ws;
    //string _itemID;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (!Page.IsPostBack)
        {
            BindData();
        }
    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        string reqID = string.Empty;
        Session["ID"] = e.CommandArgument.ToString();
        Dictionary<string, string> filters = new Dictionary<string, string>();
        switch (e.CommandName.Trim().ToUpper())
        {
            case "DELETE":
                lblMassage.Text = "Are you sure you want to delete this doc.?";
                this.mdlModelDialog.Show();
                break;
            case "MODIFY":
                Control ctl = e.CommandSource as Control;
                string requestID = ((System.Web.UI.WebControls.LinkButton)(ctl)).ToolTip;
                Response.Redirect("ConfUploadDocs.aspx?ID=" + e.CommandArgument.ToString() + "&ReqID=" + requestID, true);
                break;
            case "VIEW":
                reqID = e.CommandArgument.ToString();
                filters.Add("RequestID", ((System.Web.UI.WebControls.LinkButton)(e.CommandSource)).Text);
                DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "Category", "RequestID", "ReqDate", "DelFlag", "WFLevel", "Status", "RStatus", "KeyReason", "RilValue", "JournalConfDetail", "ApproveWith", "Abstract", "ReqStatus", "Comment", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "Disclosure", "ConfDate", "ConfType", "StatusDate", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "Text", "Text", "User" }, filters: filters);

                if (Session["GridRequest"] == null)
                    SessionUtility.AddSessionValue(key: "GridRequest", value: gridRequest);
                else
                    SessionUtility.UpdateSessionValue(key: "GridRequest", value: gridRequest);
                if (gridRequest.Rows.Count > 0)
                    Response.Redirect("MdlForm.aspx?ID=" + ((LinkButton)(e.CommandSource)).Text, true);

                break;
        }
    }

    protected void lnkFileName_Click(object sender, EventArgs e)
    {
        LinkButton button = (LinkButton)sender;
        GridViewRow row = (GridViewRow)button.NamingContainer;
        if (row != null)
        {
            string itemID = ((LinkButton)sender).CommandArgument.ToString();
            Session["ID"] = itemID;
            DownloadDocument();
        }
    }

    protected void lnkCLFileName_Click(object sender, EventArgs e)
    {
        LinkButton button = (LinkButton)sender;
        GridViewRow row = (GridViewRow)button.NamingContainer;
        GridView grid = (GridView)button.Parent.Parent.Parent.Parent;

        string val = (string)grid.DataKeys[row.RowIndex].Value.ToString();

        if (row != null)
        {
            Session["ID"] = _ws.getIPCL("IPClerReport", new KeyValuePair<string, string>("RequestID", val), "ID");
            DownloadClearence();
        }
    }

    public void BindData()
    {
        try
        {
            Dictionary<string, string> filters = new Dictionary<string, string>();
            filters.Add("DelFlag", "0");
            filters.Add("Requstor", _ws.GetCurrentUserEmail());
            //filters.Add("Requstor", "dipak.d.kachhaway@ril.com");
            DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExtConfDocs", columns: new List<string>() { "ID", "Requstor", "UpldDate", "RequestID", "FileLeafRef", "CheckOut", "Approve", "CheckedBy" }, filterColumnType: new List<string>() { "Text", "Text" }, filters: filters);
            DataView dv = null;
            if (gridRequest.Rows.Count > 0)
            {
                dv = new DataView(gridRequest);
                dv.Sort = "RequestID DESC";
                gvGroup.DataSource = dv;
                gvGroup.DataBind();
            }
            else
            {
                gvGroup.DataSource = null;
                gvGroup.DataBind();
            }

        }
        catch (Exception ex)
        {
            _ws.LogError("MyConfDocuments (BindData) :-", ex.Message.ToString());
        }
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        _ws.DeleteDoc("ExtConfDocs", int.Parse(Session["ID"].ToString()));
        BindData();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        // _ws.DeleteItem("WorkshopDocs", int.Parse(Session["_itemID"].ToString()));
        // BindData();
    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        //_ws.DeleteItem("WorkshopDocs", int.Parse(Session["_itemID"].ToString()));
        // BindData();
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;

                string checkIn = dr["CheckOut"].ToString();
                string status = dr["Approve"].ToString();

                LinkButton lnkDel = e.Row.FindControl("lnkDelete") as LinkButton;
                LinkButton lnkMod = e.Row.FindControl("lnkModify") as LinkButton;
                LinkButton lnkCLPFileName = e.Row.FindControl("lnkCLPFileName") as LinkButton;

                Label lblStatus = e.Row.FindControl("lblStatus") as Label;

                lblStatus.Text = (status.Contains("Approve") ? "Approved by CIPT" : (status.Contains("Need Changes") ? "Need Changes" : (checkIn.Contains("True") ? "In-Process" : "Pending")));
                lnkDel.Visible = (status.Contains("Approve") ? false : (status.Contains("Need Changes") ? false : (checkIn.Contains("True") ? false : true)));
                lnkMod.Visible = (status.Contains("Approve") ? false : (status.Contains("Need Changes") ? true : false));
                lnkCLPFileName.Enabled = (status.Contains("Approve") ? true : false);
            }
            catch (Exception)
            {
            }
        }

    }

    public void DownloadClearence()
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("IPClerReport");
            SP.ListItem item = list.GetItemById(int.Parse(Session["ID"].ToString()));
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            //context.ExecuteQuery();
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);

            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }

    public void DownloadDocument()
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExtConfDocs");
            SP.ListItem item = list.GetItemById(int.Parse(Session["ID"].ToString()));
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            //context.ExecuteQuery();
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);

            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    protected void btnAddA_Click(object sender, EventArgs e)
    {
        /*  foreach (GridViewRow row in gvGroup.Rows)
          {
              CheckBox chkBox = row.FindControl("chkSelected") as CheckBox;
              if (c != null)
              {
                  if (result.Count > 0)
                  {
                      foreach (Employee item in result)
                      {
                          Label Id = row.FindControl("lblId") as Label;
                          if (Id.Text == item.Id.ToString())
                          {
                              chkBox.Checked = true;
                          }
                          else
                          {
                              chkBox.Checked = false;
                          }
                      }
                  }
              }
          }*/
    }

}
