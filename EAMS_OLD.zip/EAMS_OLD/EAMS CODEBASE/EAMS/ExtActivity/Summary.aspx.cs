﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using SP = Microsoft.SharePoint.Client;
using System.Data;

public partial class Workshop_Summary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Clear();
        Workshop _ws = new Workshop();
        Dictionary<string, string> filters = new Dictionary<string, string>();

        //Filter request for logged in user
        filters.Add("Author", string.Empty);
        //filters.Add("DelFlag", "0");

        DataTable myRequests = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "Status", "RStatus", "DelFlag", "WFLevel", "draftFlag" }, filterColumnType: new List<string>() { "User" }, filters: filters);

        //lblMyRequest.Text = myRequests.Rows.Count.ToString();
        lblMyRequest.Text = (from DataRow dr in myRequests.Rows where dr["DelFlag"].ToString().Equals("0") select 1).Count().ToString();
        lblDeleted.Text = (from DataRow dr in myRequests.Rows where dr["DelFlag"].ToString().Equals("1") select 1).Count().ToString();
        lblDraft.Text = (from DataRow dr in myRequests.Rows where dr["RStatus"].ToString().Equals("Draft", StringComparison.OrdinalIgnoreCase) && dr["DelFlag"].ToString().Equals("0") select 1).Count().ToString();
        lblApproved.Text = (from DataRow dr in myRequests.Rows where dr["RStatus"].ToString().Equals("Complete", StringComparison.OrdinalIgnoreCase) select 1).Count().ToString();
        lblPending.Text = (from DataRow dr in myRequests.Rows where dr["Status"].ToString().Equals("Modify", StringComparison.OrdinalIgnoreCase) && dr["DelFlag"].ToString().Equals("0") select 1).Count().ToString();
        lblRejecte.Text = (from DataRow dr in myRequests.Rows where (dr["Status"].ToString().Equals("Rejected", StringComparison.OrdinalIgnoreCase) && dr["RStatus"].ToString().Equals("Closed", StringComparison.OrdinalIgnoreCase)) select 1).Count().ToString();
        filters.Clear();
        //---------------------------------Hide Row (1 Section)------------------//

        rowCount.Visible = (int.Parse(lblMyRequest.Text) > 0 ? true : false);
        rowDelete.Visible = (int.Parse(lblDeleted.Text) > 0 ? true : false);
        rowDraft.Visible = (int.Parse(lblDraft.Text) > 0 ? true : false);
        rowApprove.Visible = (int.Parse(lblApproved.Text) > 0 ? true : false);
        rowPending.Visible = (int.Parse(lblPending.Text) > 0 ? true : false);
        rowReject.Visible = (int.Parse(lblRejecte.Text) > 0 ? true : false);

        //Set Manager,HOD, Plan & Strategy  and R&T row visible false------------//
        rowMgr.Visible = false;
        rowSFH.Visible = false;
        rowCFH.Visible = false;
        rowCIPTView.Visible = false;
        rowLevel1.Visible = false;
        //-----------------------------End Here--------------------------------//


        //-------------------------------manager--------------------------------//
        filters.Add("Manager", string.Empty);
        filters.Add("WFLevel", "0");
        filters.Add("DelFlag", "0");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable MgrRequests = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);

        //filters.Clear();
        //filters.Add("Manager", string.Empty);
        //filters.Add("WFLevel", "11");
        //filters.Add("DelFlag", "0");
        //filters.Add("draftFlag", "No");
        //filters.Add("RStatus", "Open");
        //DataTable MgrRequests1 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);

        filters.Clear();
        filters.Add("Manager", string.Empty);
        filters.Add("WFLevel", "21");
        filters.Add("DelFlag", "0");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable MgrRequests2 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);

        // MgrRequests.Merge(MgrRequests1);
        MgrRequests.Merge(MgrRequests2);

        int cMgr = MgrRequests.Rows.Count;
        if (cMgr > 0) { rowMgr.Visible = true; lblL1.Text = cMgr.ToString(); }


        //-----------------------------Site Function Head-------------------------------//
        filters.Clear();
        filters.Add("SiteFunHead", string.Empty);
        filters.Add("WFLevel", "1");
        filters.Add("COEFlag", "False");
        filters.Add("DelFlag", "0");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");

        DataTable SFHRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text", "Text" }, filters: filters);

        filters.Clear();
        filters.Add("SiteFunHead", string.Empty);
        filters.Add("WFLevel", "21");
        filters.Add("COEFlag", "False");
        filters.Add("DelFlag", "0");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");

        DataTable SFHRequest1 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text", "Text" }, filters: filters);

        SFHRequest.Merge(SFHRequest1);

        int SFH = SFHRequest.Rows.Count;
        if (SFH > 0) { rowSFH.Visible = true; lblSFH.Text = SFH.ToString(); }



        //---------------------------Site COE HEad -------------------------//

        //For general Request (COEFlag = 'TRUE') || Request(0) => Manager(1) => COE Fun Head(2) =>CIPT

        filters.Clear();
        filters.Add("COEFunHead", string.Empty);
        filters.Add("WFLevel", "1");
        filters.Add("COEFlag", "True");
        filters.Add("DelFlag", "0");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable CFHRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text", "Text" }, filters: filters);

        //For general Request || Request(0) => Manager(1) => Site Fun Head(2) => COE Fun Head(3) =>CIPT

        filters.Clear();
        filters.Add("COEFunHead", string.Empty);
        filters.Add("WFLevel", "2");
        filters.Add("DelFlag", "0");
        filters.Add("COEFlag", "False");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable CFHRequest1 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text", "Text" }, filters: filters);

        //If user Site Head (Aval in 'Site List') || Request(21) => Site Fun Head(22) => COE Fun Head(23) => CIPT
        filters.Clear();
        filters.Add("COEFunHead", string.Empty);
        filters.Add("WFLevel", "21");
        filters.Add("DelFlag", "0");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable CFHRequest2 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);

        //If user Site CTS Head (Aval in 'Group List')|| Request(11) => COE Fun Head(12) => CIPT

        //filters.Clear();
        //filters.Add("COEFunHead", string.Empty);
        //filters.Add("WFLevel", "11");
        //filters.Add("DelFlag", "0");
        //filters.Add("draftFlag", "No");
        //filters.Add("RStatus", "Open");
        //DataTable CFHRequest3 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);


        CFHRequest.Merge(CFHRequest1);
        CFHRequest.Merge(CFHRequest2);
        // CFHRequest.Merge(CFHRequest3);

        int CFH = CFHRequest.Rows.Count;
        if (CFH > 0) { rowCFH.Visible = true; lblCFH.Text = CFH.ToString(); }

        filters.Clear();


        //-----------------------------CIPT VIEW--------------------------------//rowCIPTView

        if (_ws.IsInCIPT(_ws.GetCurrentUserID()))
        {

            //For general Request (COEFlag = 'TRUE') || Request(0) => Manager(1) => COE Fun Head(2) =>CIPT
            filters.Add("WFLevel", "2");
            filters.Add("COEFlag", "True");
            filters.Add("DelFlag", "0");
            filters.Add("draftFlag", "No");
            filters.Add("RStatus", "Open");
            DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text", "Text" }, filters: filters);

            //For general Request || Request(0) => Manager(1) => Site Fun Head(2) => COE Fun Head(3) =>CIPT
            filters.Clear();
            filters.Add("WFLevel", "3");
            filters.Add("DelFlag", "0");
            filters.Add("COEFlag", "False");
            filters.Add("draftFlag", "No");
            filters.Add("RStatus", "Open");
            DataTable gridRequest1 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text", "Text" }, filters: filters);

            //If user Site Head (Aval in 'Site List') || Request(21) => Site Fun Head(22) => COE Fun Head(23) => CIPT
            filters.Clear();
            filters.Add("WFLevel", "22");
            filters.Add("DelFlag", "0");
            filters.Add("draftFlag", "No");
            filters.Add("RStatus", "Open");
            DataTable gridRequest2 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text" }, filters: filters);

            //If user Site CTS Head (Aval in 'Group List')|| Request(11) => COE Fun Head(12) => CIPT
            filters.Clear();
            filters.Add("WFLevel", "11");
            filters.Add("DelFlag", "0");
            filters.Add("draftFlag", "No");
            filters.Add("RStatus", "Open");
            DataTable gridRequest3 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text" }, filters: filters);

            gridRequest.Merge(gridRequest1);
            gridRequest.Merge(gridRequest2);
            gridRequest.Merge(gridRequest3);

            int CIPT = gridRequest.Rows.Count;
            if (CIPT > 0) { rowCIPTView.Visible = true; lblCIPT.Text = CIPT.ToString(); }
            filters.Clear();

        }

        //----------------------------- For Level 1 -------------------------------//
        filters.Clear();
        filters.Add("LevelA", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "0");
        DataTable dtlevel1 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        //----------------------------- For Level 2 -------------------------------//
        filters.Clear();
        filters.Add("LevelB", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "1");
        DataTable dtlevel2 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        //----------------------------- For Level 3 -------------------------------//
        filters.Clear();
        filters.Add("LevelC", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "2");
        DataTable dtlevel3 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        //----------------------------- For Level 3 -------------------------------//
        filters.Clear();
        filters.Add("LevelD", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "3");
        DataTable dtlevel4 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        //----------------------------- For Level 3 -------------------------------//
        filters.Clear();
        filters.Add("LevelE", string.Empty);
        filters.Add("RStatus", "Open");
        filters.Add("LevelFlag", "4");
        DataTable dtlevel5 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text" }, filters: filters);

        dtlevel1.Merge(dtlevel2);
        dtlevel1.Merge(dtlevel3);
        dtlevel1.Merge(dtlevel4);
        dtlevel1.Merge(dtlevel5);


        int dtl1 = dtlevel1.Rows.Count;
        int userID = _ws.GetCurrentUserID();
        KeyValuePair<string, string> colLast = new KeyValuePair<string, string>("UserID", Convert.ToString(userID));
        string role = _ws.getColumnValue("ExtRoleList", colLast, "Title");
        //lblRole.Text = role;
        if (dtl1 > 0) { rowLevel1.Visible = true; lblLevel.Text = dtl1.ToString(); }


        //-----------------------------End Hear--------------------------------//


        //---------------- Check for Approve Documents -----------------------------//
        if (_ws.IsInCIPT(_ws.GetCurrentUserID()))
            rowApproveDocs.Visible = true;
        else
            rowApproveDocs.Visible = false;
    }
}