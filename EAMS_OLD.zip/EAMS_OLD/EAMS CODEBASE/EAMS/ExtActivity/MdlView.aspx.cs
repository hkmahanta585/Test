﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Configuration;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using EAMSBusiness;
using WebApplication1;
using System.Text;

public partial class MdlView : System.Web.UI.Page
{
    #region Private Members
    string _editItemID;
    Workshop _ws;
    Dictionary<string, string> filters = null;
    #endregion

    #region Event Handlers
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }

        if (!IsPostBack && _editItemID != null)
        {
            PopulatePageWithData();
            Session["returnURL"] = Request.UrlReferrer.ToString();
        }
    }

    protected void lnkAttachedFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExternalActivity");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }

    #endregion
    #region Private Methods

    void PopulatePageWithData()
    {
        DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("GridRequest");
        DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();
        lblRequestID.Text = drGridRequest["RequestID"].ToString();

        gvStatus.DataSource = _ws.GetRequestStatusDetails(Convert.ToString(drGridRequest["RequestID"]));
        gvStatus.DataBind();

        lblSegment.Text = drGridRequest["Segment"].ToString();
        lblSector.Text = drGridRequest["Sector"].ToString();
        lblBusiness.Text = drGridRequest["Business"].ToString();
        lblSite.Text = drGridRequest["site"].ToString();
        lblCategory1.Text = drGridRequest["Category"].ToString();


        //--------------------------------------------------------------
        string workShopID = Convert.ToString(drGridRequest["ProgrammTitle"]);

        lblProgrammTitle.Text = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(drGridRequest["ProgrammTitle"])), "NameSDate");

        string confDetails = "";

        confDetails = "OrganizedBy:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", workShopID), "OrganizedBy") + ";";
        confDetails += "Duration:-" + "(" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", workShopID), "Duration") + ")" + ";";
        confDetails += "Start Date:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", workShopID), "StartDate") + "; End Date:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", workShopID), "EndDate") + ";";
        confDetails += "Location:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", workShopID), "Location") + ";";
        // lblJournal1.Text = confDetails.ToString().Replace(";", "<br />");

        lblJournal1.Text = Convert.ToString(drGridRequest["JournalConfDetail"]).Replace(";", "<br />");
        //--------------------------------------------------------------


        lnkAttachedFile.Text = drGridRequest["FileLeafRef"].ToString();
        if (lnkAttachedFile.Text.Trim().Contains("XXXXX"))
        {
            lnkAttachedFile.Visible = false;
        }


        if (Convert.ToString(drGridRequest["IPCLReportName"]).Length > 0)
        {
            lnkIpClReport.Text = drGridRequest["IPCLReportName"].ToString();
            rowIpClReport.Visible = true;
        }
        else
        {
            lnkIpClReport.Text = string.Empty;
            rowIpClReport.Visible = false;
        }

        lblReason1.Text = drGridRequest["KeyReason"].ToString();
        lblTitleOfActivity1.Text = drGridRequest["Title"].ToString();
        lblValue1.Text = drGridRequest["RilValue"].ToString();
       // lblJournal1.Text = drGridRequest["JournalConfDetail"].ToString();


        lblApprover.Text = _ws.GetApprover(lblRequestID.Text, lblTitleOfActivity1.Text);

        lblAprovPrestion.Text = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? "Abstract (Only for presentation)" : "Full Paper/Presentation (Final manuscript, Final presentation, award application, etc.)");

        lblTakingApproval1.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? true : false);
        lblTakingApproval2.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("2") ? true : false);

        lblAbstract1.Text = drGridRequest["Abstract"].ToString(); //ConfDate

        rwDateOfConf.Visible = false;
        rwConfIs.Visible = false;
        rowProgTitle.Visible = false;
        if ((Convert.ToString(drGridRequest["Category"]).Contains("Publication")))
        {
            rwDateOfConf.Visible = false;
            rwConfIs.Visible = false;
            rowProgTitle.Visible = false;
        }
        else
        {
            lblDateOfConf.Text = Convert.ToString(drGridRequest["ConfDate"]);
            lblConfIs.Text = (Convert.ToString(drGridRequest["ConfType"]).Contains("0") ? "National" : "International");
            rwDateOfConf.Visible = true;
            rwConfIs.Visible = true;
            rowProgTitle.Visible = true;
        }

        lblPatentA.Text = (Convert.ToString(drGridRequest["PatentA"]).Contains("0") ? "Yes" : "No");
        lblPatentB.Text = (Convert.ToString(drGridRequest["PatentB"]).Contains("0") ? "Yes" : "No");
        lblPatentC.Text = drGridRequest["PatentC"].ToString();
        lblPatentD.Text = drGridRequest["PatentD"].ToString();
        lblPatentE.Text = drGridRequest["PatentE"].ToString();
        lblPatentF.Text = drGridRequest["PatentF"].ToString();

        string EditMode = string.Empty;
        lblIsPatentable.Text = (Convert.ToString(drGridRequest["Patent"]).Contains("0") ? "Yes" : (Convert.ToString(drGridRequest["Patent"]).Contains("1") ? "No" : "Don't Know"));

        EditMode = (drGridRequest["PatentA"].ToString().Length > 0 ? "A" : "");
        EditMode += (drGridRequest["PatentB"].ToString().Length > 0 ? "B" : "");
        EditMode += (drGridRequest["PatentC"].ToString().Length > 0 ? "C" : "");
        EditMode += (drGridRequest["PatentD"].ToString().Length > 0 ? "D" : "");
        EditMode += (drGridRequest["PatentE"].ToString().Length > 0 ? "E" : "");
        EditMode += (drGridRequest["PatentF"].ToString().Length > 0 ? "F" : "");
        lblEditMode.Text = EditMode;

        string disclosure = Convert.ToString(drGridRequest["Disclosure"]);
        rowA.Visible = false;
        rowB.Visible = false;
        rowC.Visible = false;
        rowD.Visible = false;
        rowE.Visible = false;
        rowF.Visible = false;
        rowG.Visible = false;

        switch (disclosure)
        {
            case "A":
                rdbA.Checked = true;
                rowA.Visible = true;
                break;
            case "B":
                rdbB.Checked = true;
                rowB.Visible = true;
                break;
            case "C":
                rdbC.Checked = true;
                rowC.Visible = true;
                break;
            case "D":
                rdbD.Checked = true;
                rowD.Visible = true;
                break;
            case "E":
                rdbE.Checked = true;
                rowE.Visible = true;
                break;
            case "F":
                rdbF.Checked = true;
                rowF.Visible = true;
                break;
            case "G":
                rdbG.Checked = true;
                rowG.Visible = true;
                break;
        }

        //lblAprovPrestion.Text=drGridRequest[""].ToString();
        lblStatus.Text = drGridRequest["ReqStatus"].ToString();
        lblComment.Text = drGridRequest["Comment"].ToString();
        lblStatusDate.Text = drGridRequest["StatusDate"].ToString();
        Session["ReqID"] = drGridRequest["RequestID"].ToString();
        BindEmpGrid(drGridRequest["RequestID"].ToString());
        BindNonEmpGrid(drGridRequest["RequestID"].ToString());
    }
    public void BindEmpGrid(string reqID)
    {

        filters = new Dictionary<string, string>();
        filters.Add("Title", reqID);
        DataTable ExtEmpGrid = _ws.getListAsGrid(givelistName: "ExtEmpList", columns: new List<string>() { "ID", "AuthorType", "AuthorName", "ECNo", "EmailID", "Reporting", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
        gvEmp.DataSource = ExtEmpGrid;
        gvEmp.DataBind();
    }
    public void BindNonEmpGrid(string reqID)
    {

        filters.Clear();
        filters.Add("Title", reqID);
        DataTable ExtEmpGrid = _ws.getListAsGrid(givelistName: "ExtNonEmpList", columns: new List<string>() { "ID", "CoAuthorName", "Orgnization", "EmailID", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);

        gvNonEmp.DataSource = ExtEmpGrid;
        gvNonEmp.DataBind();
    }
    #endregion

    protected void btnOK_Click(object sender, EventArgs e)
    {
        Response.Redirect(Session["returnURL"].ToString());
    }
    protected void lnkIPCLReport_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("IPClerReport");

            SP.CamlQuery caml = new SP.CamlQuery();
            StringBuilder query = new StringBuilder(string.Empty);
            query.AppendFormat("<View><Query><Where><Eq><FieldRef Name = RequestID/><Value Type = 'Text'>{0}</Value></Eq></Where></Query></View>", lblRequestID.Text.Trim());
            caml.ViewXml = query.ToString();

            SP.ListItemCollection listItems = list.GetItems(caml);
            context.Load(listItems);
            _ws.executeClientContext(context);

            SP.ListItem item = listItems[0];
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    //
}