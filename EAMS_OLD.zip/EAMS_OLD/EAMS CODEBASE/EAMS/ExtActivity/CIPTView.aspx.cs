﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;

public partial class CIPTView : System.Web.UI.Page
{
    Workshop _ws;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (!Page.IsPostBack)
        {
            BindData();
        }

    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Trim().ToUpper().Equals("VIEW"))
        {
            Session["CIPT"] = "CIPT";
            Response.Redirect("CIPTApprove.aspx?ID=" + e.CommandArgument.ToString() + "&Level=CIPT", true);
        }
    }
    public void BindData()
    {
        //Check if current logged in user is exist in 'CIPT' list or not
        if (_ws.IsInCIPT(_ws.GetCurrentUserID()))
        {
            Dictionary<string, string> filters = new Dictionary<string, string>();
            //If user Site CTS Head (Aval in 'Group List')|| Request(11) => COE Fun Head(12) => CIPT
            filters.Add("WFLevel", "11");
            filters.Add("DelFlag", "0");
            filters.Add("draftFlag", "No");
            filters.Add("RStatus", "Open");
            DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "CheckOut", "CheckedBy", "Grade", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text" }, filters: filters);

            //For general Request || Request(0) => Manager(1) => Site Fun Head(2) => COE Fun Head(3) =>CIPT
            filters.Clear();
            filters.Add("WFLevel", "3");
            filters.Add("DelFlag", "0");
            filters.Add("COEFlag", "False");
            filters.Add("draftFlag", "No");
            DataTable gridRequest1 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "CheckOut", "CheckedBy", "Grade", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text" }, filters: filters);

            //For general Request (COEFlag = 'TRUE') || Request(0) => Manager(1) => COE Fun Head(2) =>CIPT
            filters.Clear();
            filters.Add("WFLevel", "2");
            filters.Add("DelFlag", "0");
            filters.Add("COEFlag", "True");
            filters.Add("draftFlag", "No");
            DataTable gridRequest2 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "CheckOut", "CheckedBy", "Grade", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text" }, filters: filters);


            //If user Site Head (Aval in 'Site List') || Request(21) => Site Fun Head(22) => COE Fun Head(23) => CIPT
            filters.Clear();
            filters.Add("WFLevel", "22");
            filters.Add("DelFlag", "0");
            filters.Add("draftFlag", "No");
            DataTable gridRequest3 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "CheckOut", "CheckedBy", "Grade", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason", "IPCLReportName", "ProgrammTitle" }, filterColumnType: new List<string>() { "Text", "Text", "Text" }, filters: filters);

            gridRequest.Merge(gridRequest1);
            gridRequest.Merge(gridRequest2);
            gridRequest.Merge(gridRequest3);


            if (Session["GridRequest"] == null)
                SessionUtility.AddSessionValue(key: "GridRequest", value: gridRequest);
            else
                SessionUtility.UpdateSessionValue(key: "GridRequest", value: gridRequest);

            DataView dv = new DataView(gridRequest);
            dv.Sort = "ID DESC";

            gvGroup.DataSource = dv;
            gvGroup.DataBind();
        }
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void chkCheck_OnCheckedChanged(object sender, EventArgs e)
    {
        int selRowIndex = ((GridViewRow)(((CheckBox)sender).Parent.Parent)).RowIndex;

        string ID = gvGroup.DataKeys[selRowIndex].Value.ToString();
        LinkButton lnlReqID = (LinkButton)gvGroup.Rows[selRowIndex].FindControl("lnkView");

        CheckBox chkApprove = (CheckBox)gvGroup.Rows[selRowIndex].FindControl("chkCheck");
        Label lblCheckOutBy = (Label)gvGroup.Rows[selRowIndex].FindControl("lblCheckOutBy");
        Label lbCheckOut = (Label)gvGroup.Rows[selRowIndex].FindControl("lblCheck");
        string status = ((chkApprove.Checked) ? "Check Out" : "Check In");

        //Update item in ExtCheckOutHistory
        _ws.UpdateCheckInOutHistory(lnlReqID.Text, _ws.GetCurrentUserName(), status);
        //Update item in ExtActivityList list
        _ws.UpdateExtCheckInOutHistory("ExternalActivity", ID, _ws.GetCurrentUserName(), status);
        BindData();
    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("ExternalActivity", int.Parse(Session["_itemID"].ToString()));
        BindData();
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRow dr = ((DataRowView)e.Row.DataItem).Row;

            //Get current User Mail Address
            string checkOutBy = _ws.GetCurrentUserName();

            Label lblChecked = e.Row.FindControl("lblCheck") as Label;
            CheckBox chbCheck = e.Row.FindControl("chkCheck") as CheckBox;
            Label lblCheckedOutBy = e.Row.FindControl("lblCheckOutBy") as Label;
            LinkButton lnlReqID = e.Row.FindControl("lnkView") as LinkButton;

            LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
            lnkView.Text = dr["RequestID"].ToString();

            DropDownList ddlCoAuthor = e.Row.FindControl("ddlCoAuthor") as DropDownList;
            ddlCoAuthor.DataSource = _ws.getCoAuthor(new KeyValuePair<string, string>("Title", lnkView.Text.Trim()));
            ddlCoAuthor.DataBind();
            string authorName = ddlCoAuthor.Items[0].ToString();
            ddlCoAuthor.Items.RemoveAt(0);
            ddlCoAuthor.Items.Insert(0, authorName + " (A)");

            lnlReqID.Enabled = false;
            if (lblChecked.Text.Equals("Check Out", StringComparison.OrdinalIgnoreCase))
            {
                if (lblCheckedOutBy.Text.Contains(checkOutBy))
                {
                    lnlReqID.Enabled = true;
                    chbCheck.Visible = true;
                    chbCheck.Checked = true;
                    lblCheckedOutBy.Visible = false;
                }
                else
                {
                    lnlReqID.Enabled = false;
                    chbCheck.Visible = false;
                    lblCheckedOutBy.Visible = true;
                }
            }

        }
    }
}
