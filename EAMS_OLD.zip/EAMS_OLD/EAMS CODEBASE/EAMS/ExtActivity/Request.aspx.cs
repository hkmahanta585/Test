﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;
using System.IO;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using System.Text.RegularExpressions;
using System.Security.Principal;
using System.Text;




public partial class Request : System.Web.UI.Page
{

    #region Private Variables
    Workshop _ws;
    RILUser _rilUser;
    ADService objAD;
    string _editItemID;
    //    string _editPatentText;
    string _ExternalActivity = WebConfigurationManager.AppSettings["_ExternalActivity"].ToString();
    int ciptGroup = int.Parse(WebConfigurationManager.AppSettings["CIPTGroup"]);
    #endregion

    #region Global Variable
    string _manager = string.Empty;
    string _Manger = string.Empty;
    string _wfLevel = string.Empty;
    string requestId = string.Empty;
    Dictionary<string, string> filters = null;
    #endregion

    public void PopulatePageControls()
    {
        string listName = "Segment";
        string keyColumnName = "ID";
        string valueColumnName = "Title";
        ddlSegment.PopulateddlNew(_ws, listName, keyColumnName, valueColumnName);

        listName = "Site";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSite.PopulateddlNew(_ws, listName, keyColumnName, valueColumnName);

        //txtCurrentUser.Text = _ws.GetCurrentUserName();
        //txtEmpCode.Text = objAD.getUserID(_ws.GetCurrentLoginName().Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries)[1]);

        txtRequestID.Text = "PRE-" + DateTime.Now.Year + "-XXXX";


        ddlCategory.Items.Add(new ListItem("Publication"));
        ddlCategory.Items.Add(new ListItem("Presentation"));
        ddlCategory.Items.Add(new ListItem("Award Application"));
        ddlCategory.Items.Add(new ListItem("Panel Discussion"));

        ddlProgramTitle.ConfPopulateddl(ws: _ws, listName: "Conference & Workshop", keyColumnName: "WorkshopID", valueColumnName: "NameSDate", columnType: "Choice", filter: new KeyValuePair<string, string>("Category", "Conference or Seminar"), FilterByDate: true);

    }
    public void PopulatePageControlsWithExisting()
    {
        string EditMode = string.Empty;
        DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("GridRequest");
        DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();

        (from ListItem lst in ddlSegment.Items where lst.Text == Convert.ToString(drGridRequest["Segment"]) select (lst.Selected = true)).ToList();
        ddlSector.Populateddl(ws: _ws, listName: "Sector", keyColumnName: "ID", valueColumnName: "Title", columnType: "Lookup", filter: new KeyValuePair<string, string>("Segment", ddlSegment.SelectedValue));
        (from ListItem lst in ddlSector.Items where lst.Text == Convert.ToString(drGridRequest["Sector"]) select (lst.Selected = true)).ToList();
        ddlBusiness.Populateddl(ws: _ws, listName: "Group", keyColumnName: "ID", valueColumnName: "Title", columnType: "Choice", filter: new KeyValuePair<string, string>("Sector", ddlSector.SelectedItem.Text));
        (from ListItem lst in ddlBusiness.Items where lst.Text == Convert.ToString(drGridRequest["Business"]) select (lst.Selected = true)).ToList();
        (from ListItem lst in ddlSite.Items where lst.Text == Convert.ToString(drGridRequest["site"]) select (lst.Selected = true)).ToList();
        (from ListItem lst in ddlCategory.Items where lst.Text == Convert.ToString(drGridRequest["Category"]) select (lst.Selected = true)).ToList();

        //if (Convert.ToString(drGridRequest["Category"]) != "Publication" && Convert.ToString(drGridRequest["Category"]) != "Panel Discussion")
        if (Convert.ToString(drGridRequest["Category"]) != "Publication")
        {
            ddlProgramTitle.Populateddl(ws: _ws, listName: "Conference & Workshop", keyColumnName: "WorkshopID", valueColumnName: "NameSDate", columnType: "Choice", filter: new KeyValuePair<string, string>("Category", "Conference or Seminar"), FilterByDate: true);
            ddlProgramTitle.Items.FindByText(_ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(drGridRequest["ProgrammTitle"])), "NameSDate")).Selected = true;
        }
        ddlProgramTitle.Enabled = false;
        txtJournal.Enabled = false;
        string confDetails = "";

        txtTitle.Text = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "Title");

        confDetails = "OrganizedBy:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "OrganizedBy");
        confDetails += "; Duration:-" + "(" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "Duration") + ")";
        confDetails += "; Start Date:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "StartDate") + "; End Date:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "EndDate");
        confDetails += "; Location:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "Location");

        txtJournal.Text = confDetails;

        Session["startDate"] = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "StartDate");
        Session["Overseas"] = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "Overseas");

        txtConfDate.Text = Convert.ToString(Session["startDate"]);
        rdbConfType.SelectedIndex = (Convert.ToString(Session["Overseas"]) == "No" ? 0 : 1);

        txtConfDate.Enabled = false;


        ddlSegment.Enabled = false;
        ddlSector.Enabled = false;
        ddlBusiness.Enabled = false;
        ddlSite.Enabled = false;
        ddlCategory.Enabled = false;

        txtTitle.Text = drGridRequest["Title"].ToString();

        if (Convert.ToString(drGridRequest["RStatus"]).Equals("Draft") || Convert.ToString(drGridRequest["Status"]).Equals("Modify"))
        {
            txtTitle.Enabled = false;
            rdbConfType.Enabled = false;
            rowApproval.Visible = false;
            rowApprovalDetails.Visible = false;
            lblSubmitButton.Text = "Yes";
        }

        gvStatus.DataSource = _ws.GetRequestStatusDetails(Convert.ToString(drGridRequest["RequestID"]));
        gvStatus.DataBind();

        if (Convert.ToString(drGridRequest["Status"]).Equals("Modify"))
        {
            gvEmp.Enabled = false;
            gvNonEmp.Enabled = false;
        }

        statusDIV.Visible = true;

        if (drGridRequest["IPCLReportName"].ToString().Length > 0)
        {
            clrReport.Visible = true;
            lnkIpClReport.Text = drGridRequest["IPCLReportName"].ToString();
        }
        else
        {
            clrReport.Visible = false;
            lnkIpClReport.Text = string.Empty;
        }

        txtRequestID.Text = drGridRequest["RequestID"].ToString();
        lnkAttachFile.Text = drGridRequest["FileLeafRef"].ToString();
        txtReason.Text = drGridRequest["KeyReason"].ToString();
        txtCost.Text = drGridRequest["RilValue"].ToString();

        Session["WFLevel"] = drGridRequest["MDFLevel"].ToString();

        txtAbstract.Text = drGridRequest["Abstract"].ToString();
        txtJournal.Text = drGridRequest["JournalConfDetail"].ToString();

        //(from ListItem lst in ddlPatent.Items where lst.Text == Convert.ToString(drGridRequest["Patentable"]) select (lst.Selected = true)).ToList();
        (from ListItem lst in ddlTakingApproval.Items where lst.Value == Convert.ToString(drGridRequest["ApproveWith"]) select (lst.Selected = true)).ToList();
        rowApprovalDetails1.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("1") ? true : false);
        rowApprovalDetails2.Visible = (Convert.ToString(drGridRequest["ApproveWith"]).Equals("2") ? true : false);

        txtConfDate.Text = drGridRequest["ConfDate"].ToString();
        rdbConfType.SelectedValue = drGridRequest["ConfType"].ToString();


        rdbCentralThem.SelectedValue = drGridRequest["Patent"].ToString();

        rdbInvention.SelectedValue = drGridRequest["PatentA"].ToString();
        EditMode = (drGridRequest["PatentA"].ToString().Length > 0 ? "A" : "");

        rdbTechnology.SelectedValue = drGridRequest["PatentB"].ToString();
        EditMode += (drGridRequest["PatentB"].ToString().Length > 0 ? "B" : "");

        txtDetailsOfPatent.Text = drGridRequest["PatentC"].ToString();
        EditMode += (drGridRequest["PatentC"].ToString().Length > 0 ? "C" : "");

        txtDetailsOfInv.Text = drGridRequest["PatentD"].ToString();
        EditMode += (drGridRequest["PatentD"].ToString().Length > 0 ? "D" : "");

        txtJustify.Text = drGridRequest["PatentE"].ToString();
        EditMode += (drGridRequest["PatentE"].ToString().Length > 0 ? "E" : "");

        txtBasisForNonPaten.Text = drGridRequest["PatentF"].ToString();
        EditMode += (drGridRequest["PatentF"].ToString().Length > 0 ? "F" : "");

        lblEditMode.Text = EditMode;

        tdApprover.Visible = true;
        lblApprover.Text = _ws.GetApprover(txtRequestID.Text, txtTitle.Text);

        string disclosure = Convert.ToString(drGridRequest["Disclosure"]);
        switch (disclosure)
        {
            case "A":
                rdbA.Checked = true;
                break;
            case "B":
                rdbB.Checked = true;
                break;
            case "C":
                rdbC.Checked = true;
                break;
            case "D":
                rdbD.Checked = true;
                break;
            case "E":
                rdbE.Checked = true;
                break;
            case "F":
                rdbF.Checked = true;
                break;
            case "G":
                rdbG.Checked = true;
                break;
        }

        Session["ReqID"] = drGridRequest["RequestID"].ToString();
        BindEmpGrid(drGridRequest["RequestID"].ToString());
        BindNonEmpGrid(drGridRequest["RequestID"].ToString());
    }
    protected void lnkIPCLReport_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("IPClerReport");

            SP.CamlQuery caml = new SP.CamlQuery();
            StringBuilder query = new StringBuilder(string.Empty);
            query.AppendFormat("<View><Query><Where><Eq><FieldRef Name = RequestID/><Value Type = 'Text'>{0}</Value></Eq></Where></Query></View>", txtRequestID.Text.Trim());
            caml.ViewXml = query.ToString();

            SP.ListItemCollection listItems = list.GetItems(caml);
            context.Load(listItems);
            _ws.executeClientContext(context);

            SP.ListItem item = listItems[0];
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
            btnSubmit.Enabled = true;
        }
    }
    public void BindEmpGrid(string reqID)
    {

        filters = new Dictionary<string, string>();
        filters.Add("Title", reqID);
        DataTable ExtEmpGrid = _ws.getListAsGrid(givelistName: "ExtEmpList", columns: new List<string>() { "ID", "AuthorType", "AuthorName", "ECNo", "EmailID", "Reporting", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);

        gvEmp.DataSource = ExtEmpGrid;
        gvEmp.DataBind();
    }

    public void BindNonEmpGrid(string reqID)
    {

        filters.Clear();
        filters.Add("Title", reqID);
        DataTable ExtEmpGrid = _ws.getListAsGrid(givelistName: "ExtNonEmpList", columns: new List<string>() { "ID", "CoAuthorName", "Orgnization", "EmailID", "Location" }, filterColumnType: new List<string>() { "Text" }, filters: filters);

        gvNonEmp.DataSource = ExtEmpGrid;
        gvNonEmp.DataBind();
    }

    protected void gvEmp_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRow dr = ((DataRowView)(e.Row.DataItem)).Row;

            Label lblAuthorType = e.Row.FindControl("lblAuthor") as Label;
            DropDownList ddlAuthType = e.Row.FindControl("ddlAuthorType") as DropDownList;
            if (lblAuthorType.Text.Length > 0)
            {
                ddlAuthType.SelectedItem.Text = dr["AuthorType"].ToString();
            }
        }
    }

    protected void gvNonEmp_RowDataBound(object sender, GridViewRowEventArgs e)
    {
    }

    #region Event Handlers

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        _rilUser = new RILUser();
        objAD = new ADService();

        _manager = objAD.getManager(_ws.GetCurrentLoginName().Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries)[1]).Split(new string[] { "=", "," }, StringSplitOptions.RemoveEmptyEntries)[1];
        _Manger = _ws.GetUser(objAD.getManager(_ws.GetCurrentLoginName().Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries)[1]).Split(new string[] { "=", "," }, StringSplitOptions.RemoveEmptyEntries)[1]).Title;
        // _manager = _rilUser.GetManager(loginName: _ws.GetCurrentLoginName());
        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }

        statusDIV.Visible = false;
        if (Session["Status"] != null && Convert.ToString(Session["Status"]).Equals("Modify"))
        {
            btnDraft.Visible = false;
            statusDIV.Visible = true;
        }

        btnDraft.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(btnDraft, null) + ";");
        btnSubmit.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(btnSubmit, null) + ";");

        if (!IsPostBack)
        {
            FirstgvEmpRow();
            FirstgvNonEmpRow();
            PopulatePageControls();

            //Hide accept radio button initially
            chkPresentation.Visible = false;
            chkAbstract.Visible = false;
            rowApprovalDetails1.Visible = false;
            rowApprovalDetails2.Visible = false;

            if (_editItemID != null)
            {
                Linkrow.Visible = true;
                tdSiteHead.Visible = false;
                PopulatePageControlsWithExisting();
            }
            else
            {
                clrReport.Visible = false;
            }
            tdSiteHead.Visible = true;
        }
        Response.CacheControl = "No-cache";
    }
    public bool isValidEmail(String email)
    {
        Regex reg = new Regex(@"(\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,6})");
        return reg.IsMatch(email);
    }

    public bool FormValidate()
    {
        lblCodeMessage.Text = string.Empty;

        //-------------------------------Employee Grid (For Selecting only one Grid)--------------------
        bool leadFlag = true;
        int leadCount = 0;
        //int mailCount = 0;
        foreach (GridViewRow empRow in gvEmp.Rows)
        {
            if (empRow.RowType == DataControlRowType.DataRow)
            {
                DropDownList ddlAuthotType = (DropDownList)empRow.FindControl("ddlAuthorType");
                Label lblEmailID = (Label)empRow.FindControl("lblEmailID");

                if (string.IsNullOrEmpty(lblEmailID.Text))
                {
                    leadFlag = false;
                    lblCodeMessage.Text += "Please select proper employee name in 'EMPLOYEE DETAILS' section; ";
                }

                string authorType = ddlAuthotType.SelectedItem.Text;
                if (authorType.ToLower().Contains("lead"))
                {
                    leadCount++;
                    if (leadCount > 1)
                    {
                        leadFlag = false;
                    }
                }
            }
        }
        //if (leadCount > 1)
        //{
        //    leadFlag = false;
        //}
        //else
        //{
        //    leadFlag = false;
        //    lblCodeMessage.Text += "Please select 'Lead-Author' while entering employee details, Dont select more than one 'Lead-Author'; ";
        //}

        //--------------------------------------------For NonEmployee Grid (validation for email Id) ----------------------------
        foreach (GridViewRow empRow in gvNonEmp.Rows)
        {
            if (empRow.RowType == DataControlRowType.DataRow)
            {
                TextBox txtEmail = (TextBox)empRow.FindControl("txtEmail");
                TextBox txtCoAuthorName = (TextBox)empRow.FindControl("txtCoAuthorName");
                if (txtCoAuthorName.Text.Trim().Length > 0)
                {
                    if (!isValidEmail(txtEmail.Text))
                    {
                        leadFlag = false;
                        lblCodeMessage.Text += "Please enter proper email address in 'Non Employee Section' ";
                    }
                }
            }
        }
        //-------------------------------------------- Conference Date & Conference IS ----------------------------
        if (ddlCategory.SelectedItem.Text.Contains("Presentation") || ddlCategory.SelectedItem.Text.Contains("Award Application"))
        {
            try
            {
                DateTime confDate = DateTime.Parse(txtConfDate.Text);
                leadFlag = ((txtConfDate.Text.Length > 0 && rdbConfType.SelectedItem != null) ? true : false);
            }
            catch (Exception)
            {
                leadFlag = false;
                lblCodeMessage.Text += "Please select proper conference date and select conference is? ";
            }

        }
        //-------------------------------------------- Validation for 'Is the Central Theme Patentability'---------
        //-------------------------------------------- For 'Yes'---------------------------------------------------
        if (rdbCentralThem.SelectedItem != null)
        {
            if (rdbCentralThem.SelectedItem.Text.Equals("Yes"))
            {

                //if (rdbInvention.SelectedItem == null)
                //{
                //    leadFlag = false;
                //    lblCodeMessage.Text += "disclosure of concerned technology been submitted?  ";
                //}

                //For 'a'
                if (rdbInvention.SelectedItem != null && rdbInvention.SelectedItem.Text.Equals("Yes"))
                {
                    //For 'b'
                    if (rdbTechnology.SelectedItem != null && rdbTechnology.SelectedItem.Text.Equals("Yes"))
                    {
                        if (txtDetailsOfPatent.Text.Trim().Length == 0)
                        {
                            leadFlag = false;
                            lblCodeMessage.Text += "Provide details of patent. ";
                        }
                    }
                    else if (rdbTechnology.SelectedItem != null && rdbTechnology.SelectedItem.Text.Equals("No"))
                    {
                        if (txtDetailsOfInv.Text.Trim().Length == 0)
                        {
                            leadFlag = false;
                            lblCodeMessage.Text += "Provide details of invention disclosure ";
                        }
                        if (txtJustify.Text.Trim().Length == 0)
                        {
                            leadFlag = false;
                            lblCodeMessage.Text += "Justify the publication ";
                        }
                    }
                    else if (rdbTechnology.SelectedItem == null)
                    {
                        leadFlag = false;
                        lblCodeMessage.Text += "Has patent covering technology been filed / granted? ";
                    }
                }
                else if (rdbInvention.SelectedItem != null && rdbInvention.SelectedItem.Text.Equals("No"))
                {
                    if (txtDetailsOfPatent.Text.Trim().Length == 0)
                    {
                        leadFlag = false;
                        lblCodeMessage.Text += "Provide details of patent. ";
                    }
                    if (txtJustify.Text.Trim().Length == 0)
                    {
                        leadFlag = false;
                        lblCodeMessage.Text += "Justify the publication; ";
                    }
                }
                else
                {
                    leadFlag = false;
                    lblCodeMessage.Text += "Please mention invention disclosure of concerned technology? ";
                }
            }
            //-------------------------------- For 'No'-----------------------------------------------------
            if (rdbCentralThem.SelectedItem.Text.Equals("No"))
            {
                if (txtBasisForNonPaten.Text.Trim().Length == 0)
                {
                    leadFlag = false;
                    lblCodeMessage.Text += "Enter basis for non-patentability; ";
                }
            }
            //-------------------------------------------- For 'Type of Disclosure' ----------------------

            if (rdbA.Checked || rdbB.Checked || rdbC.Checked || rdbD.Checked || rdbE.Checked || rdbF.Checked || rdbG.Checked)
            {
            }
            else
            {
                leadFlag = false;
                lblCodeMessage.Text += "Please select 'Disclosure Type'; ";
            }
            //------------------------------------------- For taking approval ----------------------------
            if (ddlTakingApproval.SelectedValue.Equals("2"))
            {
                if (_editItemID != null)
                {
                    if (!_ws.CheckFileExist(_editItemID))
                    {
                        leadFlag = false;
                        lblCodeMessage.Text += "Please Upload file; ";
                    }
                }
                else
                {
                    if (fldFileUpload.HasFile)
                    {
                        leadFlag = true;
                    }
                    else
                    {
                        leadFlag = false;
                        lblCodeMessage.Text += "Please Upload file; ";
                    }
                }
            }
            //return leadFlag;
        }
        else
        {
            leadFlag = false;
            lblCodeMessage.Text += "Please select central theme; ";
        }
        return leadFlag;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (FormValidate())
        {
            string draftFlag = ((Button)sender).CommandArgument;
            using (SP.ClientContext context = _ws.getClientContext())
            {
                SP.Web site = context.Web;

                //Load CIPT Group whose id is '20025 / 20043'
                SP.Group oGroup = site.SiteGroups.GetById(ciptGroup);
                context.Load(oGroup);

                SP.List list = site.Lists.GetByTitle("ExternalActivity");
                byte[] contentByteArray;
                string newfile = string.Empty;
                string fileName = string.Empty;

                if (fldFileUpload.HasFile)
                {
                    contentByteArray = new byte[fldFileUpload.PostedFile.ContentLength];
                    newfile = fldFileUpload.PostedFile.FileName;
                    fileName = txtRequestID.Text.Trim() + "_" + fldFileUpload.FileName;
                }
                else
                {
                    contentByteArray = new byte[10 * 10];
                    fileName = "XXXXX" + DateTime.Now.ToString("yyyyMMddHHmmss");
                }
                fldFileUpload.PostedFile.InputStream.Read(contentByteArray, 0, fldFileUpload.PostedFile.ContentLength - 1);
                SP.File file = null;

                if (_editItemID == null)
                {
                    SP.FileCreationInformation fci = new SP.FileCreationInformation();
                    fci.Content = contentByteArray;
                    fci.Overwrite = true;
                    string fileExte = System.IO.Path.GetExtension(fldFileUpload.FileName);
                    fci.Url = _ExternalActivity + fileName;
                    file = list.RootFolder.Files.Add(fci);
                    context.Load(file.ListItemAllFields);
                    _ws.executeClientContext(context);

                    if (ddlCategory.SelectedItem.Text.Equals("Publication", StringComparison.OrdinalIgnoreCase))
                    {
                        requestId = "PUB-" + DateTime.Now.Year + "-" + file.ListItemAllFields.Id.ToString("0000");
                    }
                    else if (ddlCategory.SelectedItem.Text.Equals("Presentation", StringComparison.OrdinalIgnoreCase))
                    {
                        requestId = "PRE-" + DateTime.Now.Year + "-" + file.ListItemAllFields.Id.ToString("0000");
                    }
                    else if (ddlCategory.SelectedItem.Text.Equals("Award Application", StringComparison.OrdinalIgnoreCase))
                    {
                        requestId = "AWD-" + DateTime.Now.Year + "-" + file.ListItemAllFields.Id.ToString("0000");
                    }
                    else
                    {
                        requestId = "PNL-" + DateTime.Now.Year + "-" + file.ListItemAllFields.Id.ToString("0000");
                    }

                    if (fldFileUpload.HasFile)
                        SetFileName(Id: file.ListItemAllFields.Id, fileName: requestId + "-" + fldFileUpload.FileName, context: context, list: list);
                    file.ListItemAllFields["RequestID"] = requestId;
                }
                else
                {
                    SP.ListItem item = list.GetItemById(_editItemID);
                    context.Load(item, itemOld => itemOld.File);
                    _ws.executeClientContext(context);

                    file = item.File;
                    if (fldFileUpload.HasFile)
                    {
                        file.MoveTo(_ExternalActivity + fileName, SP.MoveOperations.Overwrite);
                        file.SaveBinary(new SP.FileSaveBinaryInformation { Content = contentByteArray });
                    }
                }

                file.ListItemAllFields["Title"] = txtTitle.Text;
                file.ListItemAllFields["Segment"] = ddlSegment.SelectedItem.Text;
                file.ListItemAllFields["Site"] = ddlSite.SelectedItem.Text;
                file.ListItemAllFields["Sector"] = ddlSector.SelectedItem.Text;
                file.ListItemAllFields["Business"] = ddlBusiness.SelectedItem.Text;

                //----------------------Danger Zone----------------------------------------

                //Level 1 :- current user Manager 
                int manager = _ws.GetUser(_manager).Id;
                file.ListItemAllFields["Manager"] = manager;

                SP.User SiteFunHead = null, COEFunHead;
                //Level 2 :- COE Functional Head / Site Functional Head (Site = "COE") 
                string coeFlag = (Check(ddlSite.SelectedValue, _ws.getID("Site", new KeyValuePair<string, string>("SiteID", "06")).ToString()) ? "True" : "False");

                //Level 3 :- COEFunHead
                COEFunHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");

                //Level 3 :- SiteFunHead
                //SiteFunHead = _ws.getUserFromList("Site", new KeyValuePair<string, string>("Title", ddlSite.SelectedItem.ToString()), "SiteCTSHead");
                if (!ddlSite.SelectedItem.ToString().Contains("COE"))
                {
                    SiteFunHead = _ws.getSiteSectorHead("SiteSectorHead", ddlSite.SelectedItem.ToString(), ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "SiteSectorHead");
                    file.ListItemAllFields["SiteFunHead"] = SiteFunHead.Id;
                }

                file.ListItemAllFields["COEFunHead"] = COEFunHead.Id;

                if (coeFlag.Equals("True"))
                    file.ListItemAllFields["RFlag"] = manager == COEFunHead.Id ? "COE" : "NO";
                else
                    file.ListItemAllFields["RFlag"] = manager == SiteFunHead.Id ? "SITE" : "NO";

                //Level 4 :- CIPT 
                file.ListItemAllFields["CIPT"] = oGroup;

                //-------------------------------Level A-------------------------------------//

                //Level A :- Technology COE Head/Site President
                //if (ddlSite.SelectedValue.Equals(_ws.getID("Site", new KeyValuePair<string, string>("SiteID", "06")).ToString()) && ddlSector.SelectedValue.Equals(_ws.getID("Sector", new KeyValuePair<string, string>("SectorID", "01")).ToString()))
                if (ddlSite.SelectedValue.Equals(_ws.getID("Site", new KeyValuePair<string, string>("SiteID", "06")).ToString()) || ddlSegment.SelectedValue.Equals(_ws.getID("Segment", new KeyValuePair<string, string>("SegmentID", "02")).ToString()))
                {
                    SP.User techCOEHead = _ws.getUserFromList("Sector", new KeyValuePair<string, string>("Title", ddlSector.SelectedItem.ToString()), "COEHead");
                    file.ListItemAllFields["TechSitePress"] = techCOEHead.Id;
                    file.ListItemAllFields["TechCOEFlag"] = "Yes";
                }
                else
                {
                    file.ListItemAllFields["TechCOEFlag"] = "No";
                    SP.User sitePresident = _ws.getUserFromList("Site", new KeyValuePair<string, string>("Title", ddlSite.SelectedItem.ToString()), "SitePresident");
                    file.ListItemAllFields["TechSitePress"] = sitePresident.Id;
                }

                //-------------------------------Level A-------------------------------------//
                //RNTFlag (denote wether Segment Head is RnT Head or Not)
                if (Check(ddlSegment.SelectedValue, _ws.getID("Segment", new KeyValuePair<string, string>("SegmentID", "02")).ToString()))
                {
                    file.ListItemAllFields["RNTFlag"] = "Yes";

                    coeFlag = "True";
                }
                else
                {
                    file.ListItemAllFields["RNTFlag"] = "No";
                }

                file.ListItemAllFields["COEFlag"] = coeFlag;

                //Level A :- GMS/RnT Head
                SP.User segHead = _ws.getUserFromList("Segment", new KeyValuePair<string, string>("Title", ddlSegment.SelectedItem.Text.Trim()), "SeniorManagement");
                file.ListItemAllFields["GMSHead"] = segHead.Id;

                //file.ListItemAllFields["Overseas"] = _ws.IsOverseas(ddlProgramTitle.SelectedValue);

                //--------------End Of Danger Zone-------------------------------------------
                file.ListItemAllFields["Category"] = ddlCategory.SelectedItem.Text;
                file.ListItemAllFields["Abstract"] = txtAbstract.Text;
                file.ListItemAllFields["JournalConfDetail"] = txtJournal.Text;
                file.ListItemAllFields["KeyReason"] = txtReason.Text;
                file.ListItemAllFields["RilValue"] = txtCost.Text;
                //file.ListItemAllFields["Patentable"] = ddlPatent.SelectedValue;
                file.ListItemAllFields["ApproveWith"] = ddlTakingApproval.SelectedValue;

                file.ListItemAllFields["DelFlag"] = "0";
                if (draftFlag.Equals("No"))
                {
                    file.ListItemAllFields["WFLevel"] = _ws.GetWFLevelNew();
                    file.ListItemAllFields["UsrType"] = _ws.GetUsrType();
                    file.ListItemAllFields["ReqStatus"] = _ws.GetReqStatusNew();
                    file.ListItemAllFields["RStatus"] = "Open";
                }

                if (draftFlag.Equals("Yes"))
                {
                    file.ListItemAllFields["WFLevel"] = _ws.GetWFLevelNew();
                    file.ListItemAllFields["UsrType"] = _ws.GetUsrType();
                    file.ListItemAllFields["ReqStatus"] = "Draft";
                    file.ListItemAllFields["RStatus"] = "Draft";
                }

                if (Session["Status"] != null && Convert.ToString(Session["Status"]).Equals("Modify"))
                {
                    file.ListItemAllFields["ReqStatus"] = "Re-Submitted";
                    file.ListItemAllFields["RStatus"] = "Open";
                    file.ListItemAllFields["WFLevel"] = (Session["WFLevel"] != null ? Session["WFLevel"].ToString() : "");
                }

                file.ListItemAllFields["ConfDate"] = txtConfDate.Text;
                file.ListItemAllFields["ConfType"] = rdbConfType.SelectedValue;

                string disclosure = (rdbA.Checked ? "A" : (rdbB.Checked ? "B" : (rdbC.Checked ? "C" : (rdbD.Checked ? "D" : (rdbE.Checked ? "E" : (rdbF.Checked ? "F" : "G"))))));
                GetDisclosure(disclosure);
                file.ListItemAllFields["Disclosure"] = disclosure;
                file.ListItemAllFields["DisclosureDef"] = ViewState["disclosureDef"].ToString();
                file.ListItemAllFields["DisclosureType"] = ViewState["disclosureType"].ToString();

                string patentString = Convert.ToString(Session["CT"]) + Convert.ToString(Session["Iven"]) + Convert.ToString(Session["Tech"]);

                file.ListItemAllFields["Patent"] = rdbCentralThem.SelectedValue;

                /*file.ListItemAllFields["PatentA"] = ((patentString.IndexOf('A') != -1) ? rdbInvention.SelectedValue : "");
                  file.ListItemAllFields["PatentB"] = ((patentString.IndexOf('B') != -1) ? rdbTechnology.SelectedValue : "");
                  file.ListItemAllFields["PatentC"] = ((patentString.IndexOf('C') != -1) ? txtDetailsOfPatent.Text : "");
                  file.ListItemAllFields["PatentD"] = ((patentString.IndexOf('D') != -1) ? txtDetailsOfInv.Text : "");
                  file.ListItemAllFields["PatentE"] = ((patentString.IndexOf('E') != -1) ? txtJustify.Text : "");
                  file.ListItemAllFields["PatentF"] = (txtBasisForNonPaten.Text.Length > 0 ? txtBasisForNonPaten.Text : "");*/
                //--------------------------------------------------------------------------------------------------------

                string PatentA = (rdbInvention.SelectedItem == null ? "" : Convert.ToString(rdbInvention.SelectedItem.Text));
                string PatentB = (rdbTechnology.SelectedItem == null ? "" : Convert.ToString(rdbTechnology.SelectedItem.Text));
                string PatentC = Convert.ToString(txtDetailsOfPatent.Text);
                string PatentD = Convert.ToString(txtDetailsOfInv.Text);
                string PatentE = Convert.ToString(txtJustify.Text);
                string PatentF = Convert.ToString(txtBasisForNonPaten.Text);

                file.ListItemAllFields["PatentA"] = ((PatentA.Length > 0) ? rdbInvention.SelectedValue : "");
                file.ListItemAllFields["PatentB"] = ((PatentB.Length > 0) ? rdbTechnology.SelectedValue : "");
                file.ListItemAllFields["PatentC"] = ((PatentC.Length > 0) ? txtDetailsOfPatent.Text : "");
                file.ListItemAllFields["PatentD"] = ((PatentD.Length > 0) ? txtDetailsOfInv.Text : "");
                file.ListItemAllFields["PatentE"] = ((PatentE.Length > 0) ? txtJustify.Text : "");
                file.ListItemAllFields["PatentF"] = ((PatentF.Length > 0) ? txtBasisForNonPaten.Text : "");

                //--------------------------------------------------------------------------------------------------------
                file.ListItemAllFields["ProgrammTitle"] = Convert.ToString(ddlProgramTitle.SelectedValue);
                //--------------------------------------------------------------------------------------------------------

                file.ListItemAllFields["ReqDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
                file.ListItemAllFields["Requestor"] = _ws.GetCurrentUserID();
                file.ListItemAllFields["EmpName"] = _ws.GetCurrentUserName();

                file.ListItemAllFields["draftFlag"] = draftFlag;

                file.ListItemAllFields["Status"] = "Pending";

                file.ListItemAllFields.Update();
                _ws.executeClientContext(context);

                AddEmployeeRecord(requestId);
                AddNonEmployeeRecord(requestId);
            }
            Session.Remove("Status");
            Session.Clear();
            msgHeadings.Text = "Information!";
            msgBody.Text = "Your Request is Saved.";
            mdlSuccess.Show();
        }
        else
        {
            btnSubmit.Enabled = true;
            Session.Remove("Status");
            Session.Clear();
            lblCodeHeading.Text = "Error! Please find some fields are missing..";
            mdlCodeError.Show();
        }
    }

    public void GetDisclosure(string key)
    {
        string disclosureType = string.Empty;
        string disclosureDef = string.Empty;
        switch (key)
        {
            case "A":
                disclosureType = spnTA.InnerText;
                disclosureDef = spnDA.InnerText;
                break;
            case "B":
                disclosureType = spnTB.InnerText;
                disclosureDef = spnDB.InnerText;
                break;
            case "C":
                disclosureType = spnTC.InnerText;
                disclosureDef = spnDC.InnerText;
                break;
            case "D":
                disclosureType = spnTD.InnerText;
                disclosureDef = spnDD.InnerText;
                break;
            case "E":
                disclosureType = spnTE.InnerText;
                disclosureDef = spnDE.InnerText;
                break;
            case "F":
                disclosureType = spnTF.InnerText;
                disclosureDef = spnDF.InnerText;
                break;
            case "G":
                disclosureType = spnTG.InnerText;
                disclosureDef = spnDG.InnerText;
                break;
        }

        ViewState["disclosureDef"] = disclosureDef;
        ViewState["disclosureType"] = disclosureType;
    }

    public void AddEmployeeRecord(string reqID)
    {
        string requestID;
        if (!string.IsNullOrEmpty(reqID))
        {
            requestID = reqID;
        }
        else
        {
            requestID = Session["ReqID"].ToString();
            _ws.DeleteMultipleItem("ExtEmpList", "Title", requestID);
        }
        foreach (GridViewRow row in gvEmp.Rows)
        {
            DropDownList ddlAuthorType = (DropDownList)row.FindControl("ddlAuthorType");
            TextBox txtEmpName = (TextBox)row.FindControl("txtEmpName");
            Label lblECNo = (Label)row.FindControl("lblECNo");
            Label lblEmailID = (Label)row.FindControl("lblEmailID");
            Label lblReportingTo = (Label)row.FindControl("lblReportingTo");
            Label lblLocation = (Label)row.FindControl("lblLocation");

            SP.ClientContext ctx = _ws.getClientContext();
            SP.List list = ctx.Web.Lists.GetByTitle("ExtEmpList");
            SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
            SP.ListItem listItem = list.AddItem(itemCreateInfo);

            listItem["AuthorType"] = ddlAuthorType.SelectedItem.Text;
            listItem["AuthorName"] = txtEmpName.Text;
            listItem["Title"] = requestID;
            listItem["ECNo"] = lblECNo.Text;
            listItem["EmailID"] = lblEmailID.Text;
            listItem["Reporting"] = lblReportingTo.Text;
            listItem["Location"] = lblLocation.Text;
            listItem.Update();
            _ws.executeClientContext(ctx);

        }

    }

    public void AddNonEmployeeRecord(string reqID)
    {
        string requestID;
        if (!string.IsNullOrEmpty(reqID))
        {
            requestID = reqID;
        }
        else
        {
            requestID = Session["ReqID"].ToString();
            _ws.DeleteMultipleItem("ExtNonEmpList", "Title", requestID);
        }
        foreach (GridViewRow row in gvNonEmp.Rows)
        {
            TextBox txtAuthorName = (TextBox)row.FindControl("txtCoAuthorName");
            TextBox txtOrg = (TextBox)row.FindControl("txtOrganization");
            TextBox txtEmail = (TextBox)row.FindControl("txtEmail");
            TextBox txtLoc = (TextBox)row.FindControl("txtLocation");

            SP.ClientContext ctx = _ws.getClientContext();
            SP.List list = ctx.Web.Lists.GetByTitle("ExtNonEmpList");
            SP.ListItemCreationInformation itemCreateInfo = new SP.ListItemCreationInformation();
            SP.ListItem listItem = list.AddItem(itemCreateInfo);

            listItem["CoAuthorName"] = txtAuthorName.Text;
            listItem["Title"] = requestID;
            listItem["Orgnization"] = txtOrg.Text;
            listItem["EmailID"] = txtEmail.Text;
            listItem["Location"] = txtLoc.Text;
            listItem.Update();
            _ws.executeClientContext(ctx);

        }

    }
    public bool Check(string A1, string A2)
    {
        if (A1.Equals(A2, StringComparison.OrdinalIgnoreCase))
            return true;
        else
            return false;
    }
    protected void ddlSegment_SelectedIndexChanged(object sender, EventArgs e)
    {
        //_ws.LogError(DateTime.Now.ToLongDateString(), "PostBack Happend");
        string segmentId = ddlSegment.SelectedValue;
        ddlSector.PopulateddlNew(ws: _ws, listName: "Sector", keyColumnName: "ID", valueColumnName: "Title", columnType: "Lookup", filter: new KeyValuePair<string, string>("Segment", segmentId));
        GetApproverFlow();
    }
    protected void ddlSegment_DataBound(object sender, EventArgs e)
    {
        ddlSegment.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
    {
        string sectorName = ddlSector.SelectedItem.ToString();
        ddlBusiness.PopulateddlNew(ws: _ws, listName: "Group", keyColumnName: "ID", valueColumnName: "Title", columnType: "Choice", filter: new KeyValuePair<string, string>("Sector", sectorName));
    }
    protected void ddlSector_DataBound(object sender, EventArgs e)
    {
        ddlSector.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlBusiness_DataBound(object sender, EventArgs e)
    {
        ddlBusiness.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlSite_DataBound(object sender, EventArgs e)
    {
        ddlSite.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlTakingApproval_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlTakingApproval.SelectedValue.Equals("1"))
        {
            chkAbstract.Visible = true;
            chkPresentation.Visible = false;
        }
        if (ddlTakingApproval.SelectedValue.Equals("2"))
        {
            chkPresentation.Visible = true;
            chkAbstract.Visible = false;
        }
        if (ddlTakingApproval.SelectedValue.Equals("0"))
        {
            chkPresentation.Visible = false;
            chkAbstract.Visible = false;
        }
    }
    protected void chkAbstract_CheckedChange(object sender, EventArgs e)
    {
        if (chkAbstract.Checked)
        {
            chkPresentation.Checked = false;
        }
    }
    protected void chkPresentation_CheckedChange(object sender, EventArgs e)
    {
        if (chkPresentation.Checked)
        {
            chkAbstract.Checked = false;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Summary.aspx", true);
    }
    protected void lnkAttachFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("ExternalActivity");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            //context.ExecuteQuery();
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);

            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("ExternalActivity", int.Parse(Session["_itemID"].ToString()));
    }

    #endregion


    protected void btnSuccess_Click(object sender, EventArgs e)
    {
        Response.Redirect("Summary.aspx", false);
    }

    protected void btnCodeError_Click(object sender, EventArgs e)
    {
        mdlCodeError.Hide();
    }


    public void SetFileName(int Id, string fileName, SP.ClientContext context, SP.List list)
    {
        SP.ListItem item = list.GetItemById(Id);
        context.Load(item, itemOld => itemOld.File);
        _ws.executeClientContext(context);
        //context.ExecuteQuery();
        SP.File file = item.File;
        if (fldFileUpload.HasFile)
        {
            file.MoveTo(_ExternalActivity + fileName, SP.MoveOperations.Overwrite);
            //file.SaveBinary(new SP.FileSaveBinaryInformation { Content = contentByteArray });
        }
    }


    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtTitle.Text = string.Empty;
        txtJournal.Text = string.Empty;
        txtConfDate.Text = string.Empty;
        txtTitle.ReadOnly = true;
        txtJournal.ReadOnly = true;
        txtConfDate.ReadOnly = true;
        rdbConfType.Enabled = false;

        if (ddlCategory.SelectedItem.Text.Equals("Publication", StringComparison.OrdinalIgnoreCase))
        {
            txtRequestID.Text = "PUB-" + DateTime.Now.Year + "-0000";
            txtTitle.ReadOnly = false;
            txtJournal.ReadOnly = false;
        }
        else if (ddlCategory.SelectedItem.Text.Equals("Presentation", StringComparison.OrdinalIgnoreCase))
        {
            txtRequestID.Text = "PRE-" + DateTime.Now.Year + "-0000";
            ddlProgramTitle.ConfPopulateddl(ws: _ws, listName: "Conference & Workshop", keyColumnName: "WorkshopID", valueColumnName: "NameSDate", columnType: "Choice", filter: new KeyValuePair<string, string>("Category", "Conference or Seminar"), FilterByDate: true);
        }
        else if (ddlCategory.SelectedItem.Text.Equals("Award Application", StringComparison.OrdinalIgnoreCase))
        {
            txtRequestID.Text = "AWD-" + DateTime.Now.Year + "-0000";
            ddlProgramTitle.ConfPopulateddl(ws: _ws, listName: "Conference & Workshop", keyColumnName: "WorkshopID", valueColumnName: "NameSDate", columnType: "Choice", filter: new KeyValuePair<string, string>("Category", "Conference or Seminar"), FilterByDate: true);
        }
        else
        {
            txtRequestID.Text = "PNL-" + DateTime.Now.Year + "-0000";
            ddlProgramTitle.ConfPopulateddl(ws: _ws, listName: "Conference & Workshop", keyColumnName: "WorkshopID", valueColumnName: "NameSDate", columnType: "Choice", filter: new KeyValuePair<string, string>("Category", "Conference or Seminar"), FilterByDate: true);
        }

    }

    protected void txtEmpName_OnTextChange(object sender, EventArgs e)
    {
        TextBox txtName = (TextBox)sender;
        GridViewRow row = (GridViewRow)txtName.NamingContainer;
        int i = Convert.ToInt32(row.RowIndex);
        Label lblECNo = (Label)row.FindControl("lblECNo");
        Label lblEmailId = (Label)row.FindControl("lblEmailID");
        Label lblReporting = (Label)row.FindControl("lblReportingTo");
        Label lblLocation = (Label)row.FindControl("lblLocation");

        try
        {
            ADService service = new ADService();
            string[] EmployeeSet = (Session["EmployeeSet"] != null ? (string[])Session["EmployeeSet"] : null);

            string msg = (EmployeeSet == null ? "EmployeeSet is NULL" : EmployeeSet.Length.ToString());
            string empDomainName = (from name in EmployeeSet where name.Contains(txtName.Text) select name).FirstOrDefault<string>();

            DataTable dtProfile = null;

            string userName = WebConfigurationManager.AppSettings["UserName"].ToString();
            string password = WebConfigurationManager.AppSettings["Password"].ToString();

            //using (new Impersonation("IN", "spinstall.dev", "srm@idc980"))

            try
            {
                using (new Impersonation("IN", userName, password))
                {
                    //_ws.LogError("Current Logged In User:-", User.Identity.Name);
                    //_ws.LogError("Is Authenticated ? :-", User.Identity.IsAuthenticated.ToString());
                    //_ws.LogError("AuthenticationType ? :-", User.Identity.AuthenticationType.ToString());
                    //_ws.LogError("Identity under code execute:-", System.Security.Principal.WindowsIdentity.GetCurrent().Name);
                    dtProfile = service.getUserDetailsByDomainId(empDomainName.Substring(0, empDomainName.IndexOf("[")));
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Line 34 :-" + ex.Message, ex.ToString());

            }

            lblECNo.Text = dtProfile.Rows[0]["employeeId"].ToString();
            lblEmailId.Text = dtProfile.Rows[0]["email"].ToString();
            lblReporting.Text = _ws.GetUser(dtProfile.Rows[0]["manager"].ToString()).Title;
            lblLocation.Text = dtProfile.Rows[0]["location"].ToString();

            txtName.BorderColor = System.Drawing.ColorTranslator.FromHtml("#DEDFDE");
            txtName.ForeColor = System.Drawing.ColorTranslator.FromHtml("#393839");
            row.ForeColor = System.Drawing.ColorTranslator.FromHtml("#393839");

            Button btnAdd = gvEmp.FooterRow.FindControl("btnAdd") as Button;
            btnAdd.Enabled = true;
        }
        catch (Exception ex)
        {
            _ws.LogError("List:-ExtActivity; Page:- Request.aspx", "Msg:- " + ex.Message + " Desc:- " + ex.ToString());
            lblECNo.Text = "--------";
            lblEmailId.Text = string.Empty;
            lblReporting.Text = "--------";
            lblLocation.Text = "--------";
            txtName.Text = "Enter valid name.";
            txtName.BorderColor = System.Drawing.Color.Red;
            txtName.ForeColor = System.Drawing.Color.Red;
            row.ForeColor = System.Drawing.Color.Red;
            txtName.Focus();

            Button btnAdd = gvEmp.FooterRow.FindControl("btnAdd") as Button;
            btnAdd.Enabled = false;
        }
    }


    protected void txtCoAuthorName_OnTextChange(object sender, EventArgs e)
    {
        TextBox txtCoAuthorName = (TextBox)sender;
        if (string.IsNullOrEmpty(txtCoAuthorName.Text))
        {
            txtCoAuthorName.Text = "Enter co-author name";
            txtCoAuthorName.BorderColor = System.Drawing.Color.Red;
            txtCoAuthorName.ForeColor = System.Drawing.Color.Red;
            Button btnAdd = gvNonEmp.FooterRow.FindControl("btnAddNonEmp") as Button;
            btnAdd.Enabled = false;
        }
        else
        {
            txtCoAuthorName.BorderColor = System.Drawing.ColorTranslator.FromHtml("#DEDFDE");
            txtCoAuthorName.ForeColor = System.Drawing.ColorTranslator.FromHtml("#393839");
            Button btnAdd = gvNonEmp.FooterRow.FindControl("btnAddNonEmp") as Button;
            btnAdd.Enabled = true;
        }
    }

    protected void txtOrganization_OnTextChange(object sender, EventArgs e)
    {
        TextBox txtOrganization = (TextBox)sender;
        if (string.IsNullOrEmpty(txtOrganization.Text))
        {
            txtOrganization.Text = "Enter organization name";
            txtOrganization.BorderColor = System.Drawing.Color.Red;
            txtOrganization.ForeColor = System.Drawing.Color.Red;
            Button btnAdd = gvNonEmp.FooterRow.FindControl("btnAddNonEmp") as Button;
            btnAdd.Enabled = false;
        }
        else
        {
            txtOrganization.BorderColor = System.Drawing.ColorTranslator.FromHtml("#DEDFDE");
            txtOrganization.ForeColor = System.Drawing.ColorTranslator.FromHtml("#393839");
            Button btnAdd = gvNonEmp.FooterRow.FindControl("btnAddNonEmp") as Button;
            btnAdd.Enabled = true;
        }
    }

    protected void txtEmail_OnTextChange(object sender, EventArgs e)
    {
        TextBox txtEmail = (TextBox)sender;
        if (!isValidEmail(txtEmail.Text))
        {
            txtEmail.Text = "Enter valid Email ID";
            txtEmail.BorderColor = System.Drawing.Color.Red;
            txtEmail.ForeColor = System.Drawing.Color.Red;
            //txtEmail.Focus();
            Button btnAdd = gvNonEmp.FooterRow.FindControl("btnAddNonEmp") as Button;
            btnAdd.Enabled = false;
        }
        else
        {
            txtEmail.BorderColor = System.Drawing.ColorTranslator.FromHtml("#DEDFDE");
            txtEmail.ForeColor = System.Drawing.ColorTranslator.FromHtml("#393839");
            Button btnAdd = gvNonEmp.FooterRow.FindControl("btnAddNonEmp") as Button;
            btnAdd.Enabled = true;
        }
    }

    protected void txtLocation_OnTextChange(object sender, EventArgs e)
    {
        TextBox txtLocation = (TextBox)sender;
        if (string.IsNullOrEmpty(txtLocation.Text))
        {
            txtLocation.Text = "Enter location name";
            txtLocation.BorderColor = System.Drawing.Color.Red;
            txtLocation.ForeColor = System.Drawing.Color.Red;
            // txtLocation.Focus();
            Button btnAdd = gvNonEmp.FooterRow.FindControl("btnAddNonEmp") as Button;
            btnAdd.Enabled = false;
        }
        else
        {
            txtLocation.BorderColor = System.Drawing.ColorTranslator.FromHtml("#DEDFDE");
            txtLocation.ForeColor = System.Drawing.ColorTranslator.FromHtml("#393839");
            Button btnAdd = gvNonEmp.FooterRow.FindControl("btnAddNonEmp") as Button;
            btnAdd.Enabled = true;
        }
    }
    public void FirstgvEmpRow()
    {

        DataTable dt = new DataTable();
        DataRow dr = null;
        dt.Columns.Add(new DataColumn("ID", typeof(string)));
        dt.Columns.Add(new DataColumn("AuthorName", typeof(string)));
        dt.Columns.Add(new DataColumn("ECNo", typeof(string)));
        dt.Columns.Add(new DataColumn("EmailID", typeof(string)));
        dt.Columns.Add(new DataColumn("Reporting", typeof(string)));
        dt.Columns.Add(new DataColumn("Location", typeof(string)));
        dt.Columns.Add(new DataColumn("AuthorType", typeof(string)));
        dr = dt.NewRow();
        dr["ID"] = 1;

        /*dr["AuthorName"] = string.Empty;
        dr["ECNo"] = string.Empty;
        dr["EmailID"] = string.Empty;
        dr["Reporting"] = string.Empty;
        dr["Location"] = string.Empty;
        dr["AuthorType"] = string.Empty;*/

        ADService service = new ADService();
        DataTable dtProfile = service.getUserDetailsByDomainId(_ws.GetCurrentLoginName().Remove(0, 3));
        dr["AuthorName"] = dtProfile.Rows[0]["displayName"].ToString();
        dr["ECNo"] = dtProfile.Rows[0]["employeeId"].ToString();
        dr["EmailID"] = dtProfile.Rows[0]["email"].ToString();
        dr["Reporting"] = _ws.GetUser(dtProfile.Rows[0]["manager"].ToString()).Title;
        dr["Location"] = dtProfile.Rows[0]["location"].ToString();
        dr["AuthorType"] = string.Empty;


        dt.Rows.Add(dr);

        ViewState["CurrentTable"] = dt;

        gvEmp.DataSource = dt;
        gvEmp.DataBind();

    }
    public void FirstgvNonEmpRow()
    {

        DataTable dt = new DataTable();
        DataRow dr = null;
        dt.Columns.Add(new DataColumn("ID", typeof(string)));
        dt.Columns.Add(new DataColumn("CoAuthorName", typeof(string)));
        dt.Columns.Add(new DataColumn("Orgnization", typeof(string)));
        dt.Columns.Add(new DataColumn("EmailID", typeof(string)));
        dt.Columns.Add(new DataColumn("Location", typeof(string)));

        dr = dt.NewRow();
        dr["ID"] = 1;
        dr["CoAuthorName"] = string.Empty;
        dr["Orgnization"] = string.Empty;
        dr["EmailID"] = string.Empty;
        dr["Location"] = string.Empty;
        dt.Rows.Add(dr);



        ViewState["NonEmp"] = dt;

        gvNonEmp.DataSource = dt;
        gvNonEmp.DataBind();

    }

    private void AddNewRow()
    {
        GetGridEmpData();
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null || gvEmp.Rows.Count == 1)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList ddlAuthorType = (DropDownList)gvEmp.Rows[rowIndex].Cells[1].FindControl("ddlAuthorType");
                    TextBox txtEmpName = (TextBox)gvEmp.Rows[rowIndex].Cells[2].FindControl("txtEmpName");
                    Label lblECNo = (Label)gvEmp.Rows[rowIndex].Cells[3].FindControl("lblECNo");
                    Label lblEmailID = (Label)gvEmp.Rows[rowIndex].Cells[4].FindControl("lblEmailID");
                    Label lblReportingTo = (Label)gvEmp.Rows[rowIndex].Cells[5].FindControl("lblReportingTo");
                    Label lblLocation = (Label)gvEmp.Rows[rowIndex].Cells[5].FindControl("lblLocation");

                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["ID"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["AuthorType"] = ddlAuthorType.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["AuthorName"] = txtEmpName.Text;
                    dtCurrentTable.Rows[i - 1]["ECNo"] = lblECNo.Text;
                    dtCurrentTable.Rows[i - 1]["EmailID"] = lblEmailID.Text;
                    dtCurrentTable.Rows[i - 1]["Reporting"] = lblReportingTo.Text;
                    dtCurrentTable.Rows[i - 1]["Location"] = lblLocation.Text;
                    rowIndex++;
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable"] = dtCurrentTable;

                gvEmp.DataSource = dtCurrentTable;
                gvEmp.DataBind();


            }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        SetPreviousData();
    }

    private void GetGridEmpData()
    {
        int rowIndex = 0;
        DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
        dtCurrentTable.Rows.Clear();
        DataRow drCurrentRow = null;
        if (gvEmp.Rows.Count > 0)
        {
            for (int i = 0; i < gvEmp.Rows.Count; i++)
            {
                DropDownList ddlAuthorType = (DropDownList)gvEmp.Rows[rowIndex].Cells[1].FindControl("ddlAuthorType");
                TextBox txtEmpName = (TextBox)gvEmp.Rows[rowIndex].Cells[2].FindControl("txtEmpName");
                Label lblECNo = (Label)gvEmp.Rows[rowIndex].Cells[3].FindControl("lblECNo");
                Label lblEmailID = (Label)gvEmp.Rows[rowIndex].Cells[4].FindControl("lblEmailID");
                Label lblReportingTo = (Label)gvEmp.Rows[rowIndex].Cells[5].FindControl("lblReportingTo");
                Label lblLocation = (Label)gvEmp.Rows[rowIndex].Cells[5].FindControl("lblLocation");

                drCurrentRow = dtCurrentTable.NewRow();
                drCurrentRow["ID"] = i + 1;
                dtCurrentTable.Rows.Add(drCurrentRow);

                dtCurrentTable.Rows[i]["ID"] = gvEmp.DataKeys[rowIndex]["ID"].ToString();
                dtCurrentTable.Rows[i]["AuthorType"] = ddlAuthorType.SelectedValue;
                dtCurrentTable.Rows[i]["AuthorName"] = txtEmpName.Text;
                dtCurrentTable.Rows[i]["ECNo"] = lblECNo.Text;
                dtCurrentTable.Rows[i]["EmailID"] = lblEmailID.Text;
                dtCurrentTable.Rows[i]["Reporting"] = lblReportingTo.Text;
                dtCurrentTable.Rows[i]["Location"] = lblLocation.Text;

                rowIndex++;
            }

            ViewState["CurrentTable"] = dtCurrentTable;
        }
    }

    private void AddNewRowNonEmp()
    {
        GetGridNonEmpData();
        int rowIndex = 0;
        if (ViewState["NonEmp"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["NonEmp"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {

                    TextBox txtAuthorName = (TextBox)gvNonEmp.Rows[rowIndex].Cells[1].FindControl("txtCoAuthorName");
                    TextBox txtOrg = (TextBox)gvNonEmp.Rows[rowIndex].Cells[2].FindControl("txtOrganization");
                    TextBox txtEmail = (TextBox)gvNonEmp.Rows[rowIndex].Cells[3].FindControl("txtEmail");
                    TextBox txtLoc = (TextBox)gvNonEmp.Rows[rowIndex].Cells[4].FindControl("txtLocation");

                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["ID"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["CoAuthorName"] = txtAuthorName.Text;
                    dtCurrentTable.Rows[i - 1]["Orgnization"] = txtOrg.Text;
                    dtCurrentTable.Rows[i - 1]["EmailID"] = txtEmail.Text;
                    dtCurrentTable.Rows[i - 1]["Location"] = txtLoc.Text;
                    rowIndex++;
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["NonEmp"] = dtCurrentTable;

                gvNonEmp.DataSource = dtCurrentTable;
                gvNonEmp.DataBind();
            }
        }
    }

    private void GetGridNonEmpData()
    {
        int rowIndex = 0;
        DataTable dtCurrentTable = (DataTable)ViewState["NonEmp"];
        dtCurrentTable.Rows.Clear();
        DataRow drCurrentRow = null;
        if (gvNonEmp.Rows.Count > 0)
        {
            for (int i = 0; i < gvNonEmp.Rows.Count; i++)
            {
                TextBox txtAuthorName = (TextBox)gvNonEmp.Rows[rowIndex].Cells[1].FindControl("txtCoAuthorName");
                TextBox txtOrg = (TextBox)gvNonEmp.Rows[rowIndex].Cells[2].FindControl("txtOrganization");
                TextBox txtEmail = (TextBox)gvNonEmp.Rows[rowIndex].Cells[3].FindControl("txtEmail");
                TextBox txtLoc = (TextBox)gvNonEmp.Rows[rowIndex].Cells[4].FindControl("txtLocation");

                drCurrentRow = dtCurrentTable.NewRow();
                drCurrentRow["ID"] = i + 1;
                dtCurrentTable.Rows.Add(drCurrentRow);

                dtCurrentTable.Rows[i]["ID"] = gvNonEmp.DataKeys[rowIndex]["ID"].ToString();
                dtCurrentTable.Rows[i]["CoAuthorName"] = txtAuthorName.Text;
                dtCurrentTable.Rows[i]["Orgnization"] = txtOrg.Text;
                dtCurrentTable.Rows[i]["EmailID"] = txtEmail.Text;
                dtCurrentTable.Rows[i]["Location"] = txtLoc.Text;

                rowIndex++;
            }

            ViewState["NonEmp"] = dtCurrentTable;
        }
    }

    private void SetPreviousDataNonEmp()
    {
        int rowIndex = 0;
        if (ViewState["NonEmp"] != null)
        {
            DataTable dt = (DataTable)ViewState["NonEmp"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TextBox txtAuthorName = (TextBox)gvNonEmp.Rows[rowIndex].Cells[1].FindControl("txtCoAuthorName");
                    TextBox txtOrg = (TextBox)gvNonEmp.Rows[rowIndex].Cells[2].FindControl("txtOrganization");
                    TextBox txtEmail = (TextBox)gvNonEmp.Rows[rowIndex].Cells[3].FindControl("txtEmail");
                    TextBox txtLoc = (TextBox)gvNonEmp.Rows[rowIndex].Cells[4].FindControl("txtLocation");

                    txtAuthorName.Text = dt.Rows[i]["CoAuthorName"].ToString();
                    txtOrg.Text = dt.Rows[i]["Orgnization"].ToString();
                    txtEmail.Text = dt.Rows[i]["EmailID"].ToString();
                    txtLoc.Text = dt.Rows[i]["Location"].ToString();
                    rowIndex++;

                }
            }
        }
    }
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownList ddlAuthorType = (DropDownList)gvEmp.Rows[rowIndex].Cells[1].FindControl("ddlAuthorType");
                    TextBox txtEmpName = (TextBox)gvEmp.Rows[rowIndex].Cells[2].FindControl("txtEmpName");
                    Label lblECNo = (Label)gvEmp.Rows[rowIndex].Cells[3].FindControl("lblECNo");
                    Label lblEmailID = (Label)gvEmp.Rows[rowIndex].Cells[4].FindControl("lblEmailID");
                    Label lblReportingTo = (Label)gvEmp.Rows[rowIndex].Cells[5].FindControl("lblReportingTo");
                    Label lblLocation = (Label)gvEmp.Rows[rowIndex].Cells[6].FindControl("lblLocation");

                    ddlAuthorType.SelectedValue = dt.Rows[i]["AuthorType"].ToString();
                    txtEmpName.Text = dt.Rows[i]["AuthorName"].ToString();
                    lblECNo.Text = dt.Rows[i]["ECNo"].ToString();
                    lblEmailID.Text = dt.Rows[i]["EmailID"].ToString();
                    lblReportingTo.Text = dt.Rows[i]["Reporting"].ToString();
                    lblLocation.Text = dt.Rows[i]["Location"].ToString();
                    rowIndex++;


                }
            }
        }
    }
    private void SetEmpRowData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList ddlAuthorType = (DropDownList)gvEmp.Rows[rowIndex].Cells[1].FindControl("ddlAuthorType");
                    TextBox txtEmpName = (TextBox)gvEmp.Rows[rowIndex].Cells[2].FindControl("txtEmpName");
                    Label lblECNo = (Label)gvEmp.Rows[rowIndex].Cells[3].FindControl("lblECNo");
                    Label lblEmailID = (Label)gvEmp.Rows[rowIndex].Cells[4].FindControl("lblEmailID");
                    Label lblReportingTo = (Label)gvEmp.Rows[rowIndex].Cells[5].FindControl("lblReportingTo");
                    Label lblLocation = (Label)gvEmp.Rows[rowIndex].Cells[6].FindControl("lblLocation");

                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["ID"] = gvEmp.DataKeys[rowIndex]["ID"].ToString();

                    dtCurrentTable.Rows[i - 1]["AuthorType"] = ddlAuthorType.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["AuthorName"] = txtEmpName.Text;
                    dtCurrentTable.Rows[i - 1]["ECNo"] = lblECNo.Text;
                    dtCurrentTable.Rows[i - 1]["EmailID"] = lblEmailID.Text;
                    dtCurrentTable.Rows[i - 1]["Reporting"] = lblReportingTo.Text;
                    dtCurrentTable.Rows[i - 1]["Location"] = lblLocation.Text;

                    rowIndex++;
                }
                ViewState["CurrentTable"] = dtCurrentTable;
            }
        }
    }

    public void gvEmp_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.RowIndex);
        if (rowIndex != 0)
        {
            GetGridEmpData();
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;
                if (dt.Rows.Count > 1)
                {
                    dt.Rows.Remove(dt.Rows[rowIndex]);
                    drCurrentRow = dt.NewRow();
                    ViewState["CurrentTable"] = dt;
                    gvEmp.DataSource = dt;
                    gvEmp.DataBind();
                    SetPreviousData();
                }
            }
        }
    }
    private void SetNonEmpRowData()
    {
        int rowIndex = 0;
        if (ViewState["NonEmp"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["NonEmp"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    TextBox txtAuthorName = (TextBox)gvNonEmp.Rows[rowIndex].Cells[1].FindControl("txtCoAuthorName");
                    TextBox txtOrg = (TextBox)gvNonEmp.Rows[rowIndex].Cells[2].FindControl("txtOrganization");
                    TextBox txtEmail = (TextBox)gvNonEmp.Rows[rowIndex].Cells[3].FindControl("txtEmail");
                    TextBox txtLoc = (TextBox)gvNonEmp.Rows[rowIndex].Cells[4].FindControl("txtLocation");

                    drCurrentRow = dtCurrentTable.NewRow();
                    //drCurrentRow["ID"] = gvEmp.DataKeys[rowIndex]["ID"].ToString();

                    dtCurrentTable.Rows[i - 1]["CoAuthorName"] = txtAuthorName.Text;
                    dtCurrentTable.Rows[i - 1]["Orgnization"] = txtOrg.Text;
                    dtCurrentTable.Rows[i - 1]["EmailID"] = txtEmail.Text;
                    dtCurrentTable.Rows[i - 1]["Location"] = txtLoc.Text;

                    rowIndex++;


                }
                ViewState["NonEmp"] = dtCurrentTable;
            }
        }
    }
    public void gvNonEmp_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GetGridNonEmpData();
        if (ViewState["NonEmp"] != null)
        {
            DataTable dt = (DataTable)ViewState["NonEmp"];
            DataRow drCurrentRow = null;
            int rowIndex = Convert.ToInt32(e.RowIndex);
            if (dt.Rows.Count > 1)
            {
                dt.Rows.Remove(dt.Rows[rowIndex]);
                drCurrentRow = dt.NewRow();
                ViewState["NonEmp"] = dt;
                gvNonEmp.DataSource = dt;
                gvNonEmp.DataBind();


                SetPreviousDataNonEmp();
            }
        }
    }
    protected void btnAdd_OnClick(object sender, EventArgs e)
    {

        AddNewRow();
    }
    protected void btnAddNonEmp_OnClick(object sender, EventArgs e)
    {

        AddNewRowNonEmp();
    }
    protected void rdbCentralThem_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["CT"] = null;
        Session["Iven"] = null;
        Session["Tech"] = null;

        hdfCentralThem.Value = string.Empty;
        hdfInvention.Value = string.Empty;
        hdfTechnology.Value = string.Empty;

        rdbInvention.ClearSelection();
        rdbTechnology.ClearSelection();

        if (rdbCentralThem.SelectedValue == "0")//Yes
        {
            hdfCentralThem.Value = "AM";
        }
        if (rdbCentralThem.SelectedValue == "1")//No
        {
            hdfCentralThem.Value = "FM";
        }
        if (rdbCentralThem.SelectedValue == "2")//No
        {
            hdfCentralThem.Value = "M";
        }
        Session["CT"] = hdfCentralThem.Value;
    }
    //Row :- 'axa'
    protected void rdbInvention_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["Iven"] = null;
        Session["Tech"] = null;

        hdfInvention.Value = string.Empty;
        hdfTechnology.Value = string.Empty;

        rdbTechnology.ClearSelection();

        if (rdbInvention.SelectedValue == "0")//Yes
        {
            hdfInvention.Value = "BN" + (Convert.ToString(Session["CT"]).Length > 0 ? Session["CT"] : "");
        }
        if (rdbInvention.SelectedValue == "1")//Yes
        {
            hdfInvention.Value = "CEN" + (Convert.ToString(Session["CT"]).Length > 0 ? Session["CT"] : "");
        }
        Session["Iven"] = hdfInvention.Value;
    }
    //Row :- 'bxa'
    protected void rdbTechnology_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["Tech"] = null;

        if (rdbTechnology.SelectedValue == "0")//Yes
        {
            hdfTechnology.Value = "C" + (Convert.ToString(Session["Iven"]).Length > 0 ? Session["Iven"] : "");
        }
        if (rdbTechnology.SelectedValue == "1")//Yes
        {
            hdfTechnology.Value = "DE" + (Convert.ToString(Session["Iven"]).Length > 0 ? Session["Iven"] : "");
        }
        Session["Tech"] = hdfTechnology.Value;
    }
    protected void ddlBusiness_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetApproverFlow();
    }
    protected void ddlSite_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetApproverFlow();
    }

    public void GetApproverFlow()
    {
        tdApprover.Visible = false;
        lblSiteHead.Text = "";
        int wfLevel = _ws.GetWFLevelNew();
        try
        {
            if (ddlSegment.SelectedItem.Value != "0" && ddlSector.SelectedItem.Value != "0")
            {
                if (ddlSegment.SelectedItem.Text.Equals("R&D"))
                {
                    SP.User COEFunHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                    if (wfLevel == 0)
                    {
                        lblSiteHead.Text = "Approval Flow :- Manager(" + _Manger + ")-----> COE Head(" + COEFunHead.Title + ") -----> CIPT -> (Subsequent Approval Based on Sensitivity Gradation Matrix)";
                    }
                    else if (wfLevel == 21)
                    {
                        lblSiteHead.Text = "Approval Flow :- COE Head(" + COEFunHead.Title + ") -----> CIPT -> (Subsequent Approval Based on Sensitivity Gradation Matrix)";
                    }
                }
            }

            if (ddlSite.SelectedItem.Value != "0" && ddlSector.SelectedItem.Value != "0" && ddlSegment.SelectedItem.Value != "0")
            {

                if (ddlSite.SelectedItem.Text == "COE")
                {
                    SP.User COEFunHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                    if (wfLevel == 0)
                    {
                        lblSiteHead.Text = "Approval Flow :- Manager(" + _Manger + ")-----> COE Function Head(" + COEFunHead.Title + ") -----> CIPT -> (Subsequent Approval Based on Sensitivity Gradation Matrix)";
                    }
                    else if (wfLevel == 21)
                    {
                        lblSiteHead.Text = "Approval Flow :- COE Function Head(" + COEFunHead.Title + ") -----> CIPT -> (Subsequent Approval Based on Sensitivity Gradation Matrix)";
                    }
                }
                else
                {
                    if (ddlSegment.SelectedItem.Text != "R&D")
                    {
                        SP.User COEFunHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                        SP.User SiteFunHead = _ws.getSiteSectorHead("SiteSectorHead", ddlSite.SelectedItem.ToString(), ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "SiteSectorHead");

                        if (wfLevel == 0)
                        {
                            lblSiteHead.Text = "Approval Flow :- Manager(" + _Manger + ")-----> Site Function Head(" + SiteFunHead.Title + ")-----> COE Function Head(" + COEFunHead.Title + ") -----> CIPT -> (Subsequent Approval Based on Sensitivity Gradation Matrix)";
                        }
                        else if (wfLevel == 11)
                        {
                            lblSiteHead.Text = "Approval Flow :- CIPT -> (Subsequent Approval Based on Sensitivity Gradation Matrix)";
                        }
                        else if (wfLevel == 21)
                        {
                            lblSiteHead.Text = "Approval Flow :- COE Function Head(" + COEFunHead.Title + ") -----> CIPT -> (Subsequent Approval Based on Sensitivity Gradation Matrix )";
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblSiteHead.Text = "Approver not available";
        }

    }


    protected void ddlProgramTitle_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtJournal.Text = string.Empty;
            string confDetails = "";

            txtTitle.Text = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "Title");

            confDetails = "OrganizedBy:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "OrganizedBy") + ";" + Environment.NewLine;
            confDetails += "Duration:-" + "(" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "Duration") + ");" + Environment.NewLine;
            confDetails += "Start Date:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "StartDate") + "; End Date:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "EndDate") + ";" + Environment.NewLine;
            confDetails += "Location:-" + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "Location");

            txtJournal.Text = confDetails;

            Session["startDate"] = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "StartDate");
            Session["Overseas"] = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", ddlProgramTitle.SelectedValue.ToString()), "Overseas");

            txtConfDate.Text = Convert.ToString(Session["startDate"]);
            rdbConfType.SelectedIndex = (Convert.ToString(Session["Overseas"]) == "No" ? 0 : 1);

            if (ddlProgramTitle.SelectedValue.ToString() == "0")
                txtJournal.Text = string.Empty;

        }
        catch (Exception)
        {
        }
    }
    protected void ddlProgramTitle_DataBound(object sender, EventArgs e)
    {
        ddlProgramTitle.Items.Insert(0, new ListItem("--Select--", "0"));
    }

}


