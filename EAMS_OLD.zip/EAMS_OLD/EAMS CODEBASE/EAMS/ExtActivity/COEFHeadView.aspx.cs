﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;

public partial class MgrView : System.Web.UI.Page
{
    Workshop _ws;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        BindData();

    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.Trim().ToUpper())
        {
            case "VIEW":
                Response.Redirect("Approve.aspx?ID=" + e.CommandArgument.ToString() + "&Level=CFH", true);
                break;
        }
    }
    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();

        //If user Site CTS Head (Aval in 'Group List')|| Request(11) => COE Fun Head(12) => CIPT
       // filters.Add("COEFunHead", string.Empty);
       // filters.Add("WFLevel", "11");
       // filters.Add("DelFlag", "0");
       // filters.Add("draftFlag", "No");
      //  filters.Add("RStatus", "Open");
      //  DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);

        //For general Request || Request(0) => Manager(1) => Site Fun Head(2) => COE Fun Head(3) =>CIPT
        
        filters.Clear();
        filters.Add("COEFunHead", string.Empty);
        filters.Add("WFLevel", "2");
        filters.Add("DelFlag", "0");
        filters.Add("COEFlag", "False");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text", "Text" }, filters: filters);

        //For general Request (COEFlag = 'TRUE') || Request(0) => Manager(1) => COE Fun Head(2) =>CIPT
        filters.Clear();
        filters.Add("COEFunHead", string.Empty);
        filters.Add("WFLevel", "1");
        filters.Add("COEFlag", "True");
        filters.Add("DelFlag", "0");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable gridRequest1 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text", "Text" }, filters: filters);


        //If user Site Head (Aval in 'Site List') || Request(21) => Site Fun Head(22) => COE Fun Head(23) => CIPT
        filters.Clear();
        filters.Add("COEFunHead", string.Empty);
        filters.Add("WFLevel", "21");
        filters.Add("DelFlag", "0");
        filters.Add("draftFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable gridRequest2 = _ws.getListAsGrid(givelistName: "ExternalActivity", columns: new List<string>() { "ID", "EmpName", "Title", "Segment", "Site", "Sector", "Business", "Manager", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "Category", "Abstract", "JournalConfDetail", "RilValue", "ApproveWith", "Patent", "PatentA", "PatentB", "PatentC", "PatentD", "PatentE", "PatentF", "PeerName1", "PeerName2", "PeerName3", "ReqStatus", "Disclosure", "ConfDate", "ConfType", "StatusDate", "KeyReason" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);

        gridRequest.Merge(gridRequest1);
        gridRequest.Merge(gridRequest2);
        //gridRequest.Merge(gridRequest3);

        if (Session["GridRequest"] == null)
            SessionUtility.AddSessionValue(key: "GridRequest", value: gridRequest);
        else
            SessionUtility.UpdateSessionValue(key: "GridRequest", value: gridRequest);

        DataView dv = new DataView(gridRequest);
        dv.Sort = "ID DESC";

        gvGroup.DataSource = dv;
        gvGroup.DataBind();
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("ExternalActivity", int.Parse(Session["_itemID"].ToString()));
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //Label lblReqDate = e.Row.FindControl("lblReqDate") as Label;
            //lblReqDate.Text = Convert.ToDateTime(lblReqDate.Text).ToShortDateString();
            DataRow dr = ((DataRowView)(e.Row.DataItem)).Row;
            LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
            lnkView.Text = dr["RequestID"].ToString();

            DropDownList ddlCoAuthor = e.Row.FindControl("ddlCoAuthor") as DropDownList;
            ddlCoAuthor.DataSource = _ws.getCoAuthor(new KeyValuePair<string, string>("Title", lnkView.Text.Trim()));
            ddlCoAuthor.DataBind();
            string authorName = ddlCoAuthor.Items[0].ToString();
            ddlCoAuthor.Items.RemoveAt(0);
            ddlCoAuthor.Items.Insert(0, authorName + " (A)");

            string WFLevel = DataBinder.Eval(e.Row.DataItem, "WFLevel").ToString();
            if (WFLevel.Equals("0", StringComparison.CurrentCultureIgnoreCase))
            {
                LinkButton lnkDel = e.Row.FindControl("lnkDelete") as LinkButton;
                if (lnkDel != null)
                {
                    lnkDel.Text = "XXX";
                    lnkDel.CssClass = "SetClass";
                    lnkDel.ToolTip = "Sorry u can not add link to any ";
                    lnkDel.CommandName = "XXX";

                }
            }

        }


    }
}