﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Client;
using System.Web.Configuration;


namespace EAMS.Utility
{
    /// <summary>
    /// Summary description for Utility
    /// </summary>
    public static class Utility
    {        

        public static byte[] ReadFully(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }

        public static String GetMIMEType(String filepath)
        {
            System.Security.Permissions.RegistryPermission regPerm =
                new System.Security.Permissions.RegistryPermission(System.Security.Permissions.RegistryPermissionAccess.Read, "\\HKEY_CLASSES_ROOT");
            Microsoft.Win32.RegistryKey classesRoot = Microsoft.Win32.Registry.ClassesRoot;
            System.IO.FileInfo fi = new System.IO.FileInfo(filepath);

            string dotExt = fi.Extension.ToLower();
            Microsoft.Win32.RegistryKey typeKey = classesRoot.OpenSubKey("MIME\\Database\\Content Type");
            foreach (string keyname in typeKey.GetSubKeyNames())
            {
                Microsoft.Win32.RegistryKey curKey = classesRoot.OpenSubKey("MIME\\Database\\Content Type\\" + keyname);

                if (curKey.GetValue("Extension") != null && curKey.GetValue("Extension").ToString().ToLower() == dotExt)
                {
                    return keyname;
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".docx")
                {
                    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".xlsx")
                {
                    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".zip")
                {
                    return "application/octet-stream";
                }

            }
            return string.Empty;
        }


        public static void PopulateDropDownList(this DropDownList ddl, string textField, string valueField, object dataSource)
        {
            ddl.DataSource = dataSource;
            ddl.DataTextField = textField;
            ddl.DataValueField = valueField;
            ddl.DataBind();
        }


        public static User GetUser(string loginName)
        {
            ClientContext ctx = new ClientContext(WebConfigurationManager.AppSettings["_siteCollectionUrl"].ToString());
            Web site = ctx.Web;
            ctx.Load(site);
            ctx.ExecuteQuery();
            return site.EnsureUser(loginName);
        }
    }
}
