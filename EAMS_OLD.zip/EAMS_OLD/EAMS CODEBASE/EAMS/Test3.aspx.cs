﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using WebApplication1;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;
using Microsoft.SharePoint.Client;
using EAMSBusiness;
using System.Security.Principal;

public partial class Grid : System.Web.UI.Page
{
    // Workshop ws = new Workshop();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Response.Write(DateTime.Now.ToString());
           //Response.Write(HttpContext.Current.User.Identity.Name.ToString());
           

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message+"---"+DateTime.Now.ToString());
        }
    }



    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCountry.SelectedValue == "1")
        {
            lblMsg.Text = "Dipak Kachhaway :- 1";
        }
        else
        {
            lblMsg.Text = "Vikas Kachhaway :- 2";
        }
    }
}