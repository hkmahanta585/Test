﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using SP = Microsoft.SharePoint.Client;
using EAMSBusiness;

public partial class EAMSMaster : System.Web.UI.MasterPage
{
    Workshop _ws;
    bool gFlag;
    public EAMSMaster()
    {
        _ws = new Workshop();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lblLoggedInUser.Text = _ws.GetCurrentUserName();
            int groupID = _ws.GetGroupID("EAMSHR");
            gFlag = _ws.IsInGroup(groupID, _ws.GetCurrentUserID());
        }
        catch (Exception ex)
        {
            _ws.LogError("Master Page (Page_Load) :-", ex.Message.ToString());
        }
    }
    protected void NavigationMenu_MenuItemDataBound(Object sender, MenuEventArgs e)
    {
        SiteMapNode node = e.Item.DataItem as SiteMapNode;
        Menu topMenu = (Menu)sender;

        try
        {
            if (node != null)
            {
                if (!gFlag && node.Title == "Masters")
                    topMenu.Items.Remove(e.Item);
                //else if (!gFlag && node.Title == "Publication And Presentation")
                    //topMenu.Items.Remove(e.Item);
                else if (!gFlag && node.Title == "Reports")
                {
                      topMenu.Items.Remove(e.Item);
                }
                else if (!gFlag && node.Title == "Conference List")
                    e.Item.Parent.ChildItems.Remove(e.Item);
                else if (!gFlag && node.Title == "Admin Section")
                    e.Item.Parent.ChildItems.Remove(e.Item);

            }
        }
        catch (Exception ex)
        {
            _ws.LogError("Master Page (NavigationMenu_MenuItemDataBound):-", ex.Message.ToString());
        }
    }
}
