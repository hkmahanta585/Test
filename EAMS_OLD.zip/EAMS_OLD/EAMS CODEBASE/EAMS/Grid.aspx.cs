﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using WebApplication1;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;
using Microsoft.SharePoint.Client;
using EAMSBusiness;
using System.Security.Principal;

public partial class Grid : System.Web.UI.Page
{
    // Workshop ws = new Workshop();
    protected void Page_Load(object sender, EventArgs e)
    {
        Workshop _ws = new Workshop(); ;
        try
        {
            _ws.DeleteMultipleItem("ErrorList");
          /*  Workshop _ws = new Workshop();
            SP.ClientContext ctx = _ws.getClientContext();
            ctx.Load(ctx.Web.CurrentUser);

            WindowsImpersonationContext impersonationContext;
            Response.Write(HttpContext.Current.User.Identity.Name.ToString());
            impersonationContext = ((WindowsIdentity)HttpContext.Current.User.Identity).Impersonate();
            ctx.ExecuteQuery();
            impersonationContext.Undo();
            txtOrganized.Text = ctx.Web.CurrentUser.LoginName;

         */
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }



}