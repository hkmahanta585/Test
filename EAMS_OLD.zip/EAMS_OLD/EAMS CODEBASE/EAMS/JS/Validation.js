﻿$(document).ready(function () {

    $("[id$='txtreason']").bind("keyup keypress change", function (e) {
        var tval = $("[id$='txtreason']").val(),
                tlength = tval.length,
                set = 100,
                remain = parseInt(set - tlength);
        $('.Reason').text(remain);
        if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
            $("[id$='txtreason']").val((tval).substring(0, tlength - 1))
        }
    })

    $("[id$='txtValue']").bind("keyup keypress change", function (e) {
        var tval = $("[id$='txtValue']").val(),
                tlength = tval.length,
                set = 100,
                remain = parseInt(set - tlength);
        $('.Value').text(remain);
        if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
            $("[id$='txtValue']").val((tval).substring(0, tlength - 1))
        }
    })

    $("[id$='txtBudget']").bind("keyup keypress change", function (e) {
        var tval = $("[id$='txtBudget']").val(),
                tlength = tval.length,
                set = 100,
                remain = parseInt(set - tlength);
        $('.Budget').text(remain);
        if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
            $("[id$='txtBudget']").val((tval).substring(0, tlength - 1))
        }
    })



}); 

