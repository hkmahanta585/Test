﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;
using System.IO;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using System.Text;
using System.Security.Principal;




public partial class Workshop_Request : System.Web.UI.Page
{

    #region Private Variables
    Workshop _ws;
    RILUser _rilUser;
    ADService objAD;
    string _editItemID;
    #endregion

    #region Global Variable
    string _manager = string.Empty;
    bool _transFlag = false;
    string _GLRequest = WebConfigurationManager.AppSettings["_GLRequest"].ToString();
    CreateLogFile createLog;
    #endregion

    public void PopulatePageControls()
    {
        string listName = "Segment";
        string keyColumnName = "ID";
        string valueColumnName = "Title";
        ddlSegment.Populateddl(_ws, listName, keyColumnName, valueColumnName);


        listName = "Site";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSite.Populateddl(_ws, listName, keyColumnName, valueColumnName);

        txtCurrentUser.Text = _ws.GetCurrentUserName();
        txtEmpCode.Text = objAD.getUserID(_ws.GetCurrentLoginName().Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries)[1]);

        txtRequestID.Text = "LEC" + DateTime.Now.Year + "XXXX";
    }
    public void PopulatePageControlsWithExisting()
    {
        DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("LECRequest");
        DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();

        (from ListItem lst in ddlSegment.Items where lst.Text == Convert.ToString(drGridRequest["Segment"]) select (lst.Selected = true)).ToList();
        ddlSector.Populateddl(ws: _ws, listName: "Sector", keyColumnName: "ID", valueColumnName: "Title", columnType: "Lookup", filter: new KeyValuePair<string, string>("Segment", ddlSegment.SelectedValue));
        (from ListItem lst in ddlSector.Items where lst.Text == Convert.ToString(drGridRequest["Sector"]) select (lst.Selected = true)).ToList();
        ddlBusiness.Populateddl(ws: _ws, listName: "Group", keyColumnName: "ID", valueColumnName: "Title", columnType: "Choice", filter: new KeyValuePair<string, string>("Sector", ddlSector.SelectedItem.Text));
        (from ListItem lst in ddlBusiness.Items where lst.Text == Convert.ToString(drGridRequest["Business"]) select (lst.Selected = true)).ToList();
        (from ListItem lst in ddlSite.Items where lst.Text == Convert.ToString(drGridRequest["site"]) select (lst.Selected = true)).ToList();
        (from ListItem lst in ddlNDA.Items where lst.Text == Convert.ToString(drGridRequest["NDA"]) select (lst.Selected = true)).ToList();
        // ddlProgramTitle.Populateddl(ws: _ws, listName: "Conference & Workshop", keyColumnName: "WorkshopID", valueColumnName: "NameSDate", columnType: "Choice", filter: new KeyValuePair<string, string>("Category", ddlSeekingforapproval.SelectedItem.Text));
        // (from ListItem lst in ddlProgramTitle.Items where lst.Text == Convert.ToString(drGridRequest["ProgramTitle"]) select (lst.Selected = true)).ToList();
        (from ListItem lst in ddlbudget.Items where lst.Text == Convert.ToString(drGridRequest["BudgetInv"]) select (lst.Selected = true)).ToList();
        //  txtOrganized.Text = drGridRequest["OrgaBy"].ToString();
        lnkAttachFile.Text = drGridRequest["FileLeafRef"].ToString();


        txtTopicName.Text = drGridRequest["Title"].ToString();
        txtTopicDesc.Text = drGridRequest["TopicDesc"].ToString();

        txtPertName.Text = drGridRequest["PertName"].ToString();
        txtWorkingAs.Text = drGridRequest["PertDesig"].ToString();
        txtCompany.Text = drGridRequest["PertComp"].ToString();

        txtkeyReason.Text = drGridRequest["KeyReason"].ToString();
        txtValueRil.Text = drGridRequest["ValueRil"].ToString();
        if (!string.IsNullOrEmpty(Convert.ToString(drGridRequest["NDADesc"])))
        {
            txtNDADesc.Text = Convert.ToString(drGridRequest["NDADesc"]);
            txtNDADesc.Visible = true;
        }
        if (!string.IsNullOrEmpty(Convert.ToString(drGridRequest["DescBudgetInv"])))
        {
            txtBudgetDesc.Text = Convert.ToString(drGridRequest["DescBudgetInv"]);
            txtBudgetDesc.Visible = true;
        }

        ddlFaculty.Items.FindByText(Convert.ToString(drGridRequest["IntFaculty"])).Selected = true;
        if (Convert.ToString(drGridRequest["IntFaculty"]).Contains("Yes"))
        {
            txtFaculty.Text = drGridRequest["IntFacultyDesc"].ToString();
            txtFaculty.Visible = true;
        }

        txtTravel.Text = drGridRequest["CostTravel"].ToString();
        txtAccommodation.Text = drGridRequest["CostAccom"].ToString();
        txtHonorarium.Text = drGridRequest["CostHonor"].ToString();

        txtRequestID.Text = drGridRequest["RequestID"].ToString();
        txtEmpCode.Text = drGridRequest["EmpCode"].ToString();

        if (Convert.ToString(drGridRequest["Comment"]).Length > 0)
        {
            rowComments.Visible = true;
            lblComments.Text = Convert.ToString(drGridRequest["Comment"]);
        }
        Session.Clear();
        Session["ReqStatus"] = Convert.ToString(drGridRequest["ReqStatus"]);
    }

    #region Event Handlers

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        _rilUser = new RILUser();
        objAD = new ADService();
        rowComments.Visible = false;
        createLog = new CreateLogFile();

        _manager = objAD.getManager(_ws.GetCurrentLoginName().Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries)[1]).Split(new string[] { "=", "," }, StringSplitOptions.RemoveEmptyEntries)[1];
        // _manager = _rilUser.GetManager(loginName: _ws.GetCurrentLoginName());
        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }

        if (Request.QueryString["NewReq"] != null)
        {
            if (Request.QueryString["NewReq"].ToString().Contains("Yes")) btnDraft.Visible = false; ;
        }

        if (!IsPostBack)
        {
            Session.Remove("ReqStatus");
            PopulatePageControls();
            if (_editItemID != null)
            {
                Linkrow.Visible = true;
                PopulatePageControlsWithExisting();
            }



        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            CheckForDuplicateRecord();
            CheckNDAField();
            if (_transFlag) { goto ERROR; }
            if (Page.IsValid)
            {
                using (SP.ClientContext context = _ws.getClientContext())
                {
                    string draftFlag = ((Button)sender).CommandArgument;
                    SP.Web site = context.Web;
                    SP.List list = site.Lists.GetByTitle("LECINVList");
                    byte[] contentByteArray;
                    string newfile = string.Empty;
                    string fileName = string.Empty;

                    if (fldFileUpload.HasFile)
                    {
                        contentByteArray = new byte[fldFileUpload.PostedFile.ContentLength];
                        newfile = fldFileUpload.PostedFile.FileName;
                        fileName = txtRequestID.Text.Trim() + "_" + fldFileUpload.FileName;
                    }
                    else
                    {
                        contentByteArray = new byte[10 * 10];
                        fileName = "XXXXX" + DateTime.Now.ToString("yyyyMMddHHmmss");
                    }
                    fldFileUpload.PostedFile.InputStream.Read(contentByteArray, 0, fldFileUpload.PostedFile.ContentLength - 1);
                    SP.File file = null;
                    if (_editItemID == null)
                    {
                        SP.FileCreationInformation fci = new SP.FileCreationInformation();
                        fci.Content = contentByteArray;
                        fci.Overwrite = true;
                        string fileExte = System.IO.Path.GetExtension(fldFileUpload.FileName);

                        fci.Url = _GLRequest + fileName;
                        file = list.RootFolder.Files.Add(fci);
                        context.Load(file.ListItemAllFields);

                        _ws.executeClientContext(context);


                        string requestId = "LEC" + DateTime.Now.ToString("yyyy") + file.ListItemAllFields.Id.ToString("0000");

                        if (fldFileUpload.HasFile)
                            SetFileName(Id: file.ListItemAllFields.Id, fileName: requestId + "-" + fldFileUpload.FileName, context: context, list: list);
                        file.ListItemAllFields["RequestID"] = requestId;

                    }
                    else
                    {
                        SP.ListItem item = list.GetItemById(_editItemID);
                        context.Load(item, itemOld => itemOld.File);

                        _ws.executeClientContext(context);

                        file = item.File;
                        if (fldFileUpload.HasFile)
                        {
                            file.MoveTo(_GLRequest + fileName, SP.MoveOperations.Overwrite);
                            file.SaveBinary(new SP.FileSaveBinaryInformation { Content = contentByteArray });
                        }
                    }

                    file.ListItemAllFields["Title"] = txtTopicName.Text;
                    file.ListItemAllFields["Segment"] = ddlSegment.SelectedItem.Text;
                    file.ListItemAllFields["Site"] = ddlSite.SelectedItem.Text;
                    file.ListItemAllFields["Sector"] = ddlSector.SelectedItem.Text;
                    file.ListItemAllFields["Business"] = ddlBusiness.SelectedItem.Text;

                    //----------------------Danger Zone----------------------------------------

                    ////Level 1 :- current user manager 
                    file.ListItemAllFields["Manager"] = _ws.GetUser(_manager).Id;

                    SP.User siteHead;
                    //Level 2 :- COE Function Head / Site CTS Head (Site = "COE") 
                    if (Check(ddlSite.SelectedValue, _ws.getID("Site", new KeyValuePair<string, string>("SiteID", "06")).ToString()))
                    {
                        siteHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                    }
                    else
                    {
                        siteHead = _ws.getUserFromList("Site", new KeyValuePair<string, string>("Title", ddlSite.SelectedItem.ToString()), "SiteCTSHead");
                    }

                    //RNTFlag (denote wether Segment Head is RnT Head or Not)
                    if (Check(ddlSegment.SelectedValue, _ws.getID("Segment", new KeyValuePair<string, string>("SegmentID", "02")).ToString()))
                    {
                        siteHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                    }

                    file.ListItemAllFields["SiteHead"] = siteHead.Id;
                    file.ListItemAllFields["TopicDesc"] = txtTopicDesc.Text;
                    file.ListItemAllFields["PertName"] = txtPertName.Text;
                    file.ListItemAllFields["PertDesig"] = txtWorkingAs.Text;
                    file.ListItemAllFields["PertComp"] = txtCompany.Text;

                    file.ListItemAllFields["KeyReason"] = txtkeyReason.Text;
                    file.ListItemAllFields["ValueRil"] = txtValueRil.Text;

                    file.ListItemAllFields["NDA"] = ddlNDA.SelectedItem.Text;
                    file.ListItemAllFields["NDADesc"] = txtNDADesc.Text;

                    file.ListItemAllFields["IntFaculty"] = ddlFaculty.SelectedItem.Text;
                    file.ListItemAllFields["IntFacultyDesc"] = txtFaculty.Text;

                    file.ListItemAllFields["CostTravel"] = txtTravel.Text;
                    file.ListItemAllFields["CostAccom"] = txtAccommodation.Text;
                    file.ListItemAllFields["CostHonor"] = txtHonorarium.Text;

                    file.ListItemAllFields["BudgetInv"] = ddlbudget.SelectedItem.Text;
                    file.ListItemAllFields["DescBudgetInv"] = txtBudgetDesc.Text;

                    //file.ListItemAllFields["RStatus"] = "Open";
                    //file.ListItemAllFields["DelFlag"] = "0";

                    //file.ListItemAllFields["WFLevel"] = _ws.GetWFLevel();
                    file.ListItemAllFields["Requstor"] = _ws.GetCurrentUserID();
                    file.ListItemAllFields["EmpName"] = _ws.GetCurrentUserName();

                    //file.ListItemAllFields["EmpCode"] = objAD.getUserID(_ws.GetCurrentLoginName().Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries)[1]);
                    file.ListItemAllFields["EmpCode"] = txtEmpCode.Text;

                    //dipak.d.kachhaway
                    //-------------------------  Todays Work (For Draft / Edit / Modify Request) --------------------------

                    file.ListItemAllFields["DelFlag"] = "0";

                    if (draftFlag.Equals("No"))
                    {
                        file.ListItemAllFields["WFLevel"] = _ws.GetWFLevel();
                        //file.ListItemAllFields["UsrType"] = _ws.GetUsrType();
                        file.ListItemAllFields["ReqStatus"] = "Pending with HOD";
                        file.ListItemAllFields["RStatus"] = "Open";
                        file.ListItemAllFields["Pending"] = "0";
                    }

                    if (draftFlag.Equals("Yes"))
                    {
                        file.ListItemAllFields["WFLevel"] = _ws.GetWFLevel();
                        //file.ListItemAllFields["UsrType"] = _ws.GetUsrType();
                        file.ListItemAllFields["ReqStatus"] = "Draft";
                        file.ListItemAllFields["RStatus"] = "Draft";
                    }
                    if (Session["Status"] != null && Convert.ToString(Session["Status"]).Equals("Modify"))
                    {
                        file.ListItemAllFields["ReqStatus"] = "Re-Submitted";
                        file.ListItemAllFields["RStatus"] = "Open";
                        file.ListItemAllFields["WFLevel"] = (Session["WFLevel"] != null ? Session["WFLevel"].ToString() : "");
                    }

                    file.ListItemAllFields["ChangeFlag"] = "No";

                    if (Convert.ToString(Session["ReqStatus"]).Equals("Change Topic"))
                    {
                        file.ListItemAllFields["ChangeFlag"] = "ChangeDone";
                    }

                    //---------------------------- ReqStatus

                    file.ListItemAllFields["draftFlag"] = draftFlag;
                    file.ListItemAllFields["Status"] = "Pending";
                    file.ListItemAllFields["ReqDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
                    
                    file.ListItemAllFields.Update();
                    _ws.executeClientContext(context);

                    //Execute(context);
                    lblHeader.Text = "Information!";
                    lblmsg.Text = "Record is saved..";
                    mdlSuccess.Show();
                }
            }

        ERROR:
            if (_transFlag)
            {
                mdlDuplicate.Show();
            }
        }
        catch (Exception ex)
        {
            //createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- Catch Block--------<br />" + ex.Message);
        }
    }

    public void CheckForDuplicateRecord()
    {
        if (_ws.CheckEmpExist(empCodeCol: "EmpCode", empCode: txtEmpCode.Text.Trim(), topicCol: "Title", topicName: txtTopicName.Text.Trim(), listName: "LECINVList"))
        {
            if (_editItemID == null)
            {
                _transFlag = true;
            }
        }
        else
        {
            _transFlag = false;
        }
    }
    public void CheckNDAField()
    {
        if (ddlNDA.SelectedItem.Text.Contains("No") && txtNDADesc.Text.Length == 0)
        {
            AddErrorMessage("Have RIL signed NDA");
        }

        if (ddlFaculty.SelectedItem.Text.Contains("Yes") && txtFaculty.Text.Length == 0)
        {
            AddErrorMessage("Internal faculty or training module");
        }
        if (ddlbudget.SelectedItem.Text.Contains("Yes") && txtBudgetDesc.Text.Length == 0)
        {
            AddErrorMessage("Please provide details for budget..");
        }

    }
    public void AddErrorMessage(string message)
    {
        var validator = new CustomValidator();
        validator.IsValid = false;
        validator.ErrorMessage = message;
        Page.Validators.Add(validator);
    }
    public bool Check(string A1, string A2)
    {
        if (A1.Equals(A2, StringComparison.OrdinalIgnoreCase))
            return true;
        else
            return false;
    }
    protected void ddlSegment_SelectedIndexChanged(object sender, EventArgs e)
    {
        string segmentId = ddlSegment.SelectedValue;
        ddlSector.Populateddl(ws: _ws, listName: "Sector", keyColumnName: "ID", valueColumnName: "Title", columnType: "Lookup", filter: new KeyValuePair<string, string>("Segment", segmentId));
    }
    protected void ddlNDA_SelectedIndexChange(object sender, EventArgs e)
    {
        if (ddlNDA.SelectedItem.Text.Equals("No", StringComparison.OrdinalIgnoreCase))
        {
            txtNDADesc.Visible = true;
        }
        else
        {
            txtNDADesc.Visible = false;
        }
    }
    protected void ddlFaculty_SelectedIndexChange(object sender, EventArgs e)
    {
        if (ddlFaculty.SelectedItem.Text.Equals("Yes", StringComparison.OrdinalIgnoreCase))
        {
            txtFaculty.Visible = true;
        }
        else
        {
            txtFaculty.Visible = false;
        }
    }
    protected void ddlbudget_SelectedIndexChange(object sender, EventArgs e)
    {
        if (ddlbudget.SelectedItem.Text.Equals("Yes", StringComparison.OrdinalIgnoreCase))
        {
            txtBudgetDesc.Visible = true;
        }
        else
        {
            txtBudgetDesc.Visible = false;
        }
    }
    protected void ddlSegment_DataBound(object sender, EventArgs e)
    {
        ddlSegment.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
    {
        string sectorName = ddlSector.SelectedItem.ToString();
        ddlBusiness.Populateddl(ws: _ws, listName: "Group", keyColumnName: "ID", valueColumnName: "Title", columnType: "Choice", filter: new KeyValuePair<string, string>("Sector", sectorName));
    }
    protected void ddlSector_DataBound(object sender, EventArgs e)
    {
        ddlSector.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlBusiness_DataBound(object sender, EventArgs e)
    {
        ddlBusiness.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    protected void ddlSite_DataBound(object sender, EventArgs e)
    {
        ddlSite.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Summary.aspx", true);
    }
    protected void lnkAttachFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("LECINVList");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);

            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("LECINVList", int.Parse(Session["_itemID"].ToString()));
    }

    #endregion

    protected void btnSuccess_Click(object sender, EventArgs e)
    {
        Response.Redirect("Summary.aspx", false);
    }
    public void SetFileName(int Id, string fileName, SP.ClientContext context, SP.List list)
    {
        createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- 2.2 break--------<br />");
        SP.ListItem item = list.GetItemById(Id);
        context.Load(item, itemOld => itemOld.File);
        createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- 2.3 break--------<br />");
        _ws.executeClientContext(context);
        createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- 2.4 break--------<br />");
        SP.File file = item.File;
        if (fldFileUpload.HasFile)
        {
            file.MoveTo(_GLRequest + fileName, SP.MoveOperations.Overwrite);
            createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- 2.5 break--------<br />");
        }
    }

}
