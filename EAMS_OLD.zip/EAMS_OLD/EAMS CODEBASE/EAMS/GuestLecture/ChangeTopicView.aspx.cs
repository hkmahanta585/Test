﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;

public partial class Workshop_MyView : System.Web.UI.Page
{
    Workshop _ws;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        BindData();

    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        string newWindowUrl = string.Empty;
        string javaScript = string.Empty;
        switch (e.CommandName.Trim().ToUpper())
        {
            case "EDIT":
                Response.Redirect("Request.aspx?NewReq=Yes&ID=" + e.CommandArgument.ToString(), true);
                break;

            case "VIEW":
                newWindowUrl = "MdlView.aspx?Ref=MyView&ID=" + e.CommandArgument.ToString();
                javaScript =
                "<script type='text/javascript'>\n" +
                "<!--\n" +
                "window.open('" + newWindowUrl + "','winname','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,fullscreen=no,resizable=yes');\n" +
                "// -->\n" +
                "</script>\n";
                Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "", javaScript);
                break;

            case "EDITDELETE":
                this.mdlError.Show();
                break;

            case "DELETE":
                Session["_itemID"] = e.CommandArgument.ToString();
                this.mdlSuccess.Show();
                break;
        }

    }
    public void BindData()
    {
        try
        {
            Dictionary<string, string> filters = new Dictionary<string, string>();
            filters.Add("ReqStatus", "Change Topic");
            filters.Add("DelFlag", "0");
            filters.Add("Requstor", string.Empty);

            DataTable gridRequest = _ws.getListAsGrid(givelistName: "LECINVList", columns: new List<string>() { "ID", "EmpName", "EmpCode", "Title", "TopicDesc", "Segment", "Site", "Sector", "Business", "FileLeafRef", "Author", "RequestID", "WFLevel", "ReqDate", "Status", "Comment", "RStatus", "DelFlag", "ReqStatus", "PertName", "PertDesig", "PertComp", "NDADesc", "NDA", "BudgetInv", "DescBudgetInv", "KeyReason", "ValueRil", "CostTravel", "CostAccom", "CostHonor", "StatusDate", "IntFaculty", "IntFacultyDesc" }, filterColumnType: new List<string>() { "Text", "Text", "User" }, filters: filters);
            if (Session["LECRequest"] == null)
                SessionUtility.AddSessionValue(key: "LECRequest", value: gridRequest);
            else
                SessionUtility.UpdateSessionValue(key: "LECRequest", value: gridRequest);

            //DataView dv = new DataView(gridRequest);
            //dv.Sort = "ID DESC";


            gvGroup.DataSource = gridRequest.AsEnumerable().OrderByDescending(a => Convert.ToInt32(a["ID"].ToString())).CopyToDataTable();
            gvGroup.DataBind();
        }
        catch (Exception ex)
        {
        }
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("LECINVList", int.Parse(Session["_itemID"].ToString()));
        BindData();
    }

    protected void btnSuccess_Click(object sender, EventArgs e)
    {
        Response.Redirect("Summary.aspx", false);
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;

                LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
                lnkView.Text = dr["RequestID"].ToString();

                //Label lblReqDate = e.Row.FindControl("lblReqDate") as Label;
                //lblReqDate.Text = Convert.ToDateTime(lblReqDate.Text).ToShortDateString();


                //Prevent from Deleting
                int wfLevel = Int32.Parse(dr["WFLevel"].ToString());
                string rStatus = dr["WFLevel"].ToString();
                if (wfLevel > 0)
                {
                    LinkButton lnkDel = e.Row.FindControl("lnkDelete") as LinkButton;
                    LinkButton lnkEdit = e.Row.FindControl("lnkEdit") as LinkButton;
                    if (lnkDel != null && lnkEdit != null)
                    {
                        lnkDel.ToolTip = "Sorry you can not 'DELETE' this record..";
                        lnkDel.CommandName = "EDITDELETE";
                        lnkEdit.ToolTip = "Sorry you can not 'EDIT' this record..";
                        lnkEdit.CommandName = "EDITDELETE";
                    }
                }
            }
            catch (Exception)
            {
            }
        }

    }

}
