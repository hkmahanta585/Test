﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Configuration;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using EAMSBusiness;
using WebApplication1;

public partial class MdlView : System.Web.UI.Page
{
    #region Private Members
    string _editItemID;
    Workshop _ws;
    #endregion

    #region Event Handlers
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }

        if (!IsPostBack && _editItemID != null)
        {
            PopulatePageWithData();
        }
    }

    protected void lnkAttachedFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("LECINVList");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    #endregion

    #region Private Methods
    void PopulatePageWithData()
    {
        DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("LECRequest");
        DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();

        lblRequestID.Text = drGridRequest["RequestID"].ToString();
        lblSegment.Text = drGridRequest["Segment"].ToString();
        lblSector.Text = drGridRequest["Sector"].ToString();
        lblBusiness.Text = drGridRequest["Business"].ToString();
        lblSite.Text = drGridRequest["site"].ToString();
        lblEmpName.Text = drGridRequest["Author"].ToString();

        lnkAttachedFile.Text = drGridRequest["FileLeafRef"].ToString();
        if (lnkAttachedFile.Text.Trim().Contains("XXXX"))
        {
            lnkAttachedFile.Visible = false;
        }

        lblName.Text = drGridRequest["PertName"].ToString();
        lblWorkingAs.Text = drGridRequest["PertDesig"].ToString();
        lblCompany.Text = drGridRequest["PertComp"].ToString();

        lblTravel.Text = drGridRequest["CostTravel"].ToString();
        lblAccommodation.Text = drGridRequest["CostAccom"].ToString();
        lblHonorarium.Text = drGridRequest["CostHonor"].ToString();

        lblKeyReason.Text = drGridRequest["KeyReason"].ToString();
        lblValueforRil.Text = drGridRequest["ValueRil"].ToString();

        lblNDA.Text = drGridRequest["NDA"].ToString() + "-" + drGridRequest["NDADesc"].ToString();
        lblBudget.Text = drGridRequest["BudgetInv"].ToString() + "-" + drGridRequest["DescBudgetInv"].ToString();

        lblEmpName.Text = drGridRequest["EmpName"].ToString();
        lblEmpCode.Text = drGridRequest["EmpCode"].ToString();
        lblTopicName.Text = drGridRequest["Title"].ToString();
        lblTopicDesc.Text = drGridRequest["TopicDesc"].ToString();
        lblStatus.Text = drGridRequest["ReqStatus"].ToString(); 
        lblComment.Text = drGridRequest["Comment"].ToString();
        lblStatusDate.Text = drGridRequest["StatusDate"].ToString();
        lblFaculty.Text = Convert.ToString(drGridRequest["IntFaculty"]) + "-" + Convert.ToString(drGridRequest["IntFacultyDesc"]);
    }
    #endregion

    protected void btnOK_Click(object sender, EventArgs e)
    {
        Response.Write("<script language=javascript>this.window.opener = null;window.open('','_self'); window.close();   </script>");
    }
}