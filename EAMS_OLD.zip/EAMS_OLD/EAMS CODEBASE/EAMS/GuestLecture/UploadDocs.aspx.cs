﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;
using System.IO;
using EAMSBusiness;
using System.Data;
using EAMSUtility;

public partial class OffRequest : System.Web.UI.Page
{

    #region Private Variables
    Workshop _ws;
    RILUser _rilUser;
    ADService objAD;
    string _editItemID;
    #endregion

    #region Global Variable
    string requestId = string.Empty;
    string _GLDocs = WebConfigurationManager.AppSettings["_GLDocs"].ToString();
    #endregion

    public void PopulatePageControls()
    {
        string listName = "LECINVList";
        string keyColumnName = "ID";
        string valueColumnName = "RequestID";
        ddlRequestID.GLGetValueForDDL(ws: _ws, listName: listName, keyColumnName: keyColumnName, valueColumnName: valueColumnName, columnType: "Text", filter: new KeyValuePair<string, string>("EmpName", _ws.GetCurrentUserName()));
    }
    #region Event Handlers

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        _rilUser = new RILUser();
        objAD = new ADService();

        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }
        if (!IsPostBack)
        {
            PopulatePageControls();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("GuestLecLib");
            byte[] contentByteArray;
            string newfile = string.Empty;
            string fileName = string.Empty;

            if (fldFileUpload.HasFile)
            {
                contentByteArray = new byte[fldFileUpload.PostedFile.ContentLength];
                newfile = fldFileUpload.PostedFile.FileName;
                fileName = ddlRequestID.Text.Trim() + "_" + fldFileUpload.FileName;
            }
            else
            {
                contentByteArray = new byte[10 * 10];
                fileName = "XXXXX" + DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            fldFileUpload.PostedFile.InputStream.Read(contentByteArray, 0, fldFileUpload.PostedFile.ContentLength - 1);
            SP.File file = null;
            if (_editItemID == null)
            {
                SP.FileCreationInformation fci = new SP.FileCreationInformation();
                fci.Content = contentByteArray;
                fci.Overwrite = true;
                string fileExte = System.IO.Path.GetExtension(fldFileUpload.FileName);
                fci.Url = _GLDocs + fileName;
                file = list.RootFolder.Files.Add(fci);
                context.Load(file.ListItemAllFields);
                _ws.executeClientContext(context);
                string requestId = ddlRequestID.Text.Trim() + "-" + file.ListItemAllFields.Id.ToString("000");
                if (fldFileUpload.HasFile)
                    SetFileName(Id: file.ListItemAllFields.Id, fileName: requestId + "-" + fldFileUpload.FileName, context: context, list: list);
                file.ListItemAllFields["RequestID"] = requestId;
            }
            else
            {
                SP.ListItem item = list.GetItemById(_editItemID);
                context.Load(item, itemOld => itemOld.File);
                _ws.executeClientContext(context);
              
                file = item.File;
                if (fldFileUpload.HasFile)
                {
                    file.MoveTo(_GLDocs + fileName, SP.MoveOperations.Overwrite);
                    file.SaveBinary(new SP.FileSaveBinaryInformation { Content = contentByteArray });
                }
            }
            file.ListItemAllFields["RequestID"] = ddlRequestID.SelectedItem.Text;
            file.ListItemAllFields["DelFlag"] = "0";
            file.ListItemAllFields["Requstor"] = _ws.GetCurrentUserID();
            file.ListItemAllFields["ReqTitle"] = lblProgramTitle.Text;
            file.ListItemAllFields["Comments"] = txtComments.Text;
            file.ListItemAllFields["EmpName"] = _ws.GetCurrentUserName();
            file.ListItemAllFields["UpldDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
            file.ListItemAllFields.Update();
            _ws.executeClientContext(context);
        }
       Response.Redirect("MyDocuments.aspx", true);
    }
    protected void ddlRequestID_DataBound(object sender, EventArgs e)
    {
        ddlRequestID.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyDocuments.aspx", true);
    }
    protected void lnkAttachFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("GuestLecLib");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);
            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();
            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);
            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    protected void btnSuccess_Click(object sender, EventArgs e)
    {
    }
    public void SetFileName(int Id, string fileName, SP.ClientContext context, SP.List list)
    {
        SP.ListItem item = list.GetItemById(Id);
        context.Load(item, itemOld => itemOld.File);
        _ws.executeClientContext(context);
        SP.File file = item.File;
        if (fldFileUpload.HasFile)
        {
            file.MoveTo(_GLDocs + fileName, SP.MoveOperations.Overwrite);
        }
    }


    protected void ddlRequestID_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string _requestTilte = ddlRequestID.SelectedItem.Text;
            lblProgramTitle.Text = _ws.getColumnValue("LECINVList", new KeyValuePair<string, string>("RequestID", _requestTilte), "Title");
        }
        catch (Exception)
        {
        }
    }
}
