﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Configuration;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;
using EAMSBusiness;
using WebApplication1;

public partial class Workshop_Approve : System.Web.UI.Page
{
    #region Private Members
    string _editItemID;
    string _level;
    Workshop _ws;
    int _wfLevel;
    string _role;
    #endregion

    #region Event Handlers
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (Request.QueryString["ID"] != null)
        {
            _editItemID = Request.QueryString["ID"].ToString();
        }

        if (Request.QueryString["Level"] != null)
        {
            _level = Request.QueryString["Level"].ToString();
        }

        if (!IsPostBack && _editItemID != null)
        {
            PopulatePageWithData();
        }
    }

    protected void lnkAttachedFile_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("LECINVList");
            SP.ListItem item = list.GetItemById(_editItemID);
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);

            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);

            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();

            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);

            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }


    protected void btnApprove_Click(object sender, EventArgs e)
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            string listTitle;

            listTitle = "GustHODFeedback";
            _role = "by HOD";

            SP.List list = site.Lists.GetByTitle(listTitle);
            SP.ListItemCreationInformation itemCreationInfo = new SP.ListItemCreationInformation();
            SP.ListItem item = list.AddItem(itemCreationInfo);
            item["Title"] = lblRequestID.Text;
            item["Status"] = ddlStatus.SelectedItem.Text;
            item["Comment"] = txtComment.Text;
            item.Update();
            _ws.executeClientContext(context);

            //Update status in Attendance Library (Main List)
            UpdateRequestStatus(context);
        }
        Response.Redirect("Summary.aspx");
    }
    #endregion

    #region Private Methods
    void PopulatePageWithData()
    {
        DataTable grdRequest = SessionUtility.GetSessionValue<DataTable>("LECRequest");
        DataRow drGridRequest = (from DataRow dr in grdRequest.Rows where dr["ID"].ToString() == _editItemID select dr).FirstOrDefault<DataRow>();
        lblRequestID.Text = drGridRequest["RequestID"].ToString();
        lblSegment.Text = drGridRequest["Segment"].ToString();
        lblSector.Text = drGridRequest["Sector"].ToString();
        lblBusiness.Text = drGridRequest["Business"].ToString();
        lblSite.Text = drGridRequest["site"].ToString();
        lblEmpCode.Text = drGridRequest["EmpCode"].ToString();
        lblEmpName.Text = drGridRequest["Author"].ToString();
        if (drGridRequest["FileLeafRef"].ToString().ToLower().Contains("xxxxx"))
        {
            lnkAttachedFile.Text = string.Empty;
        }
        else
        {
            lnkAttachedFile.Text = drGridRequest["FileLeafRef"].ToString();
        }
        lblTopicName.Text = drGridRequest["Title"].ToString();
        lblTopicDesc.Text = drGridRequest["TopicDesc"].ToString();
        lblName.Text = drGridRequest["PertName"].ToString();
        lblWorkingAs.Text = drGridRequest["PertDesig"].ToString();
        lblCompany.Text = drGridRequest["PertComp"].ToString();
        lblKeyReason.Text = drGridRequest["KeyReason"].ToString();
        lblValueforRil.Text = drGridRequest["ValueRil"].ToString();
        lblNDA.Text = drGridRequest["NDA"].ToString() + " - ";
        if (Convert.ToString(drGridRequest["NDA"]).Contains("No"))
        {
            lblNDADesc.Text = Convert.ToString(drGridRequest["NDADesc"]);
            lblNDADesc.Visible = true;
        }

        txtComment.Text = string.Empty;

        lblTravel.Text = drGridRequest["CostTravel"].ToString();
        lblAccommodation.Text = drGridRequest["CostAccom"].ToString();
        lblHonorarium.Text = drGridRequest["CostHonor"].ToString();
        lblBudget.Text = drGridRequest["BudgetInv"].ToString() + "-" + drGridRequest["DescBudgetInv"].ToString();
        _wfLevel = Int32.Parse(drGridRequest["WFLevel"].ToString());
        Session["_wfLevel"] = _wfLevel.ToString();
        HideControls();
    }

    void HideControls()
    {
        string comment = string.Empty;
        string status = string.Empty;

        comment = _ws.GetFeedBack(listName: "GustHODFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
        status = _ws.GetFeedBack(listName: "GustHODFeedback", returnColumn: "Status", requestID: lblRequestID.Text);

        if (status.Equals("Pending", StringComparison.OrdinalIgnoreCase) || status.Equals("Change Topic", StringComparison.OrdinalIgnoreCase) || string.IsNullOrEmpty(status))
        {
            ddlStatus.Visible = true;
            txtComment.Visible = true;
            txtComment.Text = comment;
            if (status.Contains("Change Topic"))
            {
                txtComment.Text = string.Empty;
                ddlStatus.Items.FindByText("Pending").Selected = true;
            }
            else
            {
                ddlStatus.Items.FindByText((string.IsNullOrEmpty(status) ? "Pending" : status)).Selected = true;
            }

        }
        else
        {
            ddlStatus.Visible = false;
            txtComment.Visible = false;
            divStatus.InnerText = status;
            divComment.InnerText = comment;
            btnApprove.Visible = false;
            btnReject.Text = "OK";
        }

    }

    void UpdateRequestStatus(SP.ClientContext context)
    {
        SP.List list = context.Web.Lists.GetByTitle("LECINVList");
        SP.ListItem item = list.GetItemById(_editItemID);
        context.Load(item, editItem => editItem["WFLevel"], editItem => editItem["Status"]);
        _ws.executeClientContext(context);

        if (ddlStatus.SelectedItem.Text.Equals("Pending", StringComparison.OrdinalIgnoreCase))
        {
            item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
            item["RStatus"] = "Open";
            item["ReqStatus"] = "Pending " + _role;
            item["Pending"] = "2";
        }
        if (ddlStatus.SelectedItem.Text.Equals("Change Topic", StringComparison.OrdinalIgnoreCase))
        {
            item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
            item["RStatus"] = "Open";
            item["ReqStatus"] = "Change Topic";
            item["ChangeFlag"] = "Yes";
        }
        else if (ddlStatus.SelectedItem.Text.Equals("Rejected", StringComparison.OrdinalIgnoreCase))
        {
            item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString()) + 1;
            item["RStatus"] = "Closed";
            item["ReqStatus"] = "Rejected " + _role;
            item["Pending"] = "1";
        }
        else
        {
            item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString()) + 1;
            item["RStatus"] = "Closed";
            item["ReqStatus"] = "Approved " + _role;
            item["Pending"] = "1";
        }
        item["Status"] = ddlStatus.SelectedItem.Text;
        item["StatusDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
        item["Comment"] = txtComment.Text;
        item.Update();
        _ws.executeClientContext(context);
    }
    #endregion

    protected void btnReject_Click(object sender, EventArgs e)
    {
        Response.Redirect("HODView.aspx");
    }
}