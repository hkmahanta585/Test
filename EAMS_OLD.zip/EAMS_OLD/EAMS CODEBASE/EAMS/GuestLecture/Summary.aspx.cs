﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.Web.UI.WebControls;
using EAMSBusiness;
using SP = Microsoft.SharePoint.Client;
using System.Data;

public partial class Workshop_Summary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Workshop _ws = new Workshop();
        Dictionary<string, string> filters = new Dictionary<string, string>();

        filters.Add("Requstor", string.Empty);
        filters.Add("DelFlag", "0");
        DataTable myRequests = _ws.getListAsGrid(givelistName: "LECINVList", columns: new List<string>() { "ID", "Status", "ReqStatus", "RStatus", "DelFlag", "Pending" }, filterColumnType: new List<string>() { "User", "Text" }, filters: filters);

        lblMyRequest.Text = myRequests.Rows.Count.ToString();
        lblDeleted.Text = (from DataRow dr in myRequests.Rows where dr["DelFlag"].ToString().Equals("1") select 1).Count().ToString();
        lblApproved.Text = (from DataRow dr in myRequests.Rows where Convert.ToString(dr["Status"]).Equals("Approved", StringComparison.OrdinalIgnoreCase) select dr).Count().ToString();
        lblPending.Text = (from DataRow dr in myRequests.Rows where dr["RStatus"].ToString().Equals("Open", StringComparison.OrdinalIgnoreCase) && dr["DelFlag"].ToString().Equals("0") select 1).Count().ToString();
        lblRejecte.Text = (from DataRow dr in myRequests.Rows where dr["Status"].ToString().Equals("Rejected", StringComparison.OrdinalIgnoreCase) select 1).Count().ToString();
        lblDraft.Text = (from DataRow dr in myRequests.Rows where dr["RStatus"].ToString().Equals("Draft", StringComparison.OrdinalIgnoreCase) select 1).Count().ToString();
        lblNeedChange.Text = (from DataRow dr in myRequests.Rows where dr["ReqStatus"].ToString().Equals("Change Topic", StringComparison.OrdinalIgnoreCase) select 1).Count().ToString();
        filters.Clear();

        //-------------------- Hide labels -----------------------------------//
       // if (lblMyRequest.Text.Equals("0")) rowMyRequest.Visible = false;
        if (lblDeleted.Text.Equals("0")) rowDeleted.Visible = false;
        if (lblApproved.Text.Equals("0")) rowApprove.Visible = false;
        if (lblPending.Text.Equals("0")) rowPending.Visible = false;
        if (lblRejecte.Text.Equals("0")) rowRejected.Visible = false;
        if (lblDraft.Text.Equals("0")) rowDraft.Visible = false;
        if (lblNeedChange.Text.Equals("0")) rowNeedChange.Visible = false;

        //Set HOD row visible false------------//
        filters.Clear();
        filters.Add("SiteHead", string.Empty);
        filters.Add("WFLevel", "0");
        filters.Add("DelFlag", "0");
        filters.Add("ChangeFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable HODRequest = _ws.getListAsGrid(givelistName: "LECINVList", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);

        filters.Clear();
        filters.Add("SiteHead", string.Empty);
        filters.Add("WFLevel", "0");
        filters.Add("DelFlag", "0");
        filters.Add("ChangeFlag", "ChangeDone");
        filters.Add("RStatus", "Open");
        DataTable HODRequest1 = _ws.getListAsGrid(givelistName: "LECINVList", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);

        filters.Clear();
        filters.Add("SiteHead", string.Empty);
        filters.Add("WFLevel", "21");
        filters.Add("DelFlag", "0");
        filters.Add("ChangeFlag", "No");
        filters.Add("RStatus", "Open");
        DataTable HODRequest2 = _ws.getListAsGrid(givelistName: "LECINVList", columns: new List<string>() { "ID" }, filterColumnType: new List<string>() { "User", "Text", "Text", "Text", "Text" }, filters: filters);


        HODRequest.Merge(HODRequest1);
        HODRequest.Merge(HODRequest2);

        int cHOD = HODRequest.Rows.Count;
        if (cHOD > 0) { }
        lblHOD.Text = cHOD.ToString();
    }
}