﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EAMSBusiness;
using System.Data;
using EAMSUtility;
using SP = Microsoft.SharePoint.Client;

public partial class Workshop_MyView : System.Web.UI.Page
{
    Workshop _ws;

    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        if (!Page.IsPostBack)
        {
            BindData();
        }
    }
    protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        Session["ID"] = e.CommandArgument.ToString();
        switch (e.CommandName.Trim().ToUpper())
        {
            case "DELETE":
                lblMassage.Text = "Are you sure you want to delete this doc.?";
                this.mdlModelDialog.Show();
                break;
        }
    }
   
    protected void lnkFileName_Click(object sender, EventArgs e)
    {
        LinkButton button = (LinkButton)sender;
        GridViewRow row = (GridViewRow)button.NamingContainer;
        if (row != null)
        {
          string itemID = ((LinkButton)sender).CommandArgument.ToString();
          Session["ID"] = itemID;
          DownloadDocument();
        }
    }

    public void BindData()
    {
        Dictionary<string, string> filters = new Dictionary<string, string>();
        filters.Add("DelFlag", "0");
        //filters.Add("Requstor", string.Empty);
        DataTable gridRequest = _ws.getListAsGrid(givelistName: "GuestLecLib", columns: new List<string>() { "ID", "EmpName", "UpldDate", "RequestID", "ReqTitle", "FileLeafRef", "Comments" }, filterColumnType: new List<string>() { "Text" }, filters: filters);

        DataView dv = new DataView(gridRequest);
        dv.Sort = "ID DESC";
        
        gvGroup.DataSource = dv;
        gvGroup.DataBind();
    }
    protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGroup.PageIndex = e.NewPageIndex;
        BindData();
    }
    protected void gvGroup_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        _ws.DeleteItem("GuestLecLib", int.Parse(Session["ID"].ToString()));
        BindData();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
    }
    protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
    }

    public void DownloadDocument()
    {
        using (SP.ClientContext context = _ws.getClientContext())
        {
            SP.Web site = context.Web;
            SP.List list = site.Lists.GetByTitle("GuestLecLib");
            SP.ListItem item = list.GetItemById(int.Parse(Session["ID"].ToString()));
            context.Load(item, itemOld => itemOld.File.ServerRelativeUrl, itemOld => itemOld.File.Name);
            _ws.executeClientContext(context);
            SP.FileInformation fileInfo = SP.File.OpenBinaryDirect(context, item.File.ServerRelativeUrl);
            byte[] fileData = FileUtility.ReadFully(fileInfo.Stream);
            Response.Clear();
            Response.Buffer = true;
            Response.ClearHeaders();
            string fileName = item.File.Name;
            Response.ContentType = FileUtility.GetMIMEType(fileName);
            String userAgent = Request.Headers.Get("User-Agent");
            if (userAgent.Contains("MSIE 7.0"))
            {
                fileName = fileName.Replace(" ", "%20");
            }
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.OutputStream.Write(fileData, 0, fileData.Length);
            Response.Flush();
            Response.End();
        }
    }

}
