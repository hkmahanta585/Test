﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using WebApplication1;
using SP = Microsoft.SharePoint.Client;
using System.Web.Configuration;
using Microsoft.SharePoint.Client;
using EAMSBusiness;
using System.Security.Principal;

public partial class Grid : System.Web.UI.Page
{
    // Workshop ws = new Workshop();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Workshop _ws = new Workshop();
            SP.ClientContext ctx = _ws.getClientContext();
            ctx.Load(ctx.Web.CurrentUser);

            Response.Write("-----------------------------------------------------------<br />");
            Response.Write("Application Pool Acc. :- " + WindowsIdentity.GetCurrent().Name.ToString());
            Response.Write("-----------------------------------------------------------<br />");

            WindowsImpersonationContext impersonationContext;
            Response.Write("Current User identity :- " + HttpContext.Current.User.Identity.Name.ToString());
            impersonationContext = ((WindowsIdentity)HttpContext.Current.User.Identity).Impersonate();
            ctx.ExecuteQuery();
            impersonationContext.Undo();
            Response.Write("-----------------------------------------------------------<br />");
            Response.Write("Sharepoint Context User :- " + ctx.Web.CurrentUser.LoginName);

        }
        catch (Exception ex)
        {
            //Response.Write(ex.Message);
        }
    }



}