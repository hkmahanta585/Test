﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
using EAMSBusiness;
using System.Data;
using Microsoft.Reporting.WebForms;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;

public partial class Reports_Default : System.Web.UI.Page
{
    Workshop _ws;
    string listName = string.Empty;
    string keyColumnName = string.Empty;
    string valueColumnName = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();

        //DataSet rptDS = new DataSet();
        //rptDS.Tables.Add(GetDataTable());
        //string dsPath = HttpContext.Current.Server.MapPath("~/App_Data/ConfDSA.xsd");
        //rptDS.WriteXmlSchema(dsPath);

        // txtSDate.Text = DateTime.Now.AddYears(-1).ToString("dd MMM yyyy");
        // txtEDate.Text = DateTime.Now.ToString("dd MMM yyyy");

        try
        {
            if (!Page.IsPostBack)
            {
                FillDropdown();
                // getRecord();
            }
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btnExl);
        }
        catch (Exception)
        {
        }
    }

    public void getRecord()
    {
        DataTable dtReport = GetDisplayTable();
        DataTable dtData;
        DataTable filteredRows = null;
        Dictionary<string, string> filters = new Dictionary<string, string>();
        Dictionary<string, string> filters1 = new Dictionary<string, string>();

        string filter = (txtECName.Text.Length > 1 ? "ECNAME" : txtECName.Text);

        filters.Clear();
        try
        {
            if (filter.Contains("ECNAME"))
            {
                filters.Add("EmpName", txtECName.Text);
            }
        }
        catch (Exception) { }
        if (filter.Contains("CONF"))
        {
            filters.Add("ConfID", "CONF");
        }
        try
        {
            if (ddlSegement.SelectedItem.Text != "--Select--")
            {
                filters.Add("Segment", ddlSegement.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlSector.SelectedItem.Text != "--Select--")
            {
                filters.Add("Sector", ddlSector.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlGroup.SelectedItem.Text != "--Select--")
            {
                filters.Add("Business", ddlGroup.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlSite.SelectedItem.Text != "--Select--")
            {
                filters.Add("Site", ddlSite.SelectedItem.Text);
            }
        }
        catch (Exception) { }

        try
        {
            if (ddlReqStatus.SelectedItem.Text != "--Select--")
            {
                filters.Add("RStatus", ddlReqStatus.SelectedItem.Text);
            }
        }
        catch (Exception) { }

        try
        {
            if (txtRequestID.Text.Length > 0)
            {
                filters.Add("RequestID", txtRequestID.Text);
            }
        }
        catch (Exception) { }

        DataTable dt = GetDataTable();
        switch (filters.Count)
        {
            case 1:
                dtData = _ws.getReportsNew(givelistName: "ExternalActivity", filterColumnType: new List<string>() { "Text" }, table: dt, filters: filters);
                break;
            case 2:
                dtData = _ws.getReportsNew(givelistName: "ExternalActivity", filterColumnType: new List<string>() { "Text", "Text" }, table: dt, filters: filters);
                break;
            case 3:
                dtData = _ws.getReportsNew(givelistName: "ExternalActivity", filterColumnType: new List<string>() { "Text", "Text", "Text" }, table: dt, filters: filters);
                break;
            case 4:
                dtData = _ws.getReportsNew(givelistName: "ExternalActivity", filterColumnType: new List<string>() { "Text", "Text", "Text", "Text" }, table: dt, filters: filters);
                break;
            case 5:
                dtData = _ws.getReportsNew(givelistName: "ExternalActivity", filterColumnType: new List<string>() { "Text", "Text", "Text", "Text", "Text" }, table: dt, filters: filters);
                break;
            case 6:
                dtData = _ws.getReportsNew(givelistName: "ExternalActivity", filterColumnType: new List<string>() { "Text", "Text", "Text", "Text", "Text", "Text" }, table: dt, filters: filters);
                break;
            default:
                dtData = null;
                break;
        }

        try
        {
            if (dtData.Rows.Count > 0)
            {
                if (txtSSDate.Text.Length > 0 && txtSEDate.Text.Length == 0)
                {
                    DateTime sSdt = DateTime.Parse(txtSSDate.Text);
                    //DateTime sEdt = DateTime.Parse(txtSEDate.Text);

                    filteredRows = dtData.AsEnumerable()
                     .Where(r => Convert.ToDateTime(r.Field<string>("Created")).Date >= sSdt.Date)
                     .CopyToDataTable();
                }
                else if (txtSSDate.Text.Length == 0 && txtSEDate.Text.Length > 0)
                {

                    //DateTime cSdt = DateTime.Parse(txtSSDate.Text);
                    DateTime cEdt = DateTime.Parse(txtSEDate.Text);

                    filteredRows = dtData.AsEnumerable()
                    .Where(r => Convert.ToDateTime(r.Field<string>("Created")).Date <= cEdt.Date)
                     .CopyToDataTable();
                }
                else if (txtSSDate.Text.Length > 0 && txtSEDate.Text.Length > 0)
                {

                    DateTime sSdt = DateTime.Parse(txtSSDate.Text);
                    DateTime sEdt = DateTime.Parse(txtSEDate.Text);

                    //DateTime cSdt = DateTime.Parse(txtSSDate.Text);
                    //DateTime cEdt = DateTime.Parse(txtSEDate.Text);

                    filteredRows = dtData.AsEnumerable()
                     .Where(r => Convert.ToDateTime(r.Field<string>("Created")).Date >= sSdt.Date && Convert.ToDateTime(r.Field<string>("Created")).Date <= sEdt.Date)
                     .CopyToDataTable();
                }
                else
                {
                    filteredRows = dtData;
                }
            }
            else
            {
                filteredRows = null;
            }
        }
        catch (Exception ex)
        {
            filteredRows = dtData;
        }

        /* try
         {
             if (dtData.Rows.Count > 0)
             {
                 if (txtSSDate.Text.Length > 0)
                 {
                     DateTime sSdt = DateTime.Parse(txtSSDate.Text);
                     DateTime sEdt = DateTime.Parse(txtSEDate.Text);

                     filteredRows = dtData.AsEnumerable()
                      .Where(r => Convert.ToDateTime(r.Field<string>("ReqDate")).Date >= sSdt.Date && Convert.ToDateTime(r.Field<string>("ReqDate")).Date <= sEdt.Date)
                      .CopyToDataTable();
                 }
                 else
                 {
                     filteredRows = dtData;
                 }
             }
             else
             {
                 filteredRows = null;
             }
         }
         catch (Exception ex)
         {
             filteredRows = dtData;
         }*/

        DataRow dr;
        int rowIndex;
        if (filteredRows != null)
        {
            foreach (DataRow row in filteredRows.Rows)
            {
                dr = dtReport.NewRow();
                string reqID = Convert.ToString(row["RequestID"]);

                filters1.Clear();
                filters1.Add("Title", reqID);
                DataTable dtStatus = _ws.getListAsGrid(givelistName: "ExtMgrFeedback", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                rowIndex = dtStatus.Rows.Count;
                if (rowIndex > 0)
                {
                    dr["Manager"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                    dr["Mgr Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                    dr["Mgr Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                    dr["Mgr Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                }

                //For Site Funcion Head
                dtStatus = _ws.getListAsGrid(givelistName: "ExtSiteFHead", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                rowIndex = dtStatus.Rows.Count;
                if (rowIndex > 0)
                {
                    dr["SiteFunHead"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                    dr["SFH Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                    dr["SFH Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                    dr["SFH Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                }

                //For COE Funcion Head
                dtStatus = _ws.getListAsGrid(givelistName: "ExtCOEFHead", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                rowIndex = dtStatus.Rows.Count;
                if (rowIndex > 0)
                {
                    dr["COEFunHead"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                    dr["COE Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                    dr["COE Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                    dr["COE Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                }

                //For COE Funcion Head
                dtStatus = _ws.getListAsGrid(givelistName: "ExtCOEFHead", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                rowIndex = dtStatus.Rows.Count;
                if (rowIndex > 0)
                {
                    dr["COEFunHead"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                    dr["COE Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                    dr["COE Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                    dr["COE Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                }

                //For CIPT
                dtStatus = _ws.getListAsGrid(givelistName: "ExtCIPTFeedBack", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                rowIndex = dtStatus.Rows.Count;
                if (rowIndex > 0)
                {
                    dr["CIPT"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                    dr["CIPT Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                    dr["CIPT Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                    dr["CIPT Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                }

                //For LevelA
                dtStatus = _ws.getListAsGrid(givelistName: "ExtLevelAFeedback", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                rowIndex = dtStatus.Rows.Count;
                if (rowIndex > 0)
                {
                    dr["Level A"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                    dr["LA Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                    dr["LA Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                    dr["LA Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                }

                //For LevelB
                dtStatus = _ws.getListAsGrid(givelistName: "ExtLevelBFeedback", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                rowIndex = dtStatus.Rows.Count;
                if (rowIndex > 0)
                {
                    dr["Level B"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                    dr["LB Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                    dr["LB Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                    dr["LB Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                }

                //For LevelC
                dtStatus = _ws.getListAsGrid(givelistName: "ExtLevelBFeedback", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                rowIndex = dtStatus.Rows.Count;
                if (rowIndex > 0)
                {
                    dr["Level C"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                    dr["LC Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                    dr["LC Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                    dr["LC Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                }

                //For LevelD
                /* dtStatus = _ws.getListAsGrid(givelistName: "ExtLevelBFeedback", columns: new List<string>() { "ID", "Title", "Status", "Comment", "Created", "Author" }, filterColumnType: new List<string>() { "Text" }, filters: filters1);
                 rowIndex = dtStatus.Rows.Count;
                 if (rowIndex > 0)
                 {
                     //dr["Level D"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Author"]);
                     dr["LD Status"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Status"]);
                     dr["LD Comment"] = Convert.ToString(dtStatus.Rows[rowIndex - 1]["Comment"]);
                     dr["LD Appr Date"] = _ws.GetDate(Convert.ToString(dtStatus.Rows[rowIndex - 1]["Created"]), "dd-MMM-yyyy");
                 }*/

                dr["Modified By"] = Convert.ToString(row["Modified_x0020_By"]);
                dr["Created By"] = Convert.ToString(row["Created_x0020_By"]);
                dr["Title"] = Convert.ToString(row["Title"]);

                dr["OffAddress"] = Convert.ToString(row["OffAddress"]);
                dr["Category"] = Convert.ToString(row["Category"]);
                //dr["Abstract"] = Convert.ToString(row["Abstract"]);
                //dr["JournalConfDetail"] = Convert.ToString(row["JournalConfDetail"]);
                //dr["RilValue"] = Convert.ToString(row["RilValue"]);
                //dr["ApproveWith"] = Convert.ToString(row["ApproveWith"]);


                //dr["CIPT"] = Convert.ToString(row["CIPT"]);
                //dr["DelFlag"] = Convert.ToString(row["DelFlag"]);
                //dr["WFLevel"] = Convert.ToString(row["WFLevel"]);
                //dr["UsrType"] = Convert.ToString(row["UsrType"]);


                dr["RequestID"] = Convert.ToString(row["RequestID"]);

                dr["ReqDate"] = Convert.ToString(row["ReqDate"]);

                dr["Status"] = Convert.ToString(row["Status"]);
                dr["RStatus"] = Convert.ToString(row["RStatus"]);
                dr["Comment"] = Convert.ToString(row["Comment"]);
                //dr["KeyReason"] = Convert.ToString(row["KeyReason"]);
                //dr["COEFlag"] = Convert.ToString(row["COEFlag"]);
                dr["PeerName1"] = Convert.ToString(row["PeerName1"]);
                dr["PeerName2"] = Convert.ToString(row["PeerName2"]);
                dr["PeerName3"] = Convert.ToString(row["PeerName3"]);
                dr["Requestor"] = Convert.ToString(row["Requestor"]);
                //dr["ConfDate"] = Convert.ToString(row["ConfDate"]);
                //dr["ConfType"] = Convert.ToString(row["ConfType"]);
                dr["DisclosureType"] = Convert.ToString(row["DisclosureType"]);
                //dr["DisclosureDef"] = Convert.ToString(row["DisclosureDef"]);
                //dr["Disclosure"] = Convert.ToString(row["Disclosure"]);
                //dr["EmpName"] = Convert.ToString(row["EmpName"]);
                dr["PatentA"] = Convert.ToString(row["PatentA"]);
                dr["PatentB"] = Convert.ToString(row["PatentB"]);
                dr["PatentC"] = Convert.ToString(row["PatentC"]);
                dr["PatentD"] = Convert.ToString(row["PatentD"]);
                dr["PatentE"] = Convert.ToString(row["PatentE"]);
                dr["Patent"] = Convert.ToString(row["Patent"]);
                dr["ReqStatus"] = Convert.ToString(row["ReqStatus"]);
                dr["Grade"] = Convert.ToString(row["Grade"]);
                //dr["CheckOut"] = Convert.ToString(row["CheckOut"]);
                //dr["CheckedBy"] = Convert.ToString(row["CheckedBy"]);
                dr["PatentF"] = Convert.ToString(row["PatentF"]);
                dr["Business"] = Convert.ToString(row["Business"]);
                dr["Sector"] = Convert.ToString(row["Sector"]);
                dr["Segment"] = Convert.ToString(row["Segment"]);
                dr["Site"] = Convert.ToString(row["Site"]);
                //dr["LevelB"] = Convert.ToString(row["LevelB"]);
                //dr["LevelA"] = Convert.ToString(row["LevelA"]);
                //dr["LevelC"] = Convert.ToString(row["LevelC"]);
                //dr["LevelD"] = Convert.ToString(row["LevelD"]);
                //dr["LevelE"] = Convert.ToString(row["LevelE"]);
                //dr["TechCOEFlag"] = Convert.ToString(row["TechCOEFlag"]);
                //dr["RNTFlag"] = Convert.ToString(row["RNTFlag"]);
                dr["TechSitePress"] = Convert.ToString(row["TechSitePress"]);
                dr["GMSHead"] = Convert.ToString(row["GMSHead"]);
                //dr["LevelFlag"] = Convert.ToString(row["LevelFlag"]);
                //dr["LevelCount"] = Convert.ToString(row["LevelCount"]);
                //dr["GradeKey"] = Convert.ToString(row["GradeKey"]);
                // dr["StatusDate"] = Convert.ToString(row["StatusDate"]);
                //dr["draftFlag"] = Convert.ToString(row["draftFlag"]);
                //dr["MDFLevel"] = Convert.ToString(row["MDFLevel"]);
                // dr["PeerStatus"] = Convert.ToString(row["PeerStatus"]);
                //dr["LevelARole"] = Convert.ToString(row["LevelARole"]);
                //dr["LevelBRole"] = Convert.ToString(row["LevelBRole"]);
                //dr["LevelCRole"] = Convert.ToString(row["LevelCRole"]);
                //dr["LevelDRole"] = Convert.ToString(row["LevelDRole"]);
                //dr["LevelERole"] = Convert.ToString(row["LevelERole"]);
                dr["IPCLReportName"] = Convert.ToString(row["IPCLReportName"]);
                //dr["RFlag"] = Convert.ToString(row["RFlag"]);
                //dr["EmailFlag"] = Convert.ToString(row["EmailFlag"]);
                //dr["ProgrammTitle"] = Convert.ToString(row["ProgrammTitle"]);
                //dr["ID"] = Convert.ToString(row["ID"]);
                dr["Created"] = Convert.ToString(row["Created"]);
                dr["Modified"] = Convert.ToString(row["Modified"]);
                //dr["Last Modified"] = Convert.ToString(row["Last_x0020_Modified"]);
                // dr["Created Date"] = Convert.ToString(row["Created_x0020_Date"]);

                dr["Conference ID"] = Convert.ToString(row["ProgrammTitle"]);
                dr["Conference Name"] = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(row["ProgrammTitle"])), "Title");
                dr["Overseas"] = Convert.ToString(row["ConfType"]) == "1" ? "Yes" : "No";
                dr["Conf Start Date"] = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(row["ProgrammTitle"])), "StartDate");
                dr["Conf End Date"] = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(row["ProgrammTitle"])), "EndDate");

                dtReport.Rows.Add(dr);
            }
            DisplayReport(dtReport);
        }
        else
        {
            DisplayReport(filteredRows);
        }

    }
    public void DisplayReport(DataTable dt)
    {
        try
        {
            gvConference.DataSource = dt;
            gvConference.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    public DataTable GetDataTable()
    {
        DataTable dt = new DataTable();

        dt.Columns.Add("Modified_x0020_By", typeof(string));
        dt.Columns.Add("Created_x0020_By", typeof(string));
        dt.Columns.Add("Title", typeof(string));
        dt.Columns.Add("Manager", typeof(string));
        dt.Columns.Add("OffAddress", typeof(string));
        dt.Columns.Add("Category", typeof(string));
        dt.Columns.Add("Abstract", typeof(string));
        dt.Columns.Add("JournalConfDetail", typeof(string));
        dt.Columns.Add("RilValue", typeof(string));
        dt.Columns.Add("ApproveWith", typeof(string));
        dt.Columns.Add("COEFunHead", typeof(string));
        dt.Columns.Add("SiteFunHead", typeof(string));
        dt.Columns.Add("CIPT", typeof(string));
        dt.Columns.Add("DelFlag", typeof(string));
        dt.Columns.Add("WFLevel", typeof(string));
        dt.Columns.Add("UsrType", typeof(string));
        dt.Columns.Add("ReqDate", typeof(string));
        dt.Columns.Add("RequestID", typeof(string));
        dt.Columns.Add("Status", typeof(string));
        dt.Columns.Add("RStatus", typeof(string));
        dt.Columns.Add("Comment", typeof(string));
        dt.Columns.Add("KeyReason", typeof(string));
        dt.Columns.Add("COEFlag", typeof(string));
        dt.Columns.Add("PeerName1", typeof(string));
        dt.Columns.Add("PeerName2", typeof(string));
        dt.Columns.Add("PeerName3", typeof(string));
        dt.Columns.Add("Requestor", typeof(string));
        dt.Columns.Add("ConfDate", typeof(string));
        dt.Columns.Add("ConfType", typeof(string));
        dt.Columns.Add("DisclosureType", typeof(string));
        dt.Columns.Add("DisclosureDef", typeof(string));
        dt.Columns.Add("Disclosure", typeof(string));
        dt.Columns.Add("EmpName", typeof(string));
        dt.Columns.Add("PatentA", typeof(string));
        dt.Columns.Add("PatentB", typeof(string));
        dt.Columns.Add("PatentC", typeof(string));
        dt.Columns.Add("PatentD", typeof(string));
        dt.Columns.Add("PatentE", typeof(string));
        dt.Columns.Add("Patent", typeof(string));
        dt.Columns.Add("ReqStatus", typeof(string));
        dt.Columns.Add("Grade", typeof(string));
        dt.Columns.Add("CheckOut", typeof(string));
        dt.Columns.Add("CheckedBy", typeof(string));
        dt.Columns.Add("PatentF", typeof(string));
        dt.Columns.Add("Business", typeof(string));
        dt.Columns.Add("Sector", typeof(string));
        dt.Columns.Add("Segment", typeof(string));
        dt.Columns.Add("Site", typeof(string));
        dt.Columns.Add("LevelB", typeof(string));
        dt.Columns.Add("LevelA", typeof(string));
        dt.Columns.Add("LevelC", typeof(string));
        dt.Columns.Add("LevelD", typeof(string));
        dt.Columns.Add("LevelE", typeof(string));
        dt.Columns.Add("TechCOEFlag", typeof(string));
        dt.Columns.Add("RNTFlag", typeof(string));
        dt.Columns.Add("TechSitePress", typeof(string));
        dt.Columns.Add("GMSHead", typeof(string));
        dt.Columns.Add("LevelFlag", typeof(string));
        dt.Columns.Add("LevelCount", typeof(string));
        dt.Columns.Add("GradeKey", typeof(string));
        dt.Columns.Add("StatusDate", typeof(string));
        dt.Columns.Add("draftFlag", typeof(string));
        dt.Columns.Add("MDFLevel", typeof(string));
        dt.Columns.Add("PeerStatus", typeof(string));
        dt.Columns.Add("LevelARole", typeof(string));
        dt.Columns.Add("LevelBRole", typeof(string));
        dt.Columns.Add("LevelCRole", typeof(string));
        dt.Columns.Add("LevelDRole", typeof(string));
        dt.Columns.Add("LevelERole", typeof(string));
        dt.Columns.Add("IPCLReportName", typeof(string));
        dt.Columns.Add("RFlag", typeof(string));
        dt.Columns.Add("EmailFlag", typeof(string));
        dt.Columns.Add("ProgrammTitle", typeof(string));
        dt.Columns.Add("ID", typeof(string));
        dt.Columns.Add("Created", typeof(string));
        dt.Columns.Add("Modified", typeof(string));
        dt.Columns.Add("Last_x0020_Modified", typeof(string));
        dt.Columns.Add("Created_x0020_Date", typeof(string));


        return dt;
    }
    public DataTable GetDisplayTable()
    {
        DataTable dt = new DataTable();

        //dt.Columns.Add("ID", typeof(string));
        dt.Columns.Add("RequestID", typeof(string));
        dt.Columns.Add("Title", typeof(string));


        dt.Columns.Add("Conference ID", typeof(string));
        dt.Columns.Add("Conference Name", typeof(string));
        dt.Columns.Add("Overseas", typeof(string));
        dt.Columns.Add("Conf Start Date", typeof(string));
        dt.Columns.Add("Conf End Date", typeof(string));

        dt.Columns.Add("Status", typeof(string));
        dt.Columns.Add("RStatus", typeof(string));
        dt.Columns.Add("Comment", typeof(string));
        dt.Columns.Add("ReqDate", typeof(string));
        dt.Columns.Add("Requestor", typeof(string));
        //dt.Columns.Add("EmpName", typeof(string));
        dt.Columns.Add("ReqStatus", typeof(string));

        dt.Columns.Add("Site", typeof(string));
        dt.Columns.Add("Segment", typeof(string));
        dt.Columns.Add("Sector", typeof(string));
        dt.Columns.Add("Business", typeof(string));

        //dt.Columns.Add("LevelB", typeof(string));
        //dt.Columns.Add("LevelA", typeof(string));
        //dt.Columns.Add("LevelC", typeof(string));
        //dt.Columns.Add("LevelD", typeof(string));
        //dt.Columns.Add("LevelE", typeof(string));

        dt.Columns.Add("Manager", typeof(string));
        dt.Columns.Add("Mgr Status", typeof(string));
        dt.Columns.Add("Mgr Comment", typeof(string));
        dt.Columns.Add("Mgr Appr Date", typeof(string));

        dt.Columns.Add("SiteFunHead", typeof(string));
        dt.Columns.Add("SFH Status", typeof(string));
        dt.Columns.Add("SFH Comment", typeof(string));
        dt.Columns.Add("SFH Appr Date", typeof(string));

        dt.Columns.Add("COEFunHead", typeof(string));
        dt.Columns.Add("COE Status", typeof(string));
        dt.Columns.Add("COE Comment", typeof(string));
        dt.Columns.Add("COE Appr Date", typeof(string));

        dt.Columns.Add("CIPT", typeof(string));
        dt.Columns.Add("CIPT Status", typeof(string));
        dt.Columns.Add("CIPT Comment", typeof(string));
        dt.Columns.Add("CIPT Appr Date", typeof(string));

        dt.Columns.Add("Level A", typeof(string));
        dt.Columns.Add("LA Status", typeof(string));
        dt.Columns.Add("LA Comment", typeof(string));
        dt.Columns.Add("LA Appr Date", typeof(string));

        dt.Columns.Add("Level B", typeof(string));
        dt.Columns.Add("LB Status", typeof(string));
        dt.Columns.Add("LB Comment", typeof(string));
        dt.Columns.Add("LB Appr Date", typeof(string));

        dt.Columns.Add("Level C", typeof(string));
        dt.Columns.Add("LC Status", typeof(string));
        dt.Columns.Add("LC Comment", typeof(string));
        dt.Columns.Add("LC Appr Date", typeof(string));

       /* dt.Columns.Add("Level D", typeof(string));
        dt.Columns.Add("LD Status", typeof(string));
        dt.Columns.Add("LD Comment", typeof(string));
        dt.Columns.Add("LD Appr Date", typeof(string));*/

        dt.Columns.Add("OffAddress", typeof(string));
        dt.Columns.Add("Category", typeof(string));
        dt.Columns.Add("Abstract", typeof(string));
        dt.Columns.Add("JournalConfDetail", typeof(string));
        //dt.Columns.Add("RilValue", typeof(string));

        //dt.Columns.Add("KeyReason", typeof(string));

        dt.Columns.Add("PeerName1", typeof(string));
        dt.Columns.Add("PeerName2", typeof(string));
        dt.Columns.Add("PeerName3", typeof(string));

        //dt.Columns.Add("ConfDate", typeof(string));
        //dt.Columns.Add("ConfType", typeof(string));
        dt.Columns.Add("DisclosureType", typeof(string));
        //dt.Columns.Add("DisclosureDef", typeof(string));
        //dt.Columns.Add("Disclosure", typeof(string));

        dt.Columns.Add("PatentA", typeof(string));
        dt.Columns.Add("PatentB", typeof(string));
        dt.Columns.Add("PatentC", typeof(string));
        dt.Columns.Add("PatentD", typeof(string));
        dt.Columns.Add("PatentE", typeof(string));
        dt.Columns.Add("Patent", typeof(string));

        dt.Columns.Add("Grade", typeof(string));

        dt.Columns.Add("PatentF", typeof(string));



        dt.Columns.Add("TechSitePress", typeof(string));
        dt.Columns.Add("GMSHead", typeof(string));




        /*dt.Columns.Add("PeerStatus", typeof(string));
        dt.Columns.Add("LevelARole", typeof(string));
        dt.Columns.Add("LevelBRole", typeof(string));
        dt.Columns.Add("LevelCRole", typeof(string));
        dt.Columns.Add("LevelDRole", typeof(string));
        dt.Columns.Add("LevelERole", typeof(string));*/
        dt.Columns.Add("IPCLReportName", typeof(string));




        /*dt.Columns.Add("ApproveWith", typeof(string));
         dt.Columns.Add("DelFlag", typeof(string));
         dt.Columns.Add("COEFlag", typeof(string));
         dt.Columns.Add("RFlag", typeof(string));
         dt.Columns.Add("EmailFlag", typeof(string));
         dt.Columns.Add("WFLevel", typeof(string));
         dt.Columns.Add("UsrType", typeof(string));
         dt.Columns.Add("MDFLevel", typeof(string));
         dt.Columns.Add("LevelFlag", typeof(string));
         dt.Columns.Add("LevelCount", typeof(string));
         dt.Columns.Add("GradeKey", typeof(string));
         dt.Columns.Add("draftFlag", typeof(string));
         dt.Columns.Add("CheckOut", typeof(string));
         dt.Columns.Add("CheckedBy", typeof(string));
         dt.Columns.Add("TechCOEFlag", typeof(string));
         dt.Columns.Add("RNTFlag", typeof(string));
         dt.Columns.Add("StatusDate", typeof(string));*/


        dt.Columns.Add("Created", typeof(string));
        //dt.Columns.Add("Created Date", typeof(string));
        dt.Columns.Add("Created By", typeof(string));
        dt.Columns.Add("Modified", typeof(string));
        dt.Columns.Add("Modified By", typeof(string));
        // dt.Columns.Add("Last Modified", typeof(string));



        return dt;
    }
    public void FillDropdown()
    {
        listName = "Segment";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSegement.PopulateddlNewA(_ws, listName, keyColumnName, valueColumnName);
        ddlSegement.Items.Insert(0, "--Select--");

        listName = "Site";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSite.PopulateddlNewA(_ws, listName, keyColumnName, valueColumnName);
        ddlSite.Items.Insert(0, "--Select--");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        getRecord();
    }
    protected void ddlSegement_SelectedIndexChanged(object sender, EventArgs e)
    {
        listName = "Sector";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSector.PopulateddlNew(_ws, listName, keyColumnName, valueColumnName, "Text", new KeyValuePair<string, string>("Segment", ddlSegement.SelectedItem.Text));
        ddlSector.Items.Insert(0, "--Select--");
    }
    protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
    {
        listName = "Group";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlGroup.PopulateddlNew(_ws, listName, keyColumnName, valueColumnName, "Text", new KeyValuePair<string, string>("Sector", ddlSector.SelectedItem.Text));
        ddlGroup.Items.Insert(0, "--Select--");
    }
    protected void btnExl_Click(object sender, EventArgs e)
    {
        if ((gvConference.Visible == true) && (gvConference.Rows.Count > 1))
        {
            Response.Clear();
            Response.Buffer = true;
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("content-disposition", "attachment;filename=MyFiles.xls");
            Response.Charset = "";
            this.EnableViewState = false;

            System.IO.StringWriter sw = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htw = new System.Web.UI.HtmlTextWriter(sw);

            gvConference.RenderControl(htw);

            Response.Write(sw.ToString());
            Response.End();

        }
    }

    public override void RenderControl(HtmlTextWriter writer)
    {
        base.RenderControl(writer);
    }

    protected override void RenderChildren(HtmlTextWriter writer)
    {
        base.RenderChildren(writer);
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
        for (int i = 0; i < control.Controls.Count; i++)
        {
            Control current = control.Controls[i];
            if (current is LinkButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                LinkButton).Text));
            }
            else if (current is ImageButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                ImageButton).AlternateText));
            }
            else if (current is HyperLink)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                HyperLink).Text));
            }
            else if (current is DropDownList)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                DropDownList).SelectedItem.Text));
            }
            else if (current is CheckBox)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                CheckBox).Checked ? "×›×Ÿ" : "×œ×"));
            }
            if (current.HasControls())
            {
                VerifyRenderingInServerForm(current);
            }
        }
    }
}