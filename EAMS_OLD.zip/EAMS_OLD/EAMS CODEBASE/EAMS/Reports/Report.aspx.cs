﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
using EAMSBusiness;
using System.Data;
using Microsoft.Reporting.WebForms;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System.Globalization;

public partial class Reports_Default : System.Web.UI.Page
{
    Workshop _ws;
    string listName = string.Empty;
    string keyColumnName = string.Empty;
    string valueColumnName = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();

        //DataSet rptDS = new DataSet();
        //rptDS.Tables.Add(GetDataTable());
        //string dsPath = HttpContext.Current.Server.MapPath("~/App_Data/ConfDSA.xsd");
        //rptDS.WriteXmlSchema(dsPath);

        // txtSDate.Text = DateTime.Now.AddYears(-1).ToString("dd MMM yyyy");
        // txtEDate.Text = DateTime.Now.ToString("dd MMM yyyy");

        try
        {
            if (!Page.IsPostBack)
            {
                FillDropdown();
                // getRecord();
            }
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btnExl);
        }
        catch (Exception)
        {
        }
    }

    public void getRecord()
    {
        DataTable dtReport = GetDataTable();
        DataTable dtData;
        DataTable filteredRows = null;
        Dictionary<string, string> filters = new Dictionary<string, string>();


        //--------------------   New Form Today   -------------------------

        //filters.Add("EmpName", txtECName.Text);
        //filters.Add("ConfID", "CONF" + txtConfID.Text);

        //filters.Add("Segment", ddlSegement.SelectedItem.Text);
        //filters.Add("Sector", "CONF" + ddlSector.SelectedItem.Text);
        //filters.Add("Business", ddlGroup.SelectedItem.Text);
        //filters.Add("site", ddlSite.SelectedItem.Text);

        //--------------------      End Here  -----------------------------

        string filter = (txtECName.Text.Length > 1 ? "ECNAME" : txtECName.Text);
        filter += (txtConfID.Text.Length > 1 ? "CONF" : txtConfID.Text);

        filters.Clear();
        try
        {
            if (filter.Contains("ECNAME"))
            {
                filters.Add("EmpName", txtECName.Text);
            }
        }
        catch (Exception) { }
        if (filter.Contains("CONF"))
        {
            filters.Add("ConfID", "CONF" + txtConfID.Text);
        }
        try
        {
            if (ddlSegement.SelectedItem.Text != "--Select--")
            {
                filters.Add("Segment", ddlSegement.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlSector.SelectedItem.Text != "--Select--")
            {
                filters.Add("Sector", ddlSector.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlGroup.SelectedItem.Text != "--Select--")
            {
                filters.Add("Business", ddlGroup.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlSite.SelectedItem.Text != "--Select--")
            {
                filters.Add("site", ddlSite.SelectedItem.Text);
            }
        }
        catch (Exception) { }

        switch (filters.Count)
        {
            case 1:
                dtData = _ws.getReports(givelistName: "AttendanceLibrary", columns: new List<string>() { "ID", "EmpName", "Requstor", "Title", "Segment", "site", "Sector", "Business", "Fee", "RequestID", "ReqDate", "RStatus", "ReqStatus", "ConfID", "Author", "Manager", "PlanningHead", "PSManager", "RNTHead", "SitePresident", "SiteHead", "COEHead", "TechCOEHead", "Modified", "Created", "PLNSDate", "RnTSDate", "SegHead", "ConfStartDate" }, filterColumnType: new List<string>() { "Text" }, filters: filters);
                break;
            case 2:
                dtData = _ws.getReports(givelistName: "AttendanceLibrary", columns: new List<string>() { "ID", "EmpName", "Requstor", "Title", "Segment", "site", "Sector", "Business", "Fee", "RequestID", "ReqDate", "RStatus", "ReqStatus", "ConfID", "Author", "Manager", "PlanningHead", "PSManager", "RNTHead", "SitePresident", "SiteHead", "COEHead", "TechCOEHead", "Modified", "Created", "PLNSDate", "RnTSDate", "SegHead", "ConfStartDate" }, filterColumnType: new List<string>() { "Text", "Text" }, filters: filters);
                break;
            case 3:
                dtData = _ws.getReports(givelistName: "AttendanceLibrary", columns: new List<string>() { "ID", "EmpName", "Requstor", "Title", "Segment", "site", "Sector", "Business", "Fee", "RequestID", "ReqDate", "RStatus", "ReqStatus", "ConfID", "Author", "Manager", "PlanningHead", "PSManager", "RNTHead", "SitePresident", "SiteHead", "COEHead", "TechCOEHead", "Modified", "Created", "PLNSDate", "RnTSDate", "SegHead", "ConfStartDate" }, filterColumnType: new List<string>() { "Text", "Text", "Text" }, filters: filters);
                break;
            case 4:
                dtData = _ws.getReports(givelistName: "AttendanceLibrary", columns: new List<string>() { "ID", "EmpName", "Requstor", "Title", "Segment", "site", "Sector", "Business", "Fee", "RequestID", "ReqDate", "RStatus", "ReqStatus", "ConfID", "Author", "Manager", "PlanningHead", "PSManager", "RNTHead", "SitePresident", "SiteHead", "COEHead", "TechCOEHead", "Modified", "Created", "PLNSDate", "RnTSDate", "SegHead", "ConfStartDate" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text" }, filters: filters);
                break;
            case 5:
                dtData = _ws.getReports(givelistName: "AttendanceLibrary", columns: new List<string>() { "ID", "EmpName", "Requstor", "Title", "Segment", "site", "Sector", "Business", "Fee", "RequestID", "ReqDate", "RStatus", "ReqStatus", "ConfID", "Author", "Manager", "PlanningHead", "PSManager", "RNTHead", "SitePresident", "SiteHead", "COEHead", "TechCOEHead", "Modified", "Created", "PLNSDate", "RnTSDate", "SegHead", "ConfStartDate" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text", "Text" }, filters: filters);
                break;
            case 6:
                dtData = _ws.getReports(givelistName: "AttendanceLibrary", columns: new List<string>() { "ID", "EmpName", "Requstor", "Title", "Segment", "site", "Sector", "Business", "Fee", "RequestID", "ReqDate", "RStatus", "ReqStatus", "ConfID", "Author", "Manager", "PlanningHead", "PSManager", "RNTHead", "SitePresident", "SiteHead", "COEHead", "TechCOEHead", "Modified", "Created", "PLNSDate", "RnTSDate", "SegHead", "ConfStartDate" }, filterColumnType: new List<string>() { "Text", "Text", "Text", "Text", "Text", "Text" }, filters: filters);
                break;
            default:
                dtData = null;
                break;
        }

        try
        {
            if (dtData.Rows.Count > 0)
            {
                if (txtSSDate.Text.Length > 0 && txtSEDate.Text.Length > 0)
                {
                    DateTime sSdt = DateTime.Parse(txtSSDate.Text);
                    DateTime sEdt = DateTime.Parse(txtSEDate.Text);

                    filteredRows = dtData.AsEnumerable()
                     .Where(r => Convert.ToDateTime(r.Field<string>("Created")).Date >= sSdt.Date && Convert.ToDateTime(r.Field<string>("Created")).Date <= sEdt.Date)
                     .CopyToDataTable();
                }
                if (txtCSDate.Text.Length > 0 && txtCEDate.Text.Length > 0)
                {

                    DateTime cSdt = DateTime.Parse(txtCSDate.Text);
                    DateTime cEdt = DateTime.Parse(txtCEDate.Text);

                    filteredRows = dtData.AsEnumerable()
                    .Where(r => Convert.ToDateTime(r.Field<string>("ConfStartDate")).Date >= cSdt.Date && Convert.ToDateTime(r.Field<string>("ConfStartDate")).Date <= cEdt.Date)
                    .CopyToDataTable();
                }
            }
            else
            {
                filteredRows = null;
            }
        }
        catch (Exception ex)
        {
            filteredRows = dtData;
        }

        DataRow dr;
        if (filteredRows != null)
        {
            foreach (DataRow row in filteredRows.Rows)
            {
                dr = dtReport.NewRow();
                string reqID = Convert.ToString(row["RequestID"]);
                dr["Conference ID"] = Convert.ToString(row["ConfID"]);

                dr["Conference Name"] = Convert.ToString(_ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(row["ConfID"])), "Title"));
                dr["Type"] = Convert.ToString(_ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(row["ConfID"])), "Category"));
                dr["Overseas"] = Convert.ToString(_ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(row["ConfID"])), "Overseas"));
                dr["Conf Start Date"] = Convert.ToString(_ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(row["ConfID"])), "StartDate"));
                dr["Conf End Date"] = Convert.ToString(_ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("WorkshopID", Convert.ToString(row["ConfID"])), "EndDate"));

                dr["RequestID"] = Convert.ToString(row["RequestID"]);
                dr["ECNo"] = Convert.ToString(row["Title"]);
                dr["Requestor"] = Convert.ToString(row["Requstor"]);
                dr["Segment"] = Convert.ToString(row["Segment"]);
                dr["Sector"] = Convert.ToString(row["Sector"]);
                dr["Group"] = Convert.ToString(row["Business"]);
                dr["Site"] = Convert.ToString(row["site"]);

                dr["Fees"] = Convert.ToString(row["Fee"]);
                dr["SubmitDate"] = Convert.ToString(row["ReqDate"]);


                // dr["LastUpdatedDate"] = Convert.ToString(row["Modified"]);

                dr["RequestStatus"] = Convert.ToString(row["RStatus"]);
                dr["ApprovalStatus"] = Convert.ToString(row["ReqStatus"]);

                dr["Manager"] = Convert.ToString(row["Manager"]);

                string temp = Convert.ToString(_ws.getColumnValue("MgrFeedback", new KeyValuePair<string, string>("Title", reqID), "Created"));
                if (temp.Length > 0)
                {
                    DateTime dt = DateTime.Parse(temp);
                    dr["ManagerApprovalDate"] = dt.ToString("dd-MMM-yyyy");
                }

                if (Convert.ToString(row["Segment"]).Contains("GMS"))
                    dr["CoEHeadRDHead"] = Convert.ToString(row["COEHead"]);
                else
                    dr["CoEHeadRDHead"] = Convert.ToString(row["SegHead"]);

                dr["CoEFunnHeadSiteCTSHead"] = Convert.ToString(row["SiteHead"]);


                temp = Convert.ToString(_ws.getColumnValue("HODFeedback", new KeyValuePair<string, string>("Title", reqID), "Created"));
                if (temp.Length > 0)
                {
                    DateTime dt = DateTime.Parse(temp);
                    dr["CoeSiteFunnHeadApprovalDate"] = dt.ToString("dd-MMM-yyyy");
                }
                dr["PSHead"] = Convert.ToString(row["PlanningHead"]);

                dr["PSHeadApprovalDate"] = Convert.ToString(row["PLNSDate"]);

                temp = Convert.ToString(row["RnTSDate"]).Length > 0 ? Convert.ToString(row["RnTSDate"]) : "";

                if (temp.Length > 0)
                {
                    DateTime dt = DateTime.Parse(temp);
                    dr["CoEHeadRDHeadApprovalDate"] = dt.ToString("dd-MMM-yyyy");
                }

                dtReport.Rows.Add(dr);
            }

            DisplayReport(dtReport);
        }
        else
        {
            DisplayReport(filteredRows);
        }

    }
    public void DisplayReport(DataTable dt)
    {
        try
        {
            /*this.rptConference.Reset();
            this.rptConference.LocalReport.DataSources.Clear();
            this.rptConference.LocalReport.ReportPath = HttpContext.Current.Server.MapPath("~/App_Data/ReportA.rdlc");
            ReportDataSource rds = new ReportDataSource("DS", dt);

            this.rptConference.LocalReport.DataSources.Add(rds);
            this.rptConference.ZoomMode = ZoomMode.Percent;
            this.rptConference.LocalReport.Refresh();*/
            /*
             <!--rsweb:ReportViewer ID="rptConference" runat="server" Font-Names="Verdana" Font-Size="8pt"
                                InteractiveDeviceInfos="(Collection)" WaitMessageFont-Names="Verdana" WaitMessageFont-Size="14pt"
                                Width="100%">
                                <LocalReport ReportPath="App_Data\ReportA.rdlc">
                                </LocalReport>
                            </rsweb:ReportViewer-->
             */

            gvConference.DataSource = dt;
            gvConference.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    public DataTable GetDataTable()
    {
        DataTable dt = new DataTable();

        dt.Columns.Add("Conference ID", typeof(string));
        dt.Columns.Add("Conference Name", typeof(string));
        dt.Columns.Add("Type", typeof(string));
        dt.Columns.Add("Overseas", typeof(string));
        dt.Columns.Add("Conf Start Date", typeof(string));
        dt.Columns.Add("Conf End Date", typeof(string));

        dt.Columns.Add("RequestID", typeof(string));
        dt.Columns.Add("ECNo", typeof(string));
        dt.Columns.Add("Requestor", typeof(string));
        dt.Columns.Add("Segment", typeof(string));
        dt.Columns.Add("Sector", typeof(string));
        dt.Columns.Add("Group", typeof(string));

        dt.Columns.Add("Site", typeof(string));
        dt.Columns.Add("Fees", typeof(string));
        dt.Columns.Add("SubmitDate", typeof(string));
        //dt.Columns.Add("LastUpdatedDate", typeof(string));
        dt.Columns.Add("RequestStatus", typeof(string));
        dt.Columns.Add("ApprovalStatus", typeof(string));

        dt.Columns.Add("Manager", typeof(string));
        dt.Columns.Add("ManagerApprovalDate", typeof(string));

        dt.Columns.Add("CoEFunnHeadSiteCTSHead", typeof(string));
        dt.Columns.Add("CoeSiteFunnHeadApprovalDate", typeof(string));

        dt.Columns.Add("PSHead", typeof(string));
        dt.Columns.Add("PSHeadApprovalDate", typeof(string));

        dt.Columns.Add("CoEHeadRDHead", typeof(string));
        dt.Columns.Add("CoEHeadRDHeadApprovalDate", typeof(string));


        return dt;
    }
    public void FillDropdown()
    {
        listName = "Segment";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSegement.PopulateddlNewA(_ws, listName, keyColumnName, valueColumnName);
        ddlSegement.Items.Insert(0, "--Select--");

        listName = "Site";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSite.PopulateddlNewA(_ws, listName, keyColumnName, valueColumnName);
        ddlSite.Items.Insert(0, "--Select--");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        getRecord();
    }
    protected void ddlSegement_SelectedIndexChanged(object sender, EventArgs e)
    {
        listName = "Sector";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSector.PopulateddlNew(_ws, listName, keyColumnName, valueColumnName, "Text", new KeyValuePair<string, string>("Segment", ddlSegement.SelectedItem.Text));
        ddlSector.Items.Insert(0, "--Select--");
    }
    protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
    {
        listName = "Group";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlGroup.PopulateddlNew(_ws, listName, keyColumnName, valueColumnName, "Text", new KeyValuePair<string, string>("Sector", ddlSector.SelectedItem.Text));
        ddlGroup.Items.Insert(0, "--Select--");
    }
    protected void btnExl_Click(object sender, EventArgs e)
    {
        if ((gvConference.Visible == true) && (gvConference.Rows.Count > 1))
        {
            Response.Clear();
            Response.Buffer = true;
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("content-disposition", "attachment;filename=MyFiles.xls");
            Response.Charset = "";
            this.EnableViewState = false;

            System.IO.StringWriter sw = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htw = new System.Web.UI.HtmlTextWriter(sw);

            gvConference.RenderControl(htw);

            Response.Write(sw.ToString());
            Response.End();

        }
    }

    public override void RenderControl(HtmlTextWriter writer)
    {
        base.RenderControl(writer);
    }

    protected override void RenderChildren(HtmlTextWriter writer)
    {
        base.RenderChildren(writer);
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        base.VerifyRenderingInServerForm(control);
        for (int i = 0; i < control.Controls.Count; i++)
        {
            Control current = control.Controls[i];
            if (current is LinkButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                LinkButton).Text));
            }
            else if (current is ImageButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                ImageButton).AlternateText));
            }
            else if (current is HyperLink)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                HyperLink).Text));
            }
            else if (current is DropDownList)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                DropDownList).SelectedItem.Text));
            }
            else if (current is CheckBox)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                CheckBox).Checked ? "×›×Ÿ" : "×œ×"));
            }
            if (current.HasControls())
            {
                VerifyRenderingInServerForm(current);
            }

        }
    }

    /* public string getColumnValueNew(string _givelistName, KeyValuePair<string, string> filter, string returnColumn)
     {
         string value = string.Empty;
         try
         {

             ClientContext _contextNew = _ws.getClientContext();
             Web web = _contextNew.Web;
             List lst = _contextNew.Web.Lists.GetByTitle(_givelistName);
             CamlQuery caml = new CamlQuery();
             caml.ViewXml = "<View>" +
                                 "<Query>" +
                                     "<Where>" +
                                         "<Eq>" +
                                             "<FieldRef Name =" + filter.Key + "/>" +
                                             "<Value Type = 'Text'>" + filter.Value + "</Value>" +
                                         "</Eq>" +
                                     "</Where>" +
                                  "</Query>" +
                               "</View>";
             Microsoft.SharePoint.Client.ListItemCollection lstItemCol = lst.GetItems(caml);
             _contextNew.Load(lstItemCol, items => items.Include(item => item[returnColumn]));
            _ws.executeClientContext(_contextNew);

             value = Convert.ToString(lstItemCol[0][returnColumn]);
         }
         catch (Exception ex)
         {
             value = string.Empty;
         }
         return value;
     }*/
}