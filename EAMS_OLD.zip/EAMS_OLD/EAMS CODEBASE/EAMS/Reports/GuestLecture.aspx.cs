﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
using EAMSBusiness;
using System.Data;
using Microsoft.Reporting.WebForms;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;

public partial class Reports_Default : System.Web.UI.Page
{
    Workshop _ws;
    string listName = string.Empty;
    string keyColumnName = string.Empty;
    string valueColumnName = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        _ws = new Workshop();
        try
        {
            if (!Page.IsPostBack)
            {
                FillDropdown();
                // getRecord();
            }
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btnExl);
        }
        catch (Exception)
        {
        }
    }

    public void getRecord()
    {
        DataTable dtReport = GetDisplayTable();
        DataTable dtData;
        DataTable filteredRows = null;
        Dictionary<string, string> filters = new Dictionary<string, string>();
        Dictionary<string, string> filters1 = new Dictionary<string, string>();

        string filter = (txtECName.Text.Length > 1 ? "ECNAME" : txtECName.Text);

        filters.Clear();
        try
        {
            if (filter.Contains("ECNAME"))
            {
                filters.Add("EmpName", txtECName.Text);
            }
        }
        catch (Exception) { }
        if (filter.Contains("CONF"))
        {
            filters.Add("ConfID", "CONF");
        }
        try
        {
            if (ddlSegement.SelectedItem.Text != "--Select--")
            {
                filters.Add("Segment", ddlSegement.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlSector.SelectedItem.Text != "--Select--")
            {
                filters.Add("Sector", ddlSector.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlGroup.SelectedItem.Text != "--Select--")
            {
                filters.Add("Business", ddlGroup.SelectedItem.Text);
            }
        }
        catch (Exception) { }
        try
        {
            if (ddlSite.SelectedItem.Text != "--Select--")
            {
                filters.Add("Site", ddlSite.SelectedItem.Text);
            }
        }
        catch (Exception) { }

        DataTable dt = GetDataTable();
        switch (filters.Count)
        {
            case 1:
                dtData = _ws.getReportsNew(givelistName: "LECINVList", filterColumnType: new List<string>() { "Text" }, table: dt, filters: filters);
                break;
            case 2:
                dtData = _ws.getReportsNew(givelistName: "LECINVList", filterColumnType: new List<string>() { "Text", "Text" }, table: dt, filters: filters);
                break;
            case 3:
                dtData = _ws.getReportsNew(givelistName: "LECINVList", filterColumnType: new List<string>() { "Text", "Text", "Text" }, table: dt, filters: filters);
                break;
            case 4:
                dtData = _ws.getReportsNew(givelistName: "LECINVList", filterColumnType: new List<string>() { "Text", "Text", "Text", "Text" }, table: dt, filters: filters);
                break;
            case 5:
                dtData = _ws.getReportsNew(givelistName: "LECINVList", filterColumnType: new List<string>() { "Text", "Text", "Text", "Text", "Text" }, table: dt, filters: filters);
                break;
            case 6:
                dtData = _ws.getReportsNew(givelistName: "LECINVList", filterColumnType: new List<string>() { "Text", "Text", "Text", "Text", "Text", "Text" }, table: dt, filters: filters);
                break;
            default:
                dtData = null;
                break;
        }

        try
        {
            if (dtData.Rows.Count > 0)
            {
                if (txtSSDate.Text.Length > 0 && txtSEDate.Text.Length == 0)
                {
                    DateTime sSdt = DateTime.Parse(txtSSDate.Text);
                    //DateTime sEdt = DateTime.Parse(txtSEDate.Text);

                    filteredRows = dtData.AsEnumerable()
                     .Where(r => Convert.ToDateTime(r.Field<string>("Created")).Date >= sSdt.Date)
                     .CopyToDataTable();
                }
                else if (txtSSDate.Text.Length == 0 && txtSEDate.Text.Length > 0)
                {

                    //DateTime cSdt = DateTime.Parse(txtSSDate.Text);
                    DateTime cEdt = DateTime.Parse(txtSEDate.Text);

                    filteredRows = dtData.AsEnumerable()
                    .Where(r => Convert.ToDateTime(r.Field<string>("Created")).Date <= cEdt.Date)
                     .CopyToDataTable();
                }
                else if (txtSSDate.Text.Length > 0 && txtSEDate.Text.Length > 0)
                {

                    DateTime sSdt = DateTime.Parse(txtSSDate.Text);
                    DateTime sEdt = DateTime.Parse(txtSEDate.Text);

                    //DateTime cSdt = DateTime.Parse(txtSSDate.Text);
                    //DateTime cEdt = DateTime.Parse(txtSEDate.Text);

                    filteredRows = dtData.AsEnumerable()
                     .Where(r => Convert.ToDateTime(r.Field<string>("Created")).Date >= sSdt.Date && Convert.ToDateTime(r.Field<string>("Created")).Date <= sEdt.Date)
                     .CopyToDataTable();
                }
                else
                {
                    filteredRows = dtData;
                }
            }
            else
            {
                filteredRows = null;
            }
        }
        catch (Exception ex)
        {
            filteredRows = dtData;
        }

        /* try
         {
             if (dtData.Rows.Count > 0)
             {
                 if (txtSSDate.Text.Length > 0)
                 {
                     DateTime sSdt = DateTime.Parse(txtSSDate.Text);
                     DateTime sEdt = DateTime.Parse(txtSEDate.Text);

                     filteredRows = dtData.AsEnumerable()
                      .Where(r => Convert.ToDateTime(r.Field<string>("ReqDate")).Date >= sSdt.Date && Convert.ToDateTime(r.Field<string>("ReqDate")).Date <= sEdt.Date)
                      .CopyToDataTable();
                 }
                 else
                 {
                     filteredRows = dtData;
                 }
             }
             else
             {
                 filteredRows = null;
             }
         }
         catch (Exception ex)
         {
             filteredRows = dtData;
         }*/

        DataRow dr;
        if (filteredRows != null)
        {
            foreach (DataRow row in filteredRows.Rows)
            {
                dr = dtReport.NewRow();

                dr["Title"] = Convert.ToString(row["Title"]);
                dr["TopicDesc"] = Convert.ToString(row["TopicDesc"]);
                dr["EmpCode"] = Convert.ToString(row["EmpCode"]);
                dr["EmpName"] = Convert.ToString(row["EmpName"]);
                dr["Segment"] = Convert.ToString(row["Segment"]);
                dr["Sector"] = Convert.ToString(row["Sector"]);
                dr["Business"] = Convert.ToString(row["Business"]);
                dr["Site"] = Convert.ToString(row["Site"]);
                dr["PertName"] = Convert.ToString(row["PertName"]);
                dr["PertDesig"] = Convert.ToString(row["PertDesig"]);
                dr["PertComp"] = Convert.ToString(row["PertComp"]);
                dr["KeyReason"] = Convert.ToString(row["KeyReason"]);
                dr["ValueRil"] = Convert.ToString(row["ValueRil"]);
                dr["NDA"] = Convert.ToString(row["NDA"]);
                dr["NDADesc"] = Convert.ToString(row["NDADesc"]);
                dr["CostTravel"] = Convert.ToString(row["CostTravel"]);
                dr["CostAccom"] = Convert.ToString(row["CostAccom"]);
                dr["CostHonor"] = Convert.ToString(row["CostHonor"]);
                dr["BudgetInv"] = Convert.ToString(row["BudgetInv"]);
                dr["DescBudgetInv"] = Convert.ToString(row["DescBudgetInv"]);
                dr["RStatus"] = Convert.ToString(row["RStatus"]);
                dr["DelFlag"] = Convert.ToString(row["DelFlag"]);
               // dr["WFLevel"] = Convert.ToString(row["WFLevel"]);
                dr["Requstor"] = Convert.ToString(row["Requstor"]);
                dr["ReqStatus"] = Convert.ToString(row["ReqStatus"]);
                dr["RequestID"] = Convert.ToString(row["RequestID"]);
                dr["ReqDate"] = Convert.ToString(row["ReqDate"]);
                dr["Status"] = Convert.ToString(row["Status"]);
                dr["Comment"] = Convert.ToString(row["Comment"]);
                dr["SiteHead"] = Convert.ToString(row["SiteHead"]);
                dr["Pending"] = Convert.ToString(row["Pending"]);
                dr["StatusDate"] = Convert.ToString(row["StatusDate"]);
                dr["IntFaculty"] = Convert.ToString(row["IntFaculty"]);
                dr["IntFacultyDesc"] = Convert.ToString(row["IntFacultyDesc"]);
                dr["draftFlag"] = Convert.ToString(row["draftFlag"]);
                //dr["ChangeFlag"] = Convert.ToString(row["ChangeFlag"]);
                dr["Manager"] = Convert.ToString(row["Manager"]);
             
                dr["Created"] = Convert.ToString(row["Created"]);
                dr["Author"] = Convert.ToString(row["Author"]);
                dr["Modified"] = Convert.ToString(row["Modified"]);
                dr["Editor"] = Convert.ToString(row["Editor"]);
               
                dtReport.Rows.Add(dr);
            }

            DisplayReport(dtReport);
        }
        else
        {
            DisplayReport(filteredRows);
        }

    }
    public void DisplayReport(DataTable dt)
    {
        try
        {
            gvConference.DataSource = dt;
            gvConference.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    public DataTable GetDataTable()
    {
        DataTable dt = new DataTable();

        dt.Columns.Add("ID", typeof(string));
        dt.Columns.Add("Title", typeof(string));
        dt.Columns.Add("TopicDesc", typeof(string));
        dt.Columns.Add("EmpCode", typeof(string));
        dt.Columns.Add("EmpName", typeof(string));
        dt.Columns.Add("Segment", typeof(string));
        dt.Columns.Add("Sector", typeof(string));
        dt.Columns.Add("Business", typeof(string));
        dt.Columns.Add("Site", typeof(string));
        dt.Columns.Add("PertName", typeof(string));
        dt.Columns.Add("PertDesig", typeof(string));
        dt.Columns.Add("PertComp", typeof(string));
        dt.Columns.Add("KeyReason", typeof(string));
        dt.Columns.Add("ValueRil", typeof(string));
        dt.Columns.Add("NDA", typeof(string));
        dt.Columns.Add("NDADesc", typeof(string));
        dt.Columns.Add("CostTravel", typeof(string));
        dt.Columns.Add("CostAccom", typeof(string));
        dt.Columns.Add("CostHonor", typeof(string));
        dt.Columns.Add("BudgetInv", typeof(string));
        dt.Columns.Add("DescBudgetInv", typeof(string));
        dt.Columns.Add("RStatus", typeof(string));
        dt.Columns.Add("DelFlag", typeof(string));
        dt.Columns.Add("WFLevel", typeof(string));
        dt.Columns.Add("Requstor", typeof(string));
        dt.Columns.Add("ReqStatus", typeof(string));
        dt.Columns.Add("RequestID", typeof(string));
        dt.Columns.Add("ReqDate", typeof(string));
        dt.Columns.Add("Status", typeof(string));
        dt.Columns.Add("Comment", typeof(string));
        dt.Columns.Add("SiteHead", typeof(string));
        dt.Columns.Add("Pending", typeof(string));
        dt.Columns.Add("StatusDate", typeof(string));
        dt.Columns.Add("IntFaculty", typeof(string));
        dt.Columns.Add("IntFacultyDesc", typeof(string));
        dt.Columns.Add("draftFlag", typeof(string));
        dt.Columns.Add("ChangeFlag", typeof(string));
        dt.Columns.Add("Manager", typeof(string));
        dt.Columns.Add("GLSendMa", typeof(string));
        dt.Columns.Add("GLSendMa0", typeof(string));
        dt.Columns.Add("SendMail", typeof(string));
        dt.Columns.Add("Created", typeof(string));
        dt.Columns.Add("Author", typeof(string));
        dt.Columns.Add("Modified", typeof(string));
        dt.Columns.Add("Editor", typeof(string));

        return dt;
    }
    public DataTable GetDisplayTable()
    {
        DataTable dt = new DataTable();

        //dt.Columns.Add("ID", typeof(string));
        dt.Columns.Add("Title", typeof(string));
        dt.Columns.Add("TopicDesc", typeof(string));
        dt.Columns.Add("RequestID", typeof(string));
        dt.Columns.Add("ReqDate", typeof(string));
        dt.Columns.Add("Status", typeof(string));
        dt.Columns.Add("ReqStatus", typeof(string));
        dt.Columns.Add("RStatus", typeof(string));
        dt.Columns.Add("Comment", typeof(string));


        dt.Columns.Add("EmpCode", typeof(string));
        dt.Columns.Add("EmpName", typeof(string));
        dt.Columns.Add("Requstor", typeof(string));
        dt.Columns.Add("Manager", typeof(string));


        dt.Columns.Add("Segment", typeof(string));
        dt.Columns.Add("Sector", typeof(string));
        dt.Columns.Add("Business", typeof(string));
        dt.Columns.Add("Site", typeof(string));
       
        dt.Columns.Add("PertName", typeof(string));
        dt.Columns.Add("PertDesig", typeof(string));
        dt.Columns.Add("PertComp", typeof(string));
        dt.Columns.Add("KeyReason", typeof(string));
        dt.Columns.Add("ValueRil", typeof(string));
        dt.Columns.Add("NDA", typeof(string));
        dt.Columns.Add("NDADesc", typeof(string));
        dt.Columns.Add("CostTravel", typeof(string));
        dt.Columns.Add("CostAccom", typeof(string));
        dt.Columns.Add("CostHonor", typeof(string));
        dt.Columns.Add("BudgetInv", typeof(string));
        dt.Columns.Add("DescBudgetInv", typeof(string));
       
        dt.Columns.Add("DelFlag", typeof(string));
        //dt.Columns.Add("WFLevel", typeof(string));
    
     
       
        dt.Columns.Add("SiteHead", typeof(string));
        dt.Columns.Add("Pending", typeof(string));
        dt.Columns.Add("StatusDate", typeof(string));
        dt.Columns.Add("IntFaculty", typeof(string));
        dt.Columns.Add("IntFacultyDesc", typeof(string));
        dt.Columns.Add("draftFlag", typeof(string));
        //dt.Columns.Add("ChangeFlag", typeof(string));
      
        //dt.Columns.Add("GLSendMa", typeof(string));
        //dt.Columns.Add("GLSendMa0", typeof(string));
        dt.Columns.Add("SendMail", typeof(string));
        dt.Columns.Add("Created", typeof(string));
        dt.Columns.Add("Author", typeof(string));
        dt.Columns.Add("Modified", typeof(string));
        dt.Columns.Add("Editor", typeof(string));

        return dt;
    }
    public void FillDropdown()
    {
        listName = "Segment";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSegement.PopulateddlNewA(_ws, listName, keyColumnName, valueColumnName);
        ddlSegement.Items.Insert(0, "--Select--");

        listName = "Site";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSite.PopulateddlNewA(_ws, listName, keyColumnName, valueColumnName);
        ddlSite.Items.Insert(0, "--Select--");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        getRecord();
    }
    protected void ddlSegement_SelectedIndexChanged(object sender, EventArgs e)
    {
        listName = "Sector";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlSector.PopulateddlNew(_ws, listName, keyColumnName, valueColumnName, "Text", new KeyValuePair<string, string>("Segment", ddlSegement.SelectedItem.Text));
        ddlSector.Items.Insert(0, "--Select--");
    }
    protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
    {
        listName = "Group";
        keyColumnName = "ID";
        valueColumnName = "Title";
        ddlGroup.PopulateddlNew(_ws, listName, keyColumnName, valueColumnName, "Text", new KeyValuePair<string, string>("Sector", ddlSector.SelectedItem.Text));
        ddlGroup.Items.Insert(0, "--Select--");
    }
    protected void btnExl_Click(object sender, EventArgs e)
    {
        if ((gvConference.Visible == true) && (gvConference.Rows.Count > 1))
        {
            Response.Clear();
            Response.Buffer = true;
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("content-disposition", "attachment;filename=MyFiles.xls");
            Response.Charset = "";
            this.EnableViewState = false;

            System.IO.StringWriter sw = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htw = new System.Web.UI.HtmlTextWriter(sw);

            gvConference.RenderControl(htw);

            Response.Write(sw.ToString());
            Response.End();

        }
    }

    public override void RenderControl(HtmlTextWriter writer)
    {
        base.RenderControl(writer);
    }

    protected override void RenderChildren(HtmlTextWriter writer)
    {
        base.RenderChildren(writer);
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
        for (int i = 0; i < control.Controls.Count; i++)
        {
            Control current = control.Controls[i];
            if (current is LinkButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                LinkButton).Text));
            }
            else if (current is ImageButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                ImageButton).AlternateText));
            }
            else if (current is HyperLink)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                HyperLink).Text));
            }
            else if (current is DropDownList)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                DropDownList).SelectedItem.Text));
            }
            else if (current is CheckBox)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as
                CheckBox).Checked ? "×›×Ÿ" : "×œ×"));
            }
            if (current.HasControls())
            {
                VerifyRenderingInServerForm(current);
            }
        }
    }
}