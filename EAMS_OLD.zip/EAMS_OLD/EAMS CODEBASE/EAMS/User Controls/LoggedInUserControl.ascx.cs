﻿using System;
using Microsoft.SharePoint.Client;

public partial class User_Controls_LoggedInUserControl : System.Web.UI.UserControl
{


    private string _url;
    public string SiteURL
    {
        get { return _url; }
        set { _url = value; }
    }

    public string LoggedInUser
    {
        get { return txtLoggedInUser.Text; }
        set { txtLoggedInUser.Text = value; }
    }
    

    protected void Page_Load(object sender, EventArgs e)
    {
        
        //LoggedInUser = site.CurrentUser.LoginName;
        //FieldUserValue fldUser = FieldUserValue.FromUser(site.CurrentUser.LoginName);
        //LoggedInUser = fldUser.
    }

    public string LoadLoggedInUser()
    {
        ClientContext ctx = new ClientContext(SiteURL);
        Web site = ctx.Web;
        ctx.Load(site.CurrentUser);
        ctx.ExecuteQuery();
        return LoggedInUser = site.CurrentUser.LoginName;
        
    }

  }