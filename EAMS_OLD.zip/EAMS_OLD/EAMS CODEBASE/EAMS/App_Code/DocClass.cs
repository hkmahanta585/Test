﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    /// <summary>
    /// Summary description for DocClass
    /// </summary>
    public class DocClass
    {
        public DocClass()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string Title { get; set; }
        public string FileName { get; set; }
        public string FileSize { get; set; }
        public string FileRef { get; set; }
    }
}