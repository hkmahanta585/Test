﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.DirectoryServices;
using System.Data;
using System.Text;
using System.Web.Script.Services;
using EAMSUtility;
//using EAMSBusiness;

/// <summary>
/// Summary description for ADService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.Web.Script.Services.ScriptService]
public class ADService : System.Web.Services.WebService
{

    public ADService()
    {
    }


    private static DirectoryEntry dirUser = new DirectoryEntry("LDAP://in.ril.com/dc=in,dc=ril,dc=com");
    private static DirectorySearcher directorySearcher = new DirectorySearcher(dirUser);


    protected String seperateDomainId(String s)
    {
        StringBuilder reporter = new StringBuilder();
        for (int index = s.IndexOf("CN=") + 3; index < s.IndexOf(","); index++)
        {
            reporter.Append(s.ElementAt(index));
        }
        return reporter.ToString();
    }

    protected String removeCNForGroups(String s)
    {
        return s.Substring(s.IndexOf("=") + 1);
    }

    [WebMethod(EnableSession = true)]
    [System.Web.Script.Services.ScriptMethod]
    public string[] GetAutoComplete(string prefixText, int count)
    {
        string[] result = null;
        result = FileUtility.getAutoComplete("Conference & Workshop", "WorkshopID", prefixText, 10);
        return result;
    }

    [WebMethod(EnableSession = true)]
    [System.Web.Script.Services.ScriptMethod]
    public string[] searchDomainId(string prefixText, int count)
    {
        string[] employeeDomainIds;
        string[] employeeDisplayName;
        Session.Remove("EmployeeSet");
        prefixText = prefixText.Replace('\"', ' ').Trim();
        int empCount = 0;
        try
        {
            //directorySearcher.Filter = "(&(objectClass=user)(samaccountname=" + prefixText + "*))";
            directorySearcher.Filter = "(&(objectClass=user)(displayName=" + prefixText + "*))";
            directorySearcher.SizeLimit = 5;
            SearchResultCollection dirSearchResult = directorySearcher.FindAll();
            employeeDomainIds = new string[dirSearchResult.Count];
            employeeDisplayName = new string[dirSearchResult.Count];
            foreach (SearchResult result in dirSearchResult)
            {
                DirectoryEntry der = result.GetDirectoryEntry();
                employeeDomainIds[empCount] = der.Properties["samaccountname"][0].ToString() + "[" + der.Properties["displayName"][0].ToString() + "]";
                employeeDisplayName[empCount] = der.Properties["displayName"][0].ToString();
                empCount++;
                //buffer.Append(der.Properties["displayName"][0].ToString() + "<input type='hidden' id='employeeToselect' value='" + der.Properties["samaccountname"][0].ToString() + "'>" + "|");
            }
            Session["EmployeeSet"] = employeeDomainIds;
            return employeeDisplayName;
        }
        catch (Exception ex)
        {
            Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
            return null;
        }


    }


    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string[] JsearchDomainId(string prefixText, int count)
    {
        string[] employeeDomainIds;

        prefixText = prefixText.Replace('\"', ' ').Trim();
        int empCount = 0;
        try
        {
            directorySearcher.Filter = "(&(objectClass=user)(samaccountname=" + prefixText + "*))";
            directorySearcher.SizeLimit = 5;
            SearchResultCollection dirSearchResult = directorySearcher.FindAll();
            employeeDomainIds = new string[dirSearchResult.Count];
            foreach (SearchResult result in dirSearchResult)
            {
                DirectoryEntry der = result.GetDirectoryEntry();
                employeeDomainIds[empCount] = der.Properties["samaccountname"][0].ToString();
                empCount++;
                //buffer.Append(der.Properties["displayName"][0].ToString() + "<input type='hidden' id='employeeToselect' value='" + der.Properties["samaccountname"][0].ToString() + "'>" + "|");
            }
            return employeeDomainIds;
        }
        catch
        {
            return null;
        }


    }


    //Web service to search by domain Id
    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public DataTable getUserDetailsByDomainId(string domainId)
    {
        return getActiveDirectorySearchResult("samaccountname", domainId);
    }

    //Web service to search by telephone
    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public DataTable getUserDetailsByTelephone(string teleNumber)
    {
        return getActiveDirectorySearchResult("telephoneNumber", teleNumber);
    }

    //Method to check the Email Id exists or not.
    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public int findEmailId(string email)
    {
        directorySearcher.Filter = "(&(objectClass=user)(mail=" + email + "))";
        SearchResult dirSearchResult = directorySearcher.FindOne();
        if (dirSearchResult == null)
        {
            return 0;
        }
        else
        {
            return 1;
        }

    }

    //Method to get users group.
    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public DataTable getUsersGroups(String userId)
    {
        //List<string> groups = new List<string>();
        DataTable groups = new DataTable();
        groups.TableName = "UserGroups";
        groups.Columns.Add("MemberOf");
        directorySearcher.Filter = "(&(objectClass=user)(samaccountname=" + userId + "))";
        try
        {
            SearchResult dirSearchResult = directorySearcher.FindOne();
            DirectoryEntry dirSearchResults = new DirectoryEntry(dirSearchResult.Path);
            //return dirSearchResults.Properties["memberOf"][0].ToString();
            object obGroups = dirSearchResults.Invoke("Groups");
            foreach (object ob in (IEnumerable)obGroups)
            {
                // Create object for each group.
                DirectoryEntry obGpEntry = new DirectoryEntry(ob);
                groups.Rows.Add(removeCNForGroups(obGpEntry.Name));
            }
        }
        catch
        {

        }

        return groups;
    }


    //Method to get Users Display Name
    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public string getDisplayName(string domainId)
    {
        directorySearcher.Filter = "(&(objectClass=user)(samaccountname=" + domainId + "))";
        SearchResult dirSearchResult = directorySearcher.FindOne();
        DirectoryEntry dirSearchResults = new DirectoryEntry(dirSearchResult.Path);
        return dirSearchResults.Properties["displayName"].Value.ToString();

    }

    //Method to get Users Display Name
    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public string getManager(string domainId)
    {
        directorySearcher.Filter = "(&(objectClass=user)(samaccountname=" + domainId + "))";
        SearchResult dirSearchResult = directorySearcher.FindOne();
        DirectoryEntry dirSearchResults = new DirectoryEntry(dirSearchResult.Path);
        return dirSearchResults.Properties["manager"].Value.ToString();
    }

    //Method to get Users Display Name
    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public string getUserID(string domainId)
    {
        EAMSUtility.CreateLogFile createLog = new EAMSUtility.CreateLogFile();
        //createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- ADService Track 0, domainId : -" + domainId + "--------<br />");
        DirectoryEntry dirSearchResults = null;
        try
        {
            //createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- ADService track 1--------<br />");
            directorySearcher.Filter = "(&(objectClass=user)(samaccountname=" + domainId + "))";
            //createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- ADService track 2--------<br />");
            SearchResult dirSearchResult = directorySearcher.FindOne();
            //createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- ADService track 3--------<br />");
            dirSearchResults = new DirectoryEntry(dirSearchResult.Path);
            //createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- ADService track 4--------<br />");
            return dirSearchResults.Properties["employeeId"].Value.ToString();
        }
        catch (Exception ex)
        {
            createLog.ErrorLog(sPathName: HttpContext.Current.Server.MapPath("ErrorLog"), sErrMsg: "----- ADService Massage : -" + ex.Message.ToString() + "--------<br />");
        }
        return dirSearchResults.Properties["employeeId"].Value.ToString();
    }


    //Method to get the Directory Result from the given input
    private DataTable getActiveDirectorySearchResult(string selectedParameter, string parameterValue)
    {

        Session["ServiceError"] = "WebService method is called...";

        directorySearcher.Filter = "(&(objectClass=user)(" + selectedParameter + "=" + parameterValue + "))";
        DataTable employeeDetails = defineEmployeeDataTable();
        StringBuilder reportee = new StringBuilder();


        string domainId = "";
        string employeeId = "";
        string displayName = "";
        string email = "";
        string telephoneNumber = "";
        string mobile = "";
        string department = "";
        string company = "";
        string streetAddress = "";
        string manager = "";
        string location = "";

        try
        {
            SearchResult dirSearchResult = directorySearcher.FindOne();
            DirectoryEntry dirSearchResults = new DirectoryEntry(dirSearchResult.Path);

            PropertyValueCollection obj = dirSearchResults.Properties["directReports"];
            try
            {
                foreach (String prop in obj)
                {
                    reportee.Append(seperateDomainId(prop));
                    reportee.Append("|");
                }
            }
            catch (Exception ex)
            {
                Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                reportee.Append("|");
            }

            try
            {
                try
                {
                    domainId = dirSearchResult.Properties["samaccountname"][0].ToString();
                }
                catch (Exception ex)
                {
                    domainId = "";
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                }

                try
                {
                    employeeId = dirSearchResult.Properties["employeeId"][0].ToString();
                }
                catch (Exception ex)
                {
                    displayName = "";
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                }

                try
                {
                    displayName = dirSearchResult.Properties["displayName"][0].ToString();
                }
                catch (Exception ex)
                {
                    displayName = "";
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                }

                try
                {
                    email = dirSearchResult.Properties["mail"][0].ToString();
                }
                catch (Exception ex)
                {
                    email = "";
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                }
                try
                {
                    telephoneNumber = dirSearchResult.Properties["telephoneNumber"][0].ToString();
                }
                catch (Exception ex)
                {
                    telephoneNumber = "";
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                }

                try
                {
                    mobile = dirSearchResult.Properties["mobile"][0].ToString();
                }
                catch (Exception ex)
                {
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                    mobile = "";
                }

                try
                {
                    department = dirSearchResult.Properties["department"][0].ToString();
                }
                catch (Exception ex)
                {
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                    department = "";
                }

                try
                {
                    company = dirSearchResult.Properties["company"][0].ToString();
                }
                catch (Exception ex)
                {
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                    company = "";
                }

                try
                {
                    streetAddress = dirSearchResult.Properties["streetAddress"][0].ToString();
                }
                catch
                {
                    streetAddress = "";
                }

                try
                {
                    manager = dirSearchResult.Properties["manager"][0].ToString();
                }
                catch (Exception ex)
                {
                    Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
                    manager = "";

                }

                try
                {
                    location = dirSearchResult.Properties["physicalDeliveryOfficeName"][0].ToString();
                }
                catch
                {
                    location = "";
                }

            }
            catch (Exception ex)
            {
                Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
            }
        }
        catch (Exception ex)
        {
            Session["ServiceError"] = ex.Message + " Desc:- " + ex.ToString();
        }


        { }

        employeeDetails.Rows.Add(domainId,
            employeeId, displayName, email, telephoneNumber, mobile,
                department, company, streetAddress, seperateDomainId(manager),
                  reportee.ToString(), location);
        return employeeDetails;

    }


    //Method to define table definitions.
    private DataTable defineEmployeeDataTable()
    {
        DataTable employeeDataTable = new DataTable("userDeatails");
        employeeDataTable.Columns.Add("domainId");
        employeeDataTable.Columns.Add("employeeId");
        employeeDataTable.Columns.Add("displayName");
        employeeDataTable.Columns.Add("email");
        employeeDataTable.Columns.Add("telephoneNumber");
        employeeDataTable.Columns.Add("mobile");
        employeeDataTable.Columns.Add("department");
        employeeDataTable.Columns.Add("company");
        employeeDataTable.Columns.Add("streetAddress");
        employeeDataTable.Columns.Add("manager");
        employeeDataTable.Columns.Add("reportee");
        employeeDataTable.Columns.Add("location");

        return employeeDataTable;
    }


    //Method to get mail ID
    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public string getManagerMailAddress(string manager, string user)
    {
        try
        {
            directorySearcher.Filter = "(&(objectClass=user)(samaccountname=" + manager + "))";
            SearchResult dirSearchResult = directorySearcher.FindOne();
            DirectoryEntry dirSearchResults = new DirectoryEntry(dirSearchResult.Path);
            return dirSearchResults.Properties["mail"].Value.ToString();
        }
        catch
        {
            string mmid = "x";
            try
            {
                directorySearcher.Filter = "(&(objectClass=user)(displayname=" + manager + "))";
                //SearchResult dirSearchResult = directorySearcher.FindOne();
                SearchResultCollection dirSearchResultall = directorySearcher.FindAll();

                foreach (object ob in (IEnumerable)dirSearchResultall)
                {
                    // Create object for each group.
                    SearchResult dirSearchResultobj = (SearchResult)ob;
                    DirectoryEntry dirSearchResults = new DirectoryEntry(dirSearchResultobj.Path);
                    PropertyValueCollection obj = dirSearchResults.Properties["directReports"];
                    try
                    {

                        foreach (String prop in obj)
                        {
                            if (prop.StartsWith("CN=" + user))
                            {
                                mmid = dirSearchResults.Properties["mail"].Value.ToString();
                                break;
                            }

                        }

                    }

                    catch (Exception e)
                    { return "x"; }
                    if (mmid != "x")
                    {
                        break;
                    }

                }

            }
            catch
            {
                return "x";

            } return mmid;
        }
    }

}
