﻿using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using EAMSUtility;
using EAMSBusiness;
using System;

namespace WebApplication1
{

    public static class GeneralFuction
    {


        /// <summary>
        /// Method for populating DropDownList on this page
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="listName"></param>
        /// <param name="keyColumnName"></param>
        /// <param name="valueColumnName"></param>
        /// <param name="filterColumnName"></param>
        /// <param name="filterValue"></param>
        public static void Populateddl(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter, bool FilterByDate)
        {

            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionaryWithFilter(listName, keyColumnName, valueColumnName, columnType, filter)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });
            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void Populateddl(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter)
        {

            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionary(listName, keyColumnName, valueColumnName, columnType, filter)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });


            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void PopulateddlNew(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter)
        {

            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionaryNew(listName, keyColumnName, valueColumnName, columnType, filter)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });


            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }
        public static void PopulateReqID(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter, string containsFilter)
        {

            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionary(listName, keyColumnName, valueColumnName, columnType, filter)
                           where ddlRow.Value.Contains(containsFilter)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });

            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void PopulateReqID_PRE(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter, string containsFilter)
        {

            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionary(listName, keyColumnName, valueColumnName, columnType, filter)
                           where ddlRow.Value.Contains("PRE") || ddlRow.Value.Contains("AWD")
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });


            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void PopulateReqID_EXT_DOC(this DropDownList ddl, Workshop ws, string listName, string listName2, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter, string containsFilter)
        {
            Dictionary<string, string> ddlData = new Dictionary<string, string>();
            Dictionary<string, string> ddlFilterDate = new Dictionary<string, string>();
            ddlData = ws.getListAsDictionary_DDL_EXT(listName, keyColumnName, valueColumnName, columnType, filter, containsFilter);

            foreach (KeyValuePair<string, string> item in ddlData)
            {
                bool existFlag = ws.CheckDocumentExist(listName2, "RequestID", item.Value);
                if (!existFlag)
                    ddlFilterDate.Add(item.Key, item.Value);

            }

            ddl.PopulateDropDownList("Value", "Key", ddlFilterDate);

        }
        public static void PopulateReqID_EXT_DOC_PRE(this DropDownList ddl, Workshop ws, string listName, string listName2, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter, string containsFilter)
        {
            Dictionary<string, string> ddlData = new Dictionary<string, string>();
            Dictionary<string, string> ddlFilterDate = new Dictionary<string, string>();
            ddlData = ws.getListAsDictionary_DDL_EXT_PRE(listName, keyColumnName, valueColumnName, columnType, filter, containsFilter);

            foreach (KeyValuePair<string, string> item in ddlData)
            {
                bool existFlag = ws.CheckDocumentExist(listName2, "RequestID", item.Value);
                if (!existFlag)
                    ddlFilterDate.Add(item.Key, item.Value);
            }

            ddl.PopulateDropDownList("Value", "Key", ddlFilterDate);

        }

        public static void Populateddl(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName)
        {
            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionaryNew(listName, keyColumnName, valueColumnName)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });

            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void PopulateddlNew(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName)
        {
            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionaryNew(listName, keyColumnName, valueColumnName)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });

            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void PopulateddlNewA(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName)
        {
            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDDL(listName, keyColumnName, valueColumnName)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });

            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void GLGetValueForDDL(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter)
        {

            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.GLFillDropDown(listName, keyColumnName, valueColumnName, columnType, filter)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           }).OrderByDescending(x => x.Value);
            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void LEC_Populateddl(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter)
        {

            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionary(listName, keyColumnName, valueColumnName, columnType, filter)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });


            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void Workshop_Populateddl(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter)
        {

            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.WorkShopFillDropDown(listName, keyColumnName, valueColumnName, columnType, filter)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });


            ddl.PopulateDropDownList("Value", "Key", ddlData);
        }

        public static void ConfPopulateddl(this DropDownList ddl, Workshop ws, string listName, string keyColumnName, string valueColumnName, string columnType, KeyValuePair<string, string> filter, bool FilterByDate)
        {
            var ddlData = (from KeyValuePair<string, string> ddlRow in ws.getListAsDictionaryWithFilter1(listName, keyColumnName, valueColumnName, columnType, filter)
                           select new
                           {
                               Key = ddlRow.Key,
                               Value = ddlRow.Value
                           });

            ddl.DataSource = ddlData;
            ddl.DataTextField = "Value";
            ddl.DataValueField = "Key";
            ddl.DataBind();
        }
    }
}