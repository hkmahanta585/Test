﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_ConfrenceEdit
{
    [ToolboxItemAttribute(false)]
    public partial class CnW_ConfrenceEdit : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public CnW_ConfrenceEdit()
        {
        }

        #region Global Variable
        //string _WRequest = WebConfigurationManager.AppSettings["_WRequest"].ToString();
        string siteURL = SPContext.Current.Web.Url.ToString();
        string _editItemID = string.Empty;
        Workshop _ws;
        #endregion


        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.Request.QueryString["EditID"] != null)
            {
                _editItemID = Page.Request.QueryString["EditID"].ToString();
            }

            if (!this.Page.IsPostBack)
            {
                if (_editItemID != null)
                {
                    ddlCategory.Items.Add(new ListItem("--Select--", "0"));
                    ddlCategory.Items.Add(new ListItem("Conference or Seminar"));
                    ddlCategory.Items.Add(new ListItem("Training or Workshop"));
                    FillExisitngRecord(_editItemID);

                }
            }
        }

        private void FillExisitngRecord(string _editItemID)
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstWorskhop = oWeb.Lists.TryGetList("Conference & Workshop");
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                    <Eq>
                                        <FieldRef Name='ID' />
                                        <Value Type='Text'>" + _editItemID + @"</Value>
                                    </Eq>
                                    </Where>";
                        DataTable grdRequest = lstWorskhop.GetItems(qry).GetDataTable();
                        DataRow drGridRequest = grdRequest.Rows[0];

                        if ((DateTime)drGridRequest["WStartDate"] > DateTime.Today)
                        {
                            btnSubmit.Visible = true;
                        }
                        else
                        {
                            btnSubmit.Visible = false;
                        }
                        txtRequestID.Text = drGridRequest["WorkshopID"].ToString();

                        //Pouplating Segment
                        PopulateSegmentDropdown();

                        ddlSegment.Items.FindByText(Convert.ToString(drGridRequest["Segment"])).Selected = true;


                        //Populating  Sector
                        PopulateSector(Convert.ToString(drGridRequest["Segment"]));
                        ddlSector.Items.FindByText(Convert.ToString(drGridRequest["Sector"])).Selected = true;

                        //Populating Group
                        PopulateGroup(Convert.ToString(drGridRequest["Sector"]));
                        ddlBusiness.Items.FindByText(Convert.ToString(drGridRequest["Technology"])).Selected = true;

                        txtOrganized.Text = drGridRequest["OrganizedBy"].ToString();
                        txtConfName.Text = drGridRequest["Title"].ToString();
                        //txtConfName.Text = drGridRequest["NameSDate"].ToString();

                        txtEventName.Text = drGridRequest["EventName"].ToString();
                        DateTime sdt = Convert.ToDateTime(drGridRequest["WStartDate"]);
                        txtSDate.Text = sdt.ToString("dd-MMM-yyyy");
                        DateTime edt = Convert.ToDateTime(drGridRequest["WEndDate"]);
                        txtEDate.Text = edt.ToString("dd-MMM-yyyy");

                        txtDuration.Text = drGridRequest["Duration"].ToString();
                        txtLocation.Text = drGridRequest["Location"].ToString();

                        ddlCategory.Items.FindByText(Convert.ToString(drGridRequest["Category"])).Selected = true;
                        ddlOverseas.Items.FindByText(Convert.ToString(drGridRequest["Overseas"])).Selected = true;


                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on FillExisitngRecord()", ex.Message);
            }
        }

        #region Cascaded Dropdowns Controlling

        private void PopulateSegmentDropdown()
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstSegment = oWeb.Lists.TryGetList("Segment");
                        //SPListItemCollection lstCollSegment = lstSegment.Items;
                        DataTable dtSegment = lstSegment.GetItems().GetDataTable();

                        if (dtSegment != null)
                        {
                            ddlSegment.DataSource = dtSegment;
                            ddlSegment.DataTextField = dtSegment.Columns["Title"].ToString();
                            ddlSegment.DataValueField = dtSegment.Columns["ID"].ToString();
                            ddlSegment.DataBind();
                            ddlSegment.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSegment.DataSource = Emptydt;
                            ddlSegment.DataBind();
                            ddlSegment.Items.Insert(0, "--Select--");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on PopulateSegmentDropdown()", ex.Message);
            }
        }

        private void PopulateGroup(string strSector)
        {
            string strSectorValue = strSector;
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {

                        SPList lstGroup = oWeb.Lists.TryGetList("Group");
                        //SPListItemCollection lstCollSegment = lstSegment.Items;
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='Sector' />
                                             <Value Type='Lookup'>" + strSectorValue + @"</Value>
                                          </Eq>
                                       </Where>";
                        //qry.Query = "<Query><Where><Eq><FieldRef Name ='Segment' LookupId='true' /><Value Type ='Lookup'>"+strSegmentValue+"</Value></Eq></Where></Query>";
                        DataTable dtGroup = lstGroup.GetItems(qry).GetDataTable();
                        if (dtGroup != null)
                        {
                            ddlBusiness.DataSource = dtGroup;
                            ddlBusiness.DataTextField = dtGroup.Columns["Title"].ToString();
                            ddlBusiness.DataValueField = dtGroup.Columns["FunctionCOEHead"].ToString();
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _ws.LogError("Error on PopulateGroup()", ex.Message);
            }
        }

        private void PopulateSector(string strSegment)
        {
            string strSegmentValue = strSegment;
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {

                        SPList lstSector = oWeb.Lists.TryGetList("Sector");
                        //SPListItemCollection lstCollSegment = lstSegment.Items;
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='Segment' />
                                             <Value Type='Lookup'>" + strSegmentValue + @"</Value>
                                          </Eq>
                                       </Where>";
                        //qry.Query = "<Query><Where><Eq><FieldRef Name ='Segment' LookupId='true' /><Value Type ='Lookup'>"+strSegmentValue+"</Value></Eq></Where></Query>";
                        DataTable dtSector = lstSector.GetItems(qry).GetDataTable();
                        if (dtSector != null)
                        {
                            ddlSector.DataSource = dtSector;
                            ddlSector.DataTextField = dtSector.Columns["Title"].ToString();
                            ddlSector.DataValueField = dtSector.Columns["ID"].ToString();
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSector.DataSource = Emptydt;
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");


                            // DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _ws.LogError("Error on PopulateSector()", ex.Message);
            }

        }
        #endregion

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if ((Convert.ToDateTime(txtSDate.Text) > Convert.ToDateTime(txtEDate.Text)) || (DateTime.Now > Convert.ToDateTime(txtSDate.Text)))
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                //sb.Append(@"<script language='javascript'>");
                //sb.Append(@"alert('Start Date should be less than End Date and greater than today's date.');");
                //sb.Append(@"</script>");
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", "alert('Start Date should be less than End Date and greater than todays date.');", true);

            }
            else
            {

                try
                {
                    using (SPSite osite = new SPSite(siteURL))
                    {
                        using (SPWeb oWeb = osite.OpenWeb())
                        {
                            SPList list = oWeb.Lists.TryGetList("Conference & Workshop");
                            SPListItem listItem = list.GetItemById(Convert.ToInt32(_editItemID));
                            listItem["OrganizedBy"] = txtOrganized.Text;
                            listItem["Title"] = txtConfName.Text;
                            listItem["NameSDate"] = txtConfName.Text + " [" + GetDate(txtSDate.Text).ToString("dd-MMM-yyyy") + "]";

                            listItem["EventName"] = txtEventName.Text;
                            listItem["WStartDate"] = txtSDate.Text;
                            listItem["WEndDate"] = txtEDate.Text;

                            listItem["Duration"] = txtDuration.Text;
                            listItem["Location"] = txtLocation.Text;
                            //listItem["ConfType"] = ddlConfType.SelectedItem.ToString();
                            listItem["Technology"] = ddlBusiness.SelectedItem.ToString();
                            listItem["Segment"] = ddlSegment.SelectedItem.Text;
                            listItem["Sector"] = ddlSector.SelectedItem.Text;
                            listItem["Category"] = ddlCategory.SelectedValue.ToString();
                            listItem["Overseas"] = ddlOverseas.SelectedItem.Text;
                            listItem["ConfYear"] = Convert.ToDateTime(txtSDate.Text.Trim()).Year;
                            listItem["DelFlag"] = "0";
                            listItem.Update();


                            System.Text.StringBuilder sb = new System.Text.StringBuilder();
                            //sb.Append(@"<script type='text/javascript'>");
                            //sb.Append(@"alert('Changes have been implemented successfully.');");
                            //sb.Append(@"window.location (file://sb.append(@/) = '/Pages/Confrence_Workshop/ConfrenceList.aspx';");
                            //sb.Append(@"</script>");
                            //Page.ClientScript.RegisterStartupScript(this.GetType(), "script", sb.ToString());
                            string msg = "Changes have been implemented successfully.";
                            string destination = "/Pages/Confrence_Workshop/ConfrenceList.aspx";
                            string alert_redirect_Script = string.Format(@"<script type=""text/javascript"">
                                       alert('{0}');
                                        window.location.href = '/Pages/Confrence_Workshop/ConferenceList.aspx';
                                       </script>", msg);
                            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", alert_redirect_Script, false);
                        }
                    }
                }

                catch (Exception ex)
                {
                    _ws.LogError("Error on btnSubmit_Click()", ex.Message);
                }
                //this.Page.Response.Redirect("ConferenceList.aspx", true);
            }

        }


        public DateTime GetDate(string dateText)
        {
            System.Globalization.CultureInfo newCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            System.Globalization.CultureInfo oldCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            newCulture.DateTimeFormat.DateSeparator = "-";
            newCulture.DateTimeFormat.ShortDatePattern = "dd-MM-yyyy";
            System.Threading.Thread.CurrentThread.CurrentCulture = newCulture;
            DateTime dt = Convert.ToDateTime(dateText);
            System.Threading.Thread.CurrentThread.CurrentCulture = oldCulture;
            return dt;
        }

        public void SetField()
        {
            txtOrganized.Text = string.Empty;
            txtConfName.Text = string.Empty;
            txtEventName.Text = string.Empty;
            txtSDate.Text = string.Empty;
            txtEDate.Text = string.Empty;
            txtDuration.Text = string.Empty;
            txtLocation.Text = string.Empty;
            txtDuration.Text = string.Empty;
        }
        public void AddErrorMessage(string message)
        {
            var validator = new CustomValidator();
            validator.IsValid = false;
            validator.ErrorMessage = message;
            Page.Validators.Add(validator);
        }

        protected void ddlSegment_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSegmentValue = ddlSegment.SelectedItem.Text;
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstSector = oWeb.Lists.TryGetList("Sector");

                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='Segment' />
                                             <Value Type='Lookup'>" + strSegmentValue + @"</Value>
                                          </Eq>
                                       </Where>";

                        DataTable dtSector = lstSector.GetItems(qry).GetDataTable();
                        if (dtSector != null)
                        {
                            ddlSector.DataSource = dtSector;
                            ddlSector.DataTextField = dtSector.Columns["Title"].ToString();
                            ddlSector.DataValueField = dtSector.Columns["ID"].ToString();
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSector.DataSource = Emptydt;
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");

                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on ddlSegment_SelectedIndexChanged()", ex.Message);
            }
        }

        protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSectorValue = ddlSector.SelectedItem.Text;
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstGroup = oWeb.Lists.TryGetList("Group");

                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='Sector' />
                                             <Value Type='Lookup'>" + strSectorValue + @"</Value>
                                          </Eq>
                                       </Where>";

                        DataTable dtGroup = lstGroup.GetItems(qry).GetDataTable();
                        if (dtGroup != null)
                        {
                            ddlBusiness.DataSource = dtGroup;
                            ddlBusiness.DataTextField = dtGroup.Columns["Title"].ToString();
                            ddlBusiness.DataValueField = dtGroup.Columns["ID"].ToString();
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");


                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _ws.LogError("Error on ddlSector_SelectedIndexChanged", ex.Message);
            }
        }



        protected void ddlSegment_DataBound(object sender, EventArgs e)
        {
            // ddlSegment.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void ddlSector_DataBound(object sender, EventArgs e)
        {
            // ddlSector.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        protected void ddlBusiness_DataBound(object sender, EventArgs e)
        {
            // ddlBusiness.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

            Page.Response.Redirect("/Pages/Confrence_Workshop/ConferenceList.aspx", true);
        }

        protected void popUpCancel_Click(object sender, EventArgs e)
        {
            //Page.Response.Redirect("ConferenceList.aspx", true);
        }





    }
}
