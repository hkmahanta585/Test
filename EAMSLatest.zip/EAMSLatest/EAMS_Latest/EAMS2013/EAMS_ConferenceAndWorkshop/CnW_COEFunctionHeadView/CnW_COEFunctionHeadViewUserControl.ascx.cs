﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_COEFunctionHeadView
{
    public partial class CnW_COEFunctionHeadViewUserControl : UserControl
    {

        #region ---------Global Variables------------
        Workshop _ws;
        string confID;
        string _editItemID;
        string _level;
        DataTable dtReq = null;
        Dictionary<string, string> filters;
        string siteURL = SPContext.Current.Web.Url;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack )
            {
                BindData();
            } 
        }

        private void BindData()
        {
            try
            {
                lblRequests.Text = string.Empty;
                lbltripReports.Text = string.Empty;
                lblTripReportsApproved.Text = string.Empty;
                using (SPSite osite = new SPSite(siteURL))
                {
                    using (SPWeb oweb = osite.OpenWeb())
                    {
                        GetCompletedRequestCount(oweb);
                        GetUploadedTripReportsCount(oweb);
                        GetApprovedTripReportCount(oweb);
                        
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on populateRequestID()", ex.Message);
            }
        }

        private void GetApprovedTripReportCount(SPWeb oweb)
        {
            try
            {
                SPList spList = oweb.Lists.TryGetList("WorkshopDocs");
                SPQuery qry = new SPQuery();
                qry.Query =
                @"   <Where>
                       <Or>
                          <Eq>
                             <FieldRef Name='Status' />
                             <Value Type='Text'>Level1</Value>
                          </Eq>
                          <Eq>
                             <FieldRef Name='Status' />
                             <Value Type='Text'>Level2</Value>
                          </Eq>
                       </Or>
                    </Where>";
                SPListItemCollection oItems = spList.GetItems(qry); 
                if (oItems.Count > 0)
                {
                    lblTripReportsApproved.Text = oItems.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on GetCompletedRequestCount()", ex.Message);
            }
        }

        private void GetUploadedTripReportsCount(SPWeb oweb)
        {
            try
            {
                SPList spList = oweb.Lists.TryGetList("WorkshopDocs");
               
                SPListItemCollection oItems = spList.GetItems();
                if (oItems.Count > 0)
                {
                    lbltripReports.Text = oItems.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on GetUploadedTripReportsCount()", ex.Message);
            }
        }

        private void GetCompletedRequestCount(SPWeb oweb)
        {
            try
            {
                SPList spList = oweb.Lists.TryGetList("WorkshopRequests");
                SPQuery qry = new SPQuery();
                qry.Query = @"<Where>
                                   <Eq>
                                    <FieldRef Name='RStatus' />
                                    <Value Type='Text'>Completed</Value>
                                 </Eq>
                           </Where>";
                SPListItemCollection oItems = spList.GetItems(qry);
                if (oItems.Count > 0)
                {
                    lblRequests.Text = oItems.Count.ToString();
                }
            }
            catch(Exception ex)
            {
                _ws.LogError("Error on GetCompletedRequestCount()", ex.Message);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            this.Page.Response.Redirect("/Pages/Confrence_Workshop/Summary.aspx");
        }
    }
}
