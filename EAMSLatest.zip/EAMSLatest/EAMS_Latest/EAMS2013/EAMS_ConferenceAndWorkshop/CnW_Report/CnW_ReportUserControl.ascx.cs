﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Linq;
using System.Data;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace EAMS_ConferenceAndWorkshop.CnW_Report
{
    public partial class CnW_ReportUserControl : UserControl
    {
        Workshop _ws;
        string listName = string.Empty;
        string keyColumnName = string.Empty;
        string valueColumnName = string.Empty;
        string siteURL = SPContext.Current.Web.Url;

        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();
           // txtSSDate.Text = DateTime.Today.AddDays(-7).ToString("dd-MMM-yyyy");
           // txtSEDate.Text = DateTime.Today.ToString("dd-MMM-yyyy");
           
            try
            {
                if (!Page.IsPostBack)
                {
                    PopulateSegmentDropdown();
                    PopulateSiteDropdown();
                }

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Page Load()" + ex.Message, ex.StackTrace);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                getFilter();
            }
            catch (SPException ex)
            {
                _ws.LogError("Error on Search" + ex.Message, ex.StackTrace);
            }
        }

        protected void ddlSegement_SelectedIndexChanged(object sender, EventArgs e)
        {
            string segmentId = ddlSegement.SelectedItem.Text.Trim();
            PopulateSector(segmentId);
        }

        protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
        {

            string sectorName = ddlSector.SelectedItem.Text.Trim();
            PopulateGroup(sectorName);
            //ddlBusiness.Populateddl(ws: _ws, listName: "Group", keyColumnName: "ID", valueColumnName: "Title", columnType: "Choice", filter: new KeyValuePair<string, string>("Sector", sectorName));
        }

        public override void RenderControl(HtmlTextWriter writer)
        {
            base.RenderControl(writer);
        }

        protected override void RenderChildren(HtmlTextWriter writer)
        {
            base.RenderChildren(writer);
        }

        #region ------------Methods-------------

        private void PopulateSegmentDropdown()
        {
            _ws = new Workshop();
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        DataTable dtSegment = _ws.PopulateSegmentDropdown(oWeb);

                        if (dtSegment != null)
                        {
                            ddlSegement.DataSource = dtSegment;
                            ddlSegement.DataTextField = dtSegment.Columns["Title"].ToString();
                            ddlSegement.DataValueField = dtSegment.Columns["ID"].ToString();
                            ddlSegement.DataBind();
                            ddlSegement.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSegement.DataSource = Emptydt;
                            ddlSegement.DataBind();
                            ddlSegement.Items.Insert(0, "--Select--");
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate PopulateSegmentDropdown", ex.Message);
            }
        }

        private void PopulateSector(string strSegment)
        {
            _ws = new Workshop();
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        DataTable dtSector = _ws.PopulateSectorDropdown(oWeb, strSegment);
                        if (dtSector != null)
                        {
                            ddlSector.DataSource = dtSector;
                            ddlSector.DataTextField = dtSector.Columns["Title"].ToString();
                            ddlSector.DataValueField = dtSector.Columns["ID"].ToString();
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");

                            DataTable Emptydt = new DataTable();
                            ddlGroup.DataSource = Emptydt;
                            ddlGroup.DataBind();
                            ddlGroup.Items.Insert(0, "--Select--");

                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSector.DataSource = Emptydt;
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");
                            // DataTable Emptydt = new DataTable();
                            ddlGroup.DataSource = Emptydt;
                            ddlGroup.DataBind();
                            ddlGroup.Items.Insert(0, "--Select--");

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate sector", ex.Message); throw ex;
            }

        }

        private void PopulateGroup(string strSector)
        {
            _ws = new Workshop();
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        DataTable dtGroup = _ws.PopulateGroupDropdown(oWeb, strSector);
                        if (dtGroup != null)
                        {
                            ddlGroup.DataSource = dtGroup;
                            ddlGroup.DataTextField = dtGroup.Columns["Title"].ToString();
                            ddlGroup.DataValueField = dtGroup.Columns["ID"].ToString();
                            ddlGroup.DataBind();
                            ddlGroup.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlGroup.DataSource = Emptydt;
                            ddlGroup.DataBind();
                            ddlGroup.Items.Insert(0, "--Select--");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate Group", ex.Message);
            }
        }

        private void PopulateSiteDropdown()
        {
            _ws = new Workshop();
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        DataTable dtSite = _ws.PopulateSiteDropdown(oWeb);
                        ddlSite.DataSource = dtSite;
                        ddlSite.DataTextField = dtSite.Columns["Title"].ToString();
                        ddlSite.DataValueField = dtSite.Columns["ID"].ToString();
                        ddlSite.DataBind();
                        ddlSite.Items.Insert(0, "--Select--");
                    }
                }

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate PopulateSiteDropdown", ex.Message); throw ex;
            }
        }

        private void getFilter()
        {
            DataTable dtDateFilter = new DataTable();
            gvConference.Visible = true;
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList olist = oWeb.Lists.TryGetList("WorkshopRequests");
                        SPQuery camlQuery = new SPQuery();

                        if (!string.IsNullOrEmpty(txtSSDate.Text) && !string.IsNullOrEmpty(txtSEDate.Text))
                        {
                            DateTime ddtSubStartDate = Convert.ToDateTime(txtSSDate.Text);
                            DateTime ddtSubEndDate = Convert.ToDateTime(txtSEDate.Text);
                            camlQuery.Query = @"<Where><And>
                                            <Geq><FieldRef Name='Created' /><Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(ddtSubStartDate) + @"</Value></Geq>
                                            <Leq><FieldRef Name='Created' /><Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(ddtSubEndDate) + @"</Value></Leq>
                                            </And></Where>";
                            SPListItemCollection collection = olist.GetItems(camlQuery);

                            dtDateFilter = collection.GetDataTable();
                        }
                        else if (!string.IsNullOrEmpty(txtCSDate.Text) && !string.IsNullOrEmpty(txtCEDate.Text))
                        {
                            DateTime ddtConfStartDate = Convert.ToDateTime(txtCSDate.Text);
                            DateTime ddtConfEndDate = Convert.ToDateTime(txtCEDate.Text);
                            camlQuery.Query = @"<Where><And>
                                            <Geq><FieldRef Name='WorkshopRefID_x003a_WStartDate' /><Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(ddtConfStartDate) + @"</Value></Geq>
                                            <Leq><FieldRef Name='WorkshopRefID_x003a_WEndDate' /><Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(ddtConfEndDate) + @"</Value></Leq>
                                            </And></Where>";
                            SPListItemCollection collection = olist.GetItems(camlQuery);

                            dtDateFilter = collection.GetDataTable();
                        }


                        else if (pickUser.ResolvedEntities.Count > 0)
                        {
                            //SPUser userReq = oWeb.EnsureUser(pickUser.InitialUserAccounts.Split('|')[1]);
                            string _empName = pickUser.AllEntities[0].DisplayText;
                            camlQuery.Query = "<Where><Eq><FieldRef Name='Requestor' /><Value Type='User'>" + _empName + "</Value></Eq></Where>";
                            SPListItemCollection collection = olist.GetItems(camlQuery);

                            dtDateFilter = collection.GetDataTable();
                        }
                        else if (!string.IsNullOrEmpty(txtConfID.Text))
                        {
                            string _ConfID = Convert.ToString(txtConfID.Text);
                            camlQuery.Query = "<Where><Eq><FieldRef Name='WorkshopRefID_x003a_WorkshopID' /><Value Type='Lookup'>" + _ConfID + "</Value></Eq></Where>";
                            SPListItemCollection collection = olist.GetItems(camlQuery);

                            dtDateFilter = collection.GetDataTable();
                        }
                        else if (ddlSegement.SelectedItem.Text != "--Select--")
                        {
                            camlQuery.Query = @"<Where>
                                                  <And>
                                                     <And>
                                                        <And>
                                                           <Eq>
                                                              <FieldRef Name='Segment' />
                                                              <Value Type='Text'>" + ddlSegement.SelectedItem.Text + @"</Value>
                                                           </Eq>
                                                           <Eq>
                                                              <FieldRef Name='Sector' />
                                                              <Value Type='Text'>" + ddlSector.SelectedItem.Text + @"</Value>
                                                           </Eq>
                                                        </And>
                                                        <Eq>
                                                           <FieldRef Name='Business' />
                                                           <Value Type='Text'>" + ddlGroup.SelectedItem.Text + @"</Value>
                                                        </Eq>
                                                     </And>
                                                     <Eq>
                                                        <FieldRef Name='Site' />
                                                        <Value Type='Text'>" + ddlSite.SelectedItem.Text + @"</Value>
                                                     </Eq>
                                                  </And>
                                               </Where>";
                            SPListItemCollection collection = olist.GetItems(camlQuery);

                            dtDateFilter = collection.GetDataTable();
                        }


                        if (dtDateFilter != null)
                        {
                            gvConference.DataSource = dtDateFilter;
                            gvConference.DataBind();
                        }
                        else
                        {
                            gvConference.DataSource = null;
                            gvConference.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on getFilterBySubmitData() " + ex.Message, ex.StackTrace);
                throw ex;
            }
            finally
            {
                if (dtDateFilter != null)
                    dtDateFilter.Dispose();
            }

        }

        #endregion

        protected void ddlSearchFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtSEDate.Text = string.Empty;
            txtSSDate.Text = string.Empty;
            txtCSDate.Text = string.Empty;
            txtCEDate.Text = string.Empty;
            txtConfID.Text = string.Empty;
            pickUser.AllEntities.Clear();
            ddlSegement.Items.FindByText("--Select--").Selected = true;           
            ddlSite.Items.FindByText("--Select--").Selected = true;
            gvConference.Visible = false;

            if (ddlSearchFilter.SelectedIndex == 1)
            {
                divSearchBySubmitDate.Visible = true;
                divSerachByConfDate.Visible = false;
                divSeachByEmpName.Visible = false;
                divSearchByConfID.Visible = false;
                divSearchByOthers.Visible = false;
                btnSearchID.Visible = true;

            }
            else if (ddlSearchFilter.SelectedIndex == 2)
            {
                divSearchBySubmitDate.Visible = false;
                divSerachByConfDate.Visible = true;
                divSeachByEmpName.Visible = false;
                divSearchByConfID.Visible = false;
                divSearchByOthers.Visible = false;
                btnSearchID.Visible = true;

            }
            else if (ddlSearchFilter.SelectedIndex == 3)
            {
                divSearchBySubmitDate.Visible = false;
                divSerachByConfDate.Visible = false;
                divSeachByEmpName.Visible = true;
                divSearchByConfID.Visible = false;
                divSearchByOthers.Visible = false;
                btnSearchID.Visible = true;

            }
            else if (ddlSearchFilter.SelectedIndex == 4)
            {
                divSearchBySubmitDate.Visible = false;
                divSerachByConfDate.Visible = false;
                divSeachByEmpName.Visible = false;
                divSearchByConfID.Visible = true;
                divSearchByOthers.Visible = false;
                btnSearchID.Visible = true;

            }
            else if (ddlSearchFilter.SelectedIndex == 5)
            {
                divSearchBySubmitDate.Visible = false;
                divSerachByConfDate.Visible = false;
                divSeachByEmpName.Visible = false;
                divSearchByConfID.Visible = false;
                divSearchByOthers.Visible = true;
                btnSearchID.Visible = true;

            }
            else
            {
                divSearchBySubmitDate.Visible = false;
                divSerachByConfDate.Visible = false;
                divSeachByEmpName.Visible = false;
                divSearchByConfID.Visible = false;
                divSearchByOthers.Visible =false;
                btnSearchID.Visible = false;
            }
        }

        protected void gvConference_PreRender(object sender, EventArgs e)
        {
            if (gvConference.Rows.Count > 0)
            {
                gvConference.UseAccessibleHeader = true;
                gvConference.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
        }
    }
}
