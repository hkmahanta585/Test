﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_ConfrenceRequest
{
    [ToolboxItemAttribute(false)]
    public partial class CnW_ConfrenceRequest : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public CnW_ConfrenceRequest()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        #region Global Variable
        //string _WRequest = WebConfigurationManager.AppSettings["_WRequest"].ToString();
        string siteURL = SPContext.Current.Web.Url.ToString();
        Workshop _ws;
        #endregion

        public void PopulatePageControls()
        {

            txtRequestID.Text = "CONF" + DateTime.Now.Year;

            string listName = "Segment";
            string keyColumnName = "ID";
            string valueColumnName = "Title";

            PopulateSegmentDropdown();
            ddlCategory.Items.Add(new ListItem("--Select--", "0"));
            ddlCategory.Items.Add(new ListItem("Conference or Seminar"));
            ddlCategory.Items.Add(new ListItem("Training or Workshop"));

        }

        #region Event Handlers

        private void PopulateSegmentDropdown()
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstSegment = oWeb.Lists.TryGetList("Segment");

                        DataTable dtSegment = lstSegment.GetItems().GetDataTable();

                        if (dtSegment != null)
                        {
                            ddlSegment.DataSource = dtSegment;
                            ddlSegment.DataTextField = dtSegment.Columns["Title"].ToString();
                            ddlSegment.DataValueField = dtSegment.Columns["ID"].ToString();
                            ddlSegment.DataBind();
                            ddlSegment.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSegment.DataSource = Emptydt;
                            ddlSegment.DataBind();
                            ddlSegment.Items.Insert(0, "--Select--");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on PopulateSegmentDropdown()", ex.Message);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {

                PopulatePageControls();
            }

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if ((Convert.ToDateTime(txtSDate.Text) > Convert.ToDateTime(txtEDate.Text)) || (DateTime.Now > Convert.ToDateTime(txtSDate.Text)))
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                //sb.Append(@"<script language='javascript'>");
                //sb.Append(@"alert('Start Date should be less than End Date and greater than today's date.');");
                //sb.Append(@"</script>");
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", "alert('Start Date should be less than End Date and greater than todays date.');", true);



            }
            else
            {

                try
                {
                    using (SPSite osite = new SPSite(siteURL))
                    {
                        using (SPWeb oWeb = osite.OpenWeb())
                        {
                            SPList list = oWeb.Lists.TryGetList("Conference & Workshop");
                            SPListItem listItem = list.AddItem();
                            listItem["OrganizedBy"] = txtOrganized.Text;
                            listItem["Title"] = txtConfName.Text;
                            listItem["NameSDate"] = txtConfName.Text + " [" + GetDate(txtSDate.Text).ToString("dd-MMM-yyyy") + "]";

                            listItem["EventName"] = txtEventName.Text;
                            listItem["WStartDate"] = txtSDate.Text;
                            listItem["WEndDate"] = txtEDate.Text;

                            listItem["Duration"] = txtDuration.Text+" Days";
                            listItem["Location"] = txtLocation.Text;
                            //listItem["ConfType"] = ddlConfType.SelectedItem.ToString();
                            listItem["Technology"] = ddlBusiness.SelectedItem.ToString();
                            listItem["Segment"] = ddlSegment.SelectedItem.Text;
                            listItem["Sector"] = ddlSector.SelectedItem.Text;
                            listItem["Category"] = ddlCategory.SelectedValue.ToString();
                            listItem["Overseas"] = ddlOverseas.SelectedItem.Text;
                            listItem["ConfYear"] = Convert.ToDateTime(txtSDate.Text.Trim()).Year;
                            listItem["DelFlag"] = "0";
                            listItem.Update();

                            int intInsertedId = listItem.ID;
                            listItem = list.GetItemById(intInsertedId);
                            listItem["WorkshopID"] = "CONF" + DateTime.Now.Year + intInsertedId.ToString("0000");
                            listItem.Update();

                            System.Text.StringBuilder sb = new System.Text.StringBuilder();
                            sb.Append(@"<script type='text/javascript'>");
                            sb.Append(@"alert('Confrence has been created successfully.');");
                            sb.Append(@"window.location (file://sb.append(@/) = '/Pages/Confrence_Workshop/ConfrenceList.aspx';");
                            sb.Append(@"</script>");
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", sb.ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    _ws.LogError("Error on btnSubmit_Click()", ex.Message);
                }
               Page.Response.Redirect("ConferenceList.aspx", true);
            }

        }

        public DateTime GetDate(string dateText)
        {
            System.Globalization.CultureInfo newCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            System.Globalization.CultureInfo oldCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            newCulture.DateTimeFormat.DateSeparator = "-";
            newCulture.DateTimeFormat.ShortDatePattern = "dd-MM-yyyy";
            System.Threading.Thread.CurrentThread.CurrentCulture = newCulture;
            DateTime dt = Convert.ToDateTime(dateText);
            System.Threading.Thread.CurrentThread.CurrentCulture = oldCulture;
            return dt;
        }

        public void SetField()
        {
            txtOrganized.Text = string.Empty;
            txtConfName.Text = string.Empty;
            txtEventName.Text = string.Empty;
            txtSDate.Text = string.Empty;
            txtEDate.Text = string.Empty;
            txtDuration.Text = string.Empty;
            txtLocation.Text = string.Empty;
            txtDuration.Text = string.Empty;
        }
        public void AddErrorMessage(string message)
        {
            var validator = new CustomValidator();
            validator.IsValid = false;
            validator.ErrorMessage = message;
            Page.Validators.Add(validator);
        }

        protected void ddlSegment_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSegmentValue = ddlSegment.SelectedItem.Text;
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstSector = oWeb.Lists.TryGetList("Sector");

                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='Segment' />
                                             <Value Type='Lookup'>" + strSegmentValue + @"</Value>
                                          </Eq>
                                       </Where>";

                        DataTable dtSector = lstSector.GetItems(qry).GetDataTable();
                        if (dtSector != null)
                        {
                            ddlSector.DataSource = dtSector;
                            ddlSector.DataTextField = dtSector.Columns["Title"].ToString();
                            ddlSector.DataValueField = dtSector.Columns["ID"].ToString();
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSector.DataSource = Emptydt;
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");

                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on ddlSegment_SelectedIndexChanged()", ex.Message);
            }
        }

        protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSectorValue = ddlSector.SelectedItem.Text;
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstGroup = oWeb.Lists.TryGetList("Group");

                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='Sector' />
                                             <Value Type='Lookup'>" + strSectorValue + @"</Value>
                                          </Eq>
                                       </Where>";

                        DataTable dtGroup = lstGroup.GetItems(qry).GetDataTable();
                        if (dtGroup != null)
                        {
                            ddlBusiness.DataSource = dtGroup;
                            ddlBusiness.DataTextField = dtGroup.Columns["Title"].ToString();
                            ddlBusiness.DataValueField = dtGroup.Columns["ID"].ToString();
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");


                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _ws.LogError("Error on ddlSector_SelectedIndexChanged()", ex.Message);
            }
        }



        protected void ddlSegment_DataBound(object sender, EventArgs e)
        {
            // ddlSegment.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void ddlSector_DataBound(object sender, EventArgs e)
        {
            // ddlSector.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        protected void ddlBusiness_DataBound(object sender, EventArgs e)
        {
            // ddlBusiness.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

            Page.Response.Redirect("/Pages/Confrence_Workshop/ConferenceList.aspx", true);
        }

        protected void popUpCancel_Click(object sender, EventArgs e)
        {
            //Page.Response.Redirect("ConferenceList.aspx", true);
        }
        #endregion

        protected void txtSDate_TextChanged(object sender, EventArgs e)
        {
            txtEDate.Text = Convert.ToDateTime(txtSDate.Text).AddDays(1).ToString("dd-MMM-yyyy");
        }

        








    }
}
