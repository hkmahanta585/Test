﻿using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.Administration;
using System.Linq;
using System.IO;


namespace EAMS_ConferenceAndWorkshop.CnW_Request
{
    public partial class CnW_RequestUserControl : UserControl
    {
        #region -----------Global Variables--------
        Workshop _ws = new Workshop();
        string _editItemID;
        string _manager = string.Empty;
        string progDuration = string.Empty;
        string siteURL = SPContext.Current.Web.Url;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();
            if (!IsPostBack)
            {

                #region -------------Edit Page---------
                if (Page.Request.QueryString["EditID"] != null)
                {
                    _editItemID = Page.Request.QueryString["EditID"].ToString();
                    Linkrow.Visible = true;
                    PopulatePageControlsWithExisting(_editItemID);
                }
                #endregion
                else
                {
                    PreviousSelectionMatrix();
                    PopulateSiteDropdown();

                    #region ------------Page Submission----------

                    rowBudget.Visible = false;
                    txtRequestID.Text = "CONF" + DateTime.Now.Year + "XXXX-XXX";
                    txtCurrentUser.Text = SPContext.Current.Web.CurrentUser.Name;
                    //Changed by Mahanta--18/09/2017
                    string _EmpCode = _ws.getEC(SPContext.Current.Web.CurrentUser.LoginName);
                    if (!string.IsNullOrEmpty(_EmpCode))
                        txtEmpCode.Text = _EmpCode;
                    else
                        txtEmpCode.Text = "-";                    
                    //End---
                    populateSeekingApprovalFor();
                    PopulatePrograms(ddlSeekingforapproval.SelectedItem.Text.ToString());

                    #endregion
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string ProgTitle = ddlProgramTitle.SelectedItem.Text;
            string draftFlag = ((Button)sender).CommandArgument;

            if (drdbudget.SelectedItem.Text == "Yes" && txtBudget.Text.Length == 0)
            {
                var validator = new CustomValidator();
                validator.IsValid = false;
                validator.ErrorMessage = "Please enter description for budget.";
                Page.Validators.Add(validator);
            }
            else
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        try
                        {
                            string _reqID = string.Empty;
                            if (!string.IsNullOrEmpty(Page.Request.QueryString["EditID"]))
                            {
                                _reqID = Page.Request.QueryString["EditID"];
                            }

                            oWeb.AllowUnsafeUpdates = true;
                            SPList list = oWeb.Lists.TryGetList("WorkshopRequests");
                            SPListItem fileItem;
                            string requestId = string.Empty;

                            if (string.IsNullOrEmpty(_reqID))//New Request
                            {
                                fileItem = list.AddItem();
                                fileItem.Update();
                                requestId = ViewState["WorkshopID"].ToString() + "-" + fileItem.ID.ToString("000");
                                fileItem["Title"] = requestId;
                                fileItem["RequestID"] = requestId;
                            }
                            else//Edit Request
                            {
                                fileItem = list.GetItemById(Convert.ToInt32(_reqID));
                                requestId = txtRequestID.Text;
                                fileItem["Title"] = requestId;
                                fileItem["RequestID"] = requestId;
                            }

                            #region -----------Fields --------------

                            fileItem["EmpCode"] = txtEmpCode.Text;
                            fileItem["Segment"] = ddlSegment.SelectedItem.Text;
                            fileItem["Site"] = ddlSite.SelectedItem.Text;
                            fileItem["Sector"] = ddlSector.SelectedItem.Text;
                            fileItem["Business"] = ddlBusiness.SelectedItem.Text;
                            fileItem["WorkshopRefID"] = new SPFieldLookupValue(ddlProgramTitle.SelectedValue);
                            fileItem["ApprovalFor"] = ddlSeekingforapproval.SelectedItem.Text;

                            #endregion

                            #region------------Getting Approver Head------------------
                            //----------------Danger Zone----------------------

                            //Level 1 :- current user manager 
                            fileItem.Fields["Manager"].ReadOnlyField = false;
                            fileItem["Manager"] = _ws.getMgr(SPContext.Current.Web.CurrentUser.LoginName).ID;

                            SPUser siteHead;
                            //Level 2 :- COE Function Head / Site CTS Head (Site = "COE") 
                            if (Check(ddlSite.SelectedValue, _ws.getID("Site", new KeyValuePair<string, string>("Title", "COE")).ToString()))
                            {
                                siteHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                            }
                            else
                            {
                                siteHead = _ws.getSiteSectorHead("SiteSectorHead", ddlSite.SelectedItem.ToString(), ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "SiteSectorHead");
                            }
                            //RNTFlag (denote wether Segment Head is RnD Head or Not)
                            if (Check(ddlSegment.SelectedValue, _ws.getID("Segment", new KeyValuePair<string, string>("Title", "R&D")).ToString()))
                            {
                                siteHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                            }
                            fileItem.Fields["HOD"].ReadOnlyField = false;
                            fileItem["HOD"] = siteHead.ID;

                            //Level 3 :- Planning & Stratagy Head
                            SPUser _planningHead = _ws.GetListValue("Sector", ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "PSHead");
                            fileItem.Fields["PlanningHead"].ReadOnlyField = false;
                            fileItem["PlanningHead"] = _planningHead.ID;

                            //--------PSHead ASSISTANT---------
                            SPUser _planningHeadAssistant = _ws.GetListValue("Sector", ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "PSHeadAssistant");
                            fileItem.Fields["PSHeadAssistant"].ReadOnlyField = false;
                            fileItem["PSHeadAssistant"] = _planningHeadAssistant.ID;

                            //Segment Flag for RnD Head
                            if (Check(ddlSegment.SelectedValue, _ws.getID("Segment", new KeyValuePair<string, string>("Title", "R&D")).ToString()))
                            {
                                fileItem["RNDCheck"] = "Yes";
                            }
                            else
                            {
                                fileItem["RNDCheck"] = "No";
                            }

                            //Tech COE Head
                            SPUser _coeHead = _ws.getUserFromList("Sector", new KeyValuePair<string, string>("Title", ddlSector.SelectedItem.ToString()), "COEHead");
                            fileItem.Fields["COEHead"].ReadOnlyField = false;
                            fileItem["COEHead"] = _coeHead.ID;

                            //--------COEHead ASSISTANT---------
                            SPUser _coeHeadAssistant = _ws.getUserFromList("Sector", new KeyValuePair<string, string>("Title", ddlSector.SelectedItem.ToString()), "COEHeadAssistant");
                            fileItem.Fields["COEHeadAssistant"].ReadOnlyField = false;
                            fileItem["COEHeadAssistant"] = _coeHeadAssistant.ID;

                            //Site President  
                            SPUser sitePresident = _ws.getUserFromList("Site", new KeyValuePair<string, string>("Title", ddlSite.SelectedItem.ToString()), "SitePresident");
                            fileItem.Fields["SitePresident"].ReadOnlyField = false;
                            fileItem["SitePresident"] = sitePresident.ID;

                            //-----------Site President assistant-------------  
                            SPUser _sitePresidentAssistant = _ws.getUserFromList("Site", new KeyValuePair<string, string>("Title", ddlSite.SelectedItem.ToString()), "SitePresidentAssistant");
                            fileItem.Fields["SitePresidentAssistant"].ReadOnlyField = false;
                            fileItem["SitePresidentAssistant"] = _sitePresidentAssistant.ID;

                            //Level 5 :- GMS / RnD Head
                            SPUser segHead = _ws.getUserFromList("Segment", new KeyValuePair<string, string>("Title", ddlSegment.SelectedItem.Text.Trim()), "SeniorManagement");
                            fileItem.Fields["RNDHead"].ReadOnlyField = false;
                            fileItem["RNDHead"] = segHead.ID;

                            //---------RNDHead Assistant-----------------
                            SPUser _RnDHeadAssitant = _ws.getUserFromList("Segment", new KeyValuePair<string, string>("Title", ddlSegment.SelectedItem.Text.Trim()), "SeniorManagementAssistant");
                            fileItem.Fields["RNDHeadAssistant"].ReadOnlyField = false;
                            fileItem["RNDHeadAssistant"] = _RnDHeadAssitant.ID;


                            //--------------End Of Danger Zone-------------------------------------------
                            #endregion

                            #region -----------Other Fields------------

                            fileItem["Accommodation"] = ddlAccomm.SelectedItem.Text;
                            fileItem["KeyReason"] = txtreason.Text;
                            fileItem["ValueField"] = txtValue.Text;
                            fileItem["BudgetDesc"] = (drdbudget.SelectedItem.Text == "Yes" ? txtBudget.Text : string.Empty);
                            fileItem["BudgetAllocated"] = drdbudget.SelectedItem.Text;

                            fileItem["Fee"] = txtFees.Text;
                            fileItem["Pending"] = "No";

                            fileItem.Fields["Requestor"].ReadOnlyField = false;
                            fileItem["Requestor"] = oWeb.CurrentUser.ID;
                            fileItem["EmpName"] = txtCurrentUser.Text;

                            string userType = _ws.GetUsrType();
                            fileItem["UserType"] = userType;
                            if (userType.Contains("Normal Requestor"))
                            {
                                fileItem["ReqStatus"] = "Pending with L1";
                                fileItem["Status"] = "Pending";
                            }
                            else
                            {
                                fileItem["ReqStatus"] = "Pending with PSHead";
                                fileItem["Status"] = "Pending";
                            }
                            //Level 4 :- Sector Head COE Head                        
                            if (ddlSite.SelectedValue.Equals(_ws.getID("Site", new KeyValuePair<string, string>("Title", "COE")).ToString()))
                            {
                                fileItem["TechCOEFlag"] = "Yes";
                            }
                            else
                            {
                                fileItem["TechCOEFlag"] = "No";
                            }
                            #endregion

                            #region----------- For Draft / Edit / Modify Request-------------

                            fileItem["DelFlag"] = "0";

                            if (draftFlag.Equals("No"))
                            {
                                fileItem["WFLevel"] = _ws.GetWFLevel();
                                fileItem["RStatus"] = "Open";
                                fileItem["Pending"] = "0";
                            }

                            if (draftFlag.Equals("Yes"))
                            {
                                fileItem["WFLevel"] = _ws.GetWFLevel();
                                fileItem["ReqStatus"] = "Draft";
                                fileItem["RStatus"] = "Draft";
                                fileItem["Status"] = "Draft";
                            }

                            if (Convert.ToString(ViewState["Status"]).Equals("Modify"))
                            {
                                if (userType.Contains("Normal Requestor"))
                                {
                                    fileItem["ReqStatus"] = "Resubmitted to L1";
                                    fileItem["Status"] = "Pending";
                                }
                                else
                                {
                                    fileItem["ReqStatus"] = "Resubmitted to PSHead";
                                    fileItem["Status"] = "Pending";
                                }
                                //fileItem["ReqStatus"] = "Resubmitted";
                                fileItem["RStatus"] = "Open";
                                fileItem["WFLevel"] = (ViewState["WFLevel"] != null ? ViewState["WFLevel"].ToString() : "");
                            }
                            fileItem["PLNCheck"] = "No";
                            fileItem["ReqDate"] = DateTime.Now.ToString("dd-MMM-yyyy");

                            #endregion

                            fileItem.Update();
                            saveFile(oWeb, requestId);

                            oWeb.AllowUnsafeUpdates = false;
                            _ws.LogError("Success Happy", "Request has been created successfully: " + requestId + "");

                            System.Text.StringBuilder sb = new System.Text.StringBuilder();
                            sb.Append(@"<script type='text/javascript'>");
                            sb.Append(@"alert('Action has been completed successfully.');");
                            sb.Append(@"window.location = '/Pages/Confrence_Workshop/Summary.aspx';");
                            sb.Append(@"</script>");
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", sb.ToString());
                        }

                        catch (Exception ex)
                        {
                            _ws.LogError("Error on Submit Button:", ex.Message + "-------" + ex.StackTrace);
                        }

                    }
                }

            }

        }

        #region ------------Event Handlers--------------

        public bool Check(string A1, string A2)
        {
            if (A1.Equals(A2, StringComparison.OrdinalIgnoreCase))
                return true;
            else
                return false;
        }

        protected void ddlSegment_SelectedIndexChanged(object sender, EventArgs e)
        {
            string segmentId = ddlSegment.SelectedItem.Text.Trim();
            PopulateSector(segmentId);
        }

        protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sectorName = ddlSector.SelectedItem.Text.Trim();
            PopulateGroup(sectorName);
        }

        protected void ddlSeekingforapproval_SelectedIndexChanged(object sender, EventArgs e)
        {
            string seekApprovalName = ddlSeekingforapproval.SelectedItem.Text.ToString();
            if (ddlSeekingforapproval.SelectedItem.Text.Contains("Training or Workshop"))
            {
                PopulatePrograms(seekApprovalName);
            }
            else if (ddlSeekingforapproval.SelectedItem.Text.Contains("Conference or Seminar"))
            {
                PopulatePrograms(seekApprovalName);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Summary.aspx", true);
        }

        protected void btnYes_Click(object sender, EventArgs e)
        {
            //_ws.DeleteItem("AttendanceLibrary", int.Parse(ViewState["_itemID"].ToString()));
        }

        protected void ddlProgramTitle_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SPList lstCnW = SPContext.Current.Web.Lists.TryGetList("Conference & Workshop");
                SPQuery qry = new SPQuery();
                qry.Query = @"<Where>
                                <Eq>
                                    <FieldRef Name='NameSDate' />
                                    <Value Type='Text'>" + ddlProgramTitle.SelectedItem.Text.Trim() + @"</Value>
                                </Eq>
                            </Where>";
                SPListItemCollection lstItemCol = lstCnW.GetItems(qry);

                if (lstItemCol.Count > 0)
                {
                    lblProgramtitle1.Text = ddlProgramTitle.SelectedItem.Text;
                    lblOrgBy.Text = Convert.ToString(lstItemCol[0]["OrganizedBy"]);
                    lblProgDuration.Text = "(" + Convert.ToString(lstItemCol[0]["Duration"]) + ")";
                    progDuration = Convert.ToString(lstItemCol[0]["Duration"]);
                    lblSEDate.Text = Convert.ToDateTime(lstItemCol[0]["WStartDate"]).ToString("dd/MM/yyyy") + " - " + Convert.ToDateTime(lstItemCol[0]["WEndDate"]).ToString("dd/MM/yyyy");
                    ViewState["startDate"] = Convert.ToString(lstItemCol[0]["WStartDate"]);
                    lblLoc.Text = Convert.ToString(lstItemCol[0]["Location"]);
                    ViewState["Overseas"] = Convert.ToString(lstItemCol[0]["Overseas"]);
                    ViewState["WorkshopID"] = Convert.ToString(lstItemCol[0]["WorkshopID"]);
                }
            }
            catch (SPException ex)
            {
                _ws.LogError("Error on ddlProgramTitle_SelectedIndexChange", ex.Message);

            }
        }

        protected void btnSuccess_Click(object sender, EventArgs e)
        {
            Response.Redirect("Summary.aspx", false);
        }

        protected void drdbudget_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                if (drdbudget.SelectedItem.Text.Contains("Yes"))
                {
                    rowBudget.Visible = true;
                }
                else
                {
                    rowBudget.Visible = false;
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("DDL Error Request :-", drdbudget.Items.Count + "---" + ex.Message);
            }
        }

        protected void ddlSite_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlSegment.SelectedItem.Text == "--Select--" || ddlSector.SelectedItem.Text == "--Select--" || ddlBusiness.SelectedItem.Text == "--Select--")
                {
                    var validator = new CustomValidator();
                    validator.IsValid = false;
                    validator.ErrorMessage = "Please Select Segment,Sector and Group respectively.";
                    Page.Validators.Add(validator);
                }
                else
                {
                    GetApproverFlow();
                }
            }
            catch (Exception exp)
            {
                _ws.LogError("Error On fetching ApproverFlow :", exp.Message);
            }
        }

        protected void ddlProgramTitle_DataBound(object sender, EventArgs e)
        {
            ddlProgramTitle.Items.Insert(0, new ListItem("--Select--", "0"));
            lblProgramtitle1.Text = string.Empty;
            lblOrgBy.Text = string.Empty;
            lblProgDuration.Text = string.Empty;
            lblSEDate.Text = string.Empty;
            lblLoc.Text = string.Empty;
        }


        #endregion

        #region ----------Methods---------------

        private void PopulateSegmentDropdown(SPWeb oWeb)
        {
            _ws = new Workshop();
            try
            {
                DataTable dtSegment = _ws.PopulateSegmentDropdown(oWeb);

                if (dtSegment != null)
                {
                    ddlSegment.DataSource = dtSegment;
                    ddlSegment.DataTextField = dtSegment.Columns["Title"].ToString();
                    ddlSegment.DataValueField = dtSegment.Columns["ID"].ToString();
                    ddlSegment.DataBind();
                    ddlSegment.Items.Insert(0, "--Select--");
                }
                else
                {
                    DataTable Emptydt = new DataTable();
                    ddlSegment.DataSource = Emptydt;
                    ddlSegment.DataBind();
                    ddlSegment.Items.Insert(0, "--Select--");
                }

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate PopulateSegmentDropdown", ex.Message);
                throw ex;
            }
        }

        private void PopulateSector(string strSegment)
        {
            _ws = new Workshop();
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        DataTable dtSector = _ws.PopulateSectorDropdown(oWeb, strSegment);
                        if (dtSector != null)
                        {
                            ddlSector.DataSource = dtSector;
                            ddlSector.DataTextField = dtSector.Columns["Title"].ToString();
                            ddlSector.DataValueField = dtSector.Columns["ID"].ToString();
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");

                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSector.DataSource = Emptydt;
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");
                            // DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate sector", ex.Message); throw ex;
            }

        }

        private void PopulateGroup(string strSector)
        {
            _ws = new Workshop();
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        //SPList lstGroup = oWeb.Lists.TryGetList("Group");
                        //SPQuery qry = new SPQuery();
                        //qry.Query = @"<Where><Eq><FieldRef Name='Sector'/><Value Type='Lookup'>" + strSectorValue + @"</Value></Eq></Where>";
                        DataTable dtGroup = _ws.PopulateGroupDropdown(oWeb, strSector);// lstGroup.GetItems(qry).GetDataTable();
                        if (dtGroup != null)
                        {
                            ddlBusiness.DataSource = dtGroup;
                            ddlBusiness.DataTextField = dtGroup.Columns["Title"].ToString();
                            ddlBusiness.DataValueField = dtGroup.Columns["ID"].ToString();
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate Group", ex.Message);
            }
        }

        private void PopulateSiteDropdown()
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        using (SPSite oSite = new SPSite(siteURL))
                        {
                            using (SPWeb oWeb = oSite.OpenWeb())
                            {
                                SPList lstSite = oWeb.Lists.TryGetList("Site");
                                DataTable dtSite = lstSite.GetItems().GetDataTable();
                                if (dtSite != null)
                                {
                                    ddlSite.DataSource = dtSite;
                                    ddlSite.DataTextField = Convert.ToString(dtSite.Columns["Title"]);
                                    ddlSite.DataValueField = Convert.ToString(dtSite.Columns["ID"]);
                                    ddlSite.DataBind();
                                    ddlSite.Items.Insert(0, "--Select--");
                                }
                                else
                                {
                                    _ws.LogError("Error", "Can't PopulateSiteDropdown");
                                }
                            }

                        }
                    });
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate PopulateSiteDropdown" + ex.StackTrace, ex.Message);
            }
        }

        private void PopulatePrograms(string SeekingApproval)
        {
            try
            {
                //trPrg.Visible = true;
                string strToday = SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Now);
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstGroup = oWeb.Lists.TryGetList("Conference & Workshop");
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>                                          
                                             <And>
                                                 <Eq>
                                                    <FieldRef Name='Category' />
                                                    <Value Type='Choice'>" + SeekingApproval + @"</Value>
                                                 </Eq>
                                                 <Gt>
                                                    <FieldRef Name='WStartDate' />
                                                    <Value Type='DateTime' IncludeTimeValue='TRUE'>" + strToday + @"</Value>               
                                                 </Gt>
                                          </And>                                         
                                       </Where>";
                        DataTable dtPrograms = lstGroup.GetItems(qry).GetDataTable();

                        if (dtPrograms != null)
                        {
                            ddlProgramTitle.DataSource = dtPrograms;
                            ddlProgramTitle.DataTextField = dtPrograms.Columns["NameSDate"].ToString();
                            ddlProgramTitle.DataValueField = dtPrograms.Columns["ID"].ToString();

                            ddlProgramTitle.DataBind();
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlProgramTitle.DataSource = Emptydt;
                            ddlProgramTitle.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on PopulateProgram", ex.Message);
            }
        }

        public void GetApproverFlow()
        {
            try
            {
                lblSiteHead.Text = "";

                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        //------------------Getting MyManager details---------------
                        SPServiceContext serContext = SPServiceContext.GetContext(oSite);
                        UserProfileManager oUserProfileManager = new UserProfileManager(serContext);
                        UserProfile oUserProfile = oUserProfileManager.GetUserProfile(SPContext.Current.Web.CurrentUser.LoginName);
                        UserProfile mgr = oUserProfile.GetManager();
                        // SPUser xmgr = _ws.getMgr(SPContext.Current.Web.CurrentUser.LoginName);

                        //------------------Getting HOD details---------------
                        SPUser SiteFunHead;
                        // COE Function Head / Site CTS Head (Site = "COE") 
                        if (Check(ddlSite.SelectedValue, _ws.getID("Site", new KeyValuePair<string, string>("Title", "COE")).ToString()))
                        {
                            SiteFunHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                        }
                        else
                        {
                            SiteFunHead = _ws.getSiteSectorHead("SiteSectorHead", ddlSite.SelectedItem.ToString(), ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "SiteSectorHead");
                        }
                        // RnD Head or Not)
                        if (Check(ddlSegment.SelectedValue, _ws.getID("Segment", new KeyValuePair<string, string>("Title", "R&D")).ToString()))
                        {
                            SiteFunHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                        }

                        #region -------------OLD CODE NOT USED-----

                        //                        SPList lstSiteSectorHead = oWeb.Lists.TryGetList("SiteSectorHead");
                        //                        SPQuery qrySiteSectorHead = new SPQuery();
                        //                        qrySiteSectorHead.Query = @"<Where><And>
                        //                                                <And><Eq><FieldRef Name='Title' /><Value Type='Text'>" + ddlSite.SelectedItem.Text + @"</Value></Eq>
                        //                                                <Eq><FieldRef Name='Segment' /><Value Type='Text'>" + ddlSegment.SelectedItem.Text + @"</Value></Eq>
                        //                                                    </And><Eq><FieldRef Name='Sector' /><Value Type='Text'>" + ddlSector.SelectedItem.Text + @"</Value></Eq>
                        //                                                </And></Where>";
                        //                        DataTable dtSiteSectorHead = lstSiteSectorHead.GetItems(qrySiteSectorHead).GetDataTable();
                        //                        DataRow drSiteSectorHead = dtSiteSectorHead.Rows[0];
                        //                        SPUser SiteFunHead = SPContext.Current.Web.EnsureUser(Convert.ToString(drSiteSectorHead["SiteSectorHead"]));

                        #endregion

                        //---------------- Getting PS Head Details------------

                        SPList lstSector = oWeb.Lists.TryGetList("Sector");
                        SPQuery qrySector = new SPQuery();
                        qrySector.Query = @"<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + ddlSector.SelectedItem.Text + @"</Value></Eq></Where>";
                        DataTable dtSector = lstSector.GetItems(qrySector).GetDataTable();
                        DataRow drSector = dtSector.Rows[0];
                        SPUser PSHead = SPContext.Current.Web.EnsureUser(Convert.ToString(drSector["PSHead"]));

                        string userType = _ws.GetUsrType();

                        if (userType.Contains("Normal Requestor"))
                        {
                            lblSiteHead.Text = "Approval Flow :- Manager(" + mgr.DisplayName.ToString() + ")----> HOD(" + SiteFunHead.Name.ToString() + ") -----> PS Head(" + PSHead.Name.ToString() + ")---> (Subsequent Approval Based on Workshop Location...)";
                        }
                        else
                        {
                            lblSiteHead.Text = "Approval Flow :- PS Head(" + PSHead.Name.ToString() + ")---> (Subsequent Approval Based on Workshop Location...)";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lblSiteHead.Text = "Approver not available";
                _ws.LogError("Error on GetApproverFlow()", ex.Message);

            }

        }

        public int GetWFLevelNew()
        {
            int funCOEHead = getCount("Group", "FunctionCOEHead");
            int siteCTSHead = getCount("SiteSectorHead", "SiteSectorHead");
            int retValue = 0;
            retValue = (funCOEHead > 0 ? 11 : (siteCTSHead > 0 ? 21 : 0));
            return retValue;
        }

        public int getCount(string listName, string colName)
        {
            SPList lst = SPContext.Current.Web.Lists.TryGetList(listName);
            SPQuery caml = new SPQuery();
            caml.Query = @"   <Where> 
                                  <Eq> 
                                     <FieldRef Name= " + colName + @" /> 
                                     <Value Type='Integer'> 
                                        <UserID /> 
                                     </Value> 
                                  </Eq> 
                               </Where>";
            SPListItemCollection items = lst.GetItems(caml);

            int count = items.Count;
            return count;
        }

        private void populateSeekingApprovalFor()
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstGroup = oWeb.Lists.TryGetList("Conference & Workshop");
                        SPQuery qry = new SPQuery();
                        qry.ViewFields = @"<FieldRef Name='Category' />";
                        DataTable dt = lstGroup.GetItems(qry).GetDataTable();
                        if (dt != null)
                        {
                            DataView dtView = new DataView(dt);
                            DataTable dtDistinct = dtView.ToTable(true, "Category");
                            ddlSeekingforapproval.DataSource = dtDistinct;
                            ddlSeekingforapproval.DataTextField = dtDistinct.Columns["Category"].ToString();
                            //ddlSeekingforapproval.DataValueField = dtDistinct.Columns["ID"].ToString();
                            ddlSeekingforapproval.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate sector", ex.Message);
                throw ex;
            }

        }

        private void saveFile(SPWeb oWeb, string reqID)
        {
            SPList list = oWeb.Lists.TryGetList("WorkshopRequestsDocs");
            string newfile = string.Empty, fileName = string.Empty, _fileUrl = string.Empty;
            byte[] contentByteArray;
            SPFile file = null;
            if (fldFileUpload.HasFile)
            {
                contentByteArray = new byte[fldFileUpload.PostedFile.ContentLength];
                newfile = fldFileUpload.PostedFile.FileName;
                fileName = reqID + "_" + fldFileUpload.FileName;

                fldFileUpload.PostedFile.InputStream.Read(contentByteArray, 0, fldFileUpload.PostedFile.ContentLength - 1);
                file = list.RootFolder.Files.Add(fileName, contentByteArray, true);
                file.Update();

                SPListItem fileItem = file.Item;
                fileItem["RequestID"] = reqID;
                fileItem.Fields["Requestor"].ReadOnlyField = false;
                fileItem["Requestor"] = oWeb.CurrentUser.ID;
                fileItem.Update();
                _ws.LogError("File uploaded Successfully", "File uploaded Successfully of RequestID :" + reqID + "");
            }
            else
            {
                _ws.LogError("No File uploaded by the User", "No file uploaded by User");
            }
        }

        public string fileAttached(SPWeb oWeb, string reqID)
        {
            string fileName = string.Empty;
            try
            {
                SPDocumentLibrary oLib = oWeb.Lists.TryGetList("WorkshopRequestsDocs") as SPDocumentLibrary;
                SPQuery qry = new SPQuery();
                qry.Query = @"<Where>
                                  <Eq>
                                     <FieldRef Name='RequestID' />
                                     <Value Type='Text'>" + reqID + @"</Value>
                                  </Eq>
                               </Where> <OrderBy><FieldRef Name='Modified' Ascending='FALSE' /></OrderBy>";
                SPListItemCollection oitems = oLib.GetItems(qry);
                DataTable dtLib = oitems.GetDataTable();
                if (dtLib != null)
                {
                    DataRow drLib = dtLib.Rows[0];
                    if (!string.IsNullOrEmpty(Convert.ToString(drLib["FileLeafRef"])))
                    {
                        fileName = Convert.ToString(drLib["FileLeafRef"]);
                    }
                    else
                        fileName = string.Empty;
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on File Attached" + ex.Message, "------------" + ex.StackTrace);
            }
            return fileName;

        }

        #endregion

        private void PreviousSelectionMatrix()
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        try
                        {
                            SPList lstWorkshopRequests = oWeb.Lists.TryGetList("WorkshopRequests");
                            SPQuery qry = new SPQuery();
                            qry.Query = @"<Where>
                                            <Eq>
                                                <FieldRef Name='Requestor' />
                                                <Value Type='Integer'>
                                                    <UserID />
                                                </Value>
                                            </Eq>
                                        </Where>
                                        <OrderBy>
                                            <FieldRef Name='ID' Ascending='FALSE' />                                                       
                                        </OrderBy>";
                            qry.RowLimit = 1;
                            SPListItemCollection oItems = lstWorkshopRequests.GetItems(qry);
                            if (oItems != null && oItems.Count > 0)
                            {
                                //Pouplating Segment
                                PopulateSegmentDropdown(oWeb);
                                ddlSegment.Items.FindByText(Convert.ToString(oItems[0]["Segment"])).Selected = true;

                                //Populating  Sector                            
                                PopulateSector(Convert.ToString(oItems[0]["Segment"]));
                                ddlSector.Items.FindByText(Convert.ToString(oItems[0]["Sector"])).Selected = true;

                                //Populating Group
                                PopulateGroup(Convert.ToString(oItems[0]["Sector"]));
                                ddlBusiness.Items.FindByText(Convert.ToString(oItems[0]["Business"])).Selected = true;
                            }
                            else
                            {
                                PopulateSegmentDropdown(oWeb);
                                PopulateSiteDropdown();
                            }                                                             
                            
                        }
                        catch (Exception ex)
                        {                           
                            PopulateSegmentDropdown(oWeb);
                            PopulateSiteDropdown();
                            _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Checking Entry Point - Work arround succeed!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Checking Entry Point");

            }
        }

        public void PopulatePageControlsWithExisting(string _editID)
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstWorkshopRequests = oWeb.Lists.TryGetList("WorkshopRequests");
                        SPListItem lstItem = lstWorkshopRequests.GetItemById(Convert.ToInt32(_editID));

                        txtRequestID.Text = lstItem["RequestID"].ToString();
                        ViewState["ReqID"] = txtRequestID.Text;//Needs for file attachment,plz dont delete

                        //Pouplating Segment
                        PopulateSegmentDropdown(oWeb);
                        ddlSegment.Items.FindByText(Convert.ToString(lstItem["Segment"])).Selected = true;

                        //Populating  Sector
                        PopulateSector(Convert.ToString(lstItem["Segment"]));
                        ddlSector.Items.FindByText(Convert.ToString(lstItem["Sector"])).Selected = true;

                        //Populating Group
                        PopulateGroup(Convert.ToString(lstItem["Sector"]));
                        ddlBusiness.Items.FindByText(Convert.ToString(lstItem["Business"])).Selected = true;

                        //Populating Site
                        PopulateSiteDropdown();
                        ddlSite.Items.FindByText(Convert.ToString(lstItem["Site"])).Selected = true;

                        txtEmpCode.Text = Convert.ToString(lstItem["EmpCode"]);
                        txtCurrentUser.Text = Convert.ToString(lstItem["EmpName"]);

                        //Populating Seeking Approval
                        populateSeekingApprovalFor();
                        ddlSeekingforapproval.Items.FindByText(Convert.ToString(lstItem["ApprovalFor"])).Selected = true;

                        //Populating Program Title
                        PopulatePrograms(Convert.ToString(lstItem["ApprovalFor"]));
                        bool matchFlag = false;
                        string strNameSDate = lstItem["WorkshopRefID_x003a_NameSDate"].ToString().Split('#')[1];
                        if (ddlProgramTitle.Items.Count > 1)
                        {
                            foreach (ListItem item in ddlProgramTitle.Items)
                            {
                                if (strNameSDate == item.Text)
                                {
                                    matchFlag = true;
                                }
                            }

                        }
                        if (matchFlag)
                        {
                            ddlProgramTitle.Items.FindByText(Convert.ToString(strNameSDate)).Selected = true;
                        }
                        else
                        {
                            string msg = "Selected " + Convert.ToString(lstItem["ApprovalFor"]) + " is already past the start date. Request cannot be modified.";
                            string alert_redirect_Script = string.Format(@"<script type=""text/javascript"">
                                       alert('{0}');
                                        window.location.href = '/Pages/Confrence_Workshop/Summary.aspx';
                                       </script>", msg);
                            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", alert_redirect_Script, false);
                        }

                        lblProgramtitle1.Text = Convert.ToString(lstItem["WorkshopRefID_x003a_NameSDate"]).Split('#')[1];
                        lblOrgBy.Text = lstItem["WorkshopRefID_x003a_Organized_x0"].ToString().Split('#')[1];
                        lblLoc.Text = lstItem["WorkshopRefID_x003a_Location"].ToString().Split('#')[1];
                        lblProgDuration.Text = " (" + lstItem["WorkshopRefID_x003a_Duration"].ToString().Split('#')[1] + ")";
                        ViewState["startDate"] = lstItem["WorkshopRefID_x003a_WStartDate"].ToString().Split('#')[1];
                        lblSEDate.Text = Convert.ToDateTime(lstItem["WorkshopRefID_x003a_WStartDate"].ToString().Split('#')[1]).ToString("dd/MM/yyyy") + "-" + Convert.ToDateTime(lstItem["WorkshopRefID_x003a_WEndDate"].ToString().Split('#')[1]).ToString("dd/MM/yyyy");

                        txtFees.Text = lstItem["Fee"].ToString();
                        drdbudget.Items.FindByText(Convert.ToString(lstItem["BudgetAllocated"])).Selected = true;
                        if (Convert.ToString(lstItem["BudgetAllocated"]).Contains("Yes"))
                        {
                            rowBudget.Visible = true;
                            txtBudget.Text = Convert.ToString(lstItem["BudgetDesc"]);
                        }
                        else
                        {
                            rowBudget.Visible = false;
                            txtBudget.Text = string.Empty;
                            // txtBudget.Text = Convert.ToString(lstItem["BudgetDesc"]);
                        }

                        txtValue.Text = Convert.ToString(lstItem["ValueField"]);
                        txtreason.Text = Convert.ToString(lstItem["KeyReason"]);
                        lnkAttachFile.Text = fileAttached(oWeb, txtRequestID.Text);// lstItem["FileLeafRef"].ToString();
                        //added for edit----
                        ViewState["Status"] = Convert.ToString(lstItem["Status"]);
                        ViewState["WFLevel"] = Convert.ToString(lstItem["WFLevel"]);

                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on PopulatePageControlsWithExisting()", ex.Message);
            }
        }

        protected void lnkAttachFile_Click(object sender, EventArgs e)
        {

            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        string qryRequestID = ViewState["ReqID"].ToString();
                        SPDocumentLibrary lstWorkshopRequestsDocs = oWeb.Lists.TryGetList("WorkshopRequestsDocs") as SPDocumentLibrary;
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                      <Eq>
                                         <FieldRef Name='RequestID' />
                                         <Value Type='Text'>" + qryRequestID + @"</Value>
                                      </Eq>
                                   </Where><OrderBy><FieldRef Name='Modified' Ascending='FALSE' /></OrderBy>";
                        SPListItemCollection oitems = lstWorkshopRequestsDocs.GetItems(qry);
                        foreach (SPListItem item in oitems)
                        {
                            SPFile file = item.File;
                            string path = file.Url.ToString();

                            if (file != null)
                            {
                                byte[] bytes = file.OpenBinary();
                                byte[] fileData = bytes;

                                Page.Response.Clear();
                                Page.Response.Buffer = true;
                                Page.Response.ClearHeaders();

                                string fileName = item.File.Name;
                                Page.Response.ContentType = FileUtility.GetMIMEType(fileName);

                                String userAgent = Page.Request.Headers.Get("User-Agent");
                                if (userAgent.Contains("MSIE 7.0"))
                                {
                                    fileName = fileName.Replace(" ", "%20");
                                }
                                Page.Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

                                Page.Response.OutputStream.Write(fileData, 0, fileData.Length);
                                Page.Response.Flush();
                                Page.Response.End();

                                break;
                            }

                        }

                    }


                }


            }
            catch (Exception ex)
            {
                _ws.LogError("Error on attachment file" + ex.Message, ex.StackTrace);

            }
        }

    }

}

