﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_COEFunctionHeadDetailedView
{
    public partial class CnW_COEFunctionHeadDetailedViewUserControl : UserControl
    {
        #region ---------Global Variables------------
        Workshop _ws;
        string confID;
        string _editItemID;
        string _level;
        DataTable dtReq = null;
        Dictionary<string, string> filters;
        string _siteURL = SPContext.Current.Web.Url;
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();
            if(!Page.IsPostBack)
            {
                BindGridView();
            }
        }

        private void BindGridView()
        {
            try
            {
                using (SPSite oSite = new SPSite(_siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lst = SPContext.Current.Web.Lists.TryGetList("WorkshopRequests");
                        SPQuery caml = new SPQuery();
                        caml.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='RStatus' />
                                             <Value Type='Text'>Completed</Value>
                                          </Eq>
                                    </Where>";
                        dtReq = lst.GetItems(caml).GetDataTable();
                        if (dtReq != null)
                        {
                            DataView dv = new DataView(dtReq);
                            dv.Sort = "Site";
                            ChGrid.DataSource = dv.ToTable();
                            ChGrid.DataBind();
                        }
                        else
                        {
                            _ws.LogError("Error on COEFunctionHeadDetailed View Page", "No Items found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on BindData()", ex.Message);
            }

        }

        protected void ChGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    DataRow dr = ((DataRowView)e.Row.DataItem).Row;
                    LinkButton lnkID = e.Row.FindControl("lnkID") as LinkButton;
                    Label lblOutput = e.Row.FindControl("lblOutput") as Label;
                    //LinkButton lnkAttachedFile = e.Row.FindControl("lnkAttachedFile") as LinkButton;
                    Repeater rpt = e.Row.FindControl("rptFileLinks") as Repeater;
                    lblOutput.Text = string.Empty;
                    lnkID.Text = dr["RequestID"].ToString();
                    using (SPSite oSite = new SPSite(_siteURL))
                    {
                        using (SPWeb oWeb = oSite.OpenWeb())
                        {
                            SPList lst = SPContext.Current.Web.Lists.TryGetList("WorkshopDocs");
                            SPQuery caml = new SPQuery();
                            caml.Query = @"   <Where>
                                                  <Eq>
                                                     <FieldRef Name='RequestID' />
                                                     <Value Type='Text'>" + lnkID.Text.ToString() + @"</Value>
                                                  </Eq>
                                               </Where>";
                            caml.ViewFields = "<FieldRef Name='FileLeafRef' />";
                            DataTable dt = lst.GetItems(caml).GetDataTable();
                            if (dt != null)
                            {
                                lblOutput.Text = "Yes";
                                rpt.DataSource = dt;
                                rpt.DataBind();
                            }
                            else
                            {
                                lblOutput.Text = "No";
                            }
                        }
                    }

                }
            }
            catch(Exception ex)
            {
                _ws.LogError("Error on ChGrid_RowDataBound()", ex.Message);
            }
        }

        protected void rptFileLinks_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
             if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) {

                 DataRowView usrCurrent = e.Item.DataItem as DataRowView;
                 ((LinkButton)e.Item.FindControl("lnkAttachedFile")).Text = usrCurrent["FileLeafRef"].ToString();
             }
        }
        protected void ChGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.Trim().ToUpper())
            {
                case "VIEW":
                    Response.Redirect("ViewRequest.aspx?ViewID=" + e.CommandArgument.ToString(), true);
                    break;
            }
        }

        protected void ChGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ChGrid.PageIndex = e.NewPageIndex;
            BindGridView();
        }

        protected void rptFileLinks_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int docid = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "Download")
            {
                try
                {
                    using (SPSite oSite = new SPSite(_siteURL))
                    {
                        using (SPWeb oWeb = oSite.OpenWeb())
                        {
                            
                            SPDocumentLibrary lstWorkshopRequestsDocs = oWeb.Lists.TryGetList("WorkshopDocs") as SPDocumentLibrary;
                            SPListItem item = lstWorkshopRequestsDocs.GetItemById(docid);
                            SPFile file = item.File;
                                string path = file.Url.ToString();

                                if (file != null)
                                {
                                    byte[] bytes = file.OpenBinary();
                                    byte[] fileData = bytes;

                                    Page.Response.Clear();
                                    Page.Response.Buffer = true;
                                    Page.Response.ClearHeaders();

                                    string fileName = item.File.Name;
                                    Page.Response.ContentType =FileUtility.GetMIMEType(fileName);

                                    String userAgent = Page.Request.Headers.Get("User-Agent");
                                    if (userAgent.Contains("MSIE 7.0"))
                                    {
                                        fileName = fileName.Replace(" ", "%20");
                                    }
                                    Page.Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

                                    Page.Response.OutputStream.Write(fileData, 0, fileData.Length);
                                    Page.Response.Flush();
                                    Page.Response.End();

                            }
                        }
                    }
                }
                catch (Exception ex)
                {

                    throw;
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            this.Page.Response.Redirect("/Pages/Confrence_Workshop/COEFHeadViewTripReport.aspx");
        }

        public static String GetMIMEType(String filepath)
        {
            System.Security.Permissions.RegistryPermission regPerm =
                new System.Security.Permissions.RegistryPermission(System.Security.Permissions.RegistryPermissionAccess.Read, "\\HKEY_CLASSES_ROOT");
            Microsoft.Win32.RegistryKey classesRoot = Microsoft.Win32.Registry.ClassesRoot;
            System.IO.FileInfo fi = new System.IO.FileInfo(filepath);

            string dotExt = fi.Extension.ToLower();
            Microsoft.Win32.RegistryKey typeKey = classesRoot.OpenSubKey("MIME\\Database\\Content Type");
            foreach (string keyname in typeKey.GetSubKeyNames())
            {
                Microsoft.Win32.RegistryKey curKey = classesRoot.OpenSubKey("MIME\\Database\\Content Type\\" + keyname);

                if (curKey.GetValue("Extension") != null && curKey.GetValue("Extension").ToString().ToLower() == dotExt)
                {
                    return keyname;
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".docx")
                {
                    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".xlsx")
                {
                    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".zip")
                {
                    return "application/octet-stream";
                }

            }
            return string.Empty;
        }
    }
}
