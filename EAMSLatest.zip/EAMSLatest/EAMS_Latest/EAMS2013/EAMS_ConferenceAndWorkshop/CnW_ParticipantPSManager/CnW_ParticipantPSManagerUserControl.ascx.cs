﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_ParticipantPSManager
{
    public partial class CnW_ParticipantPSManagerUserControl : UserControl
    {
        Workshop _ws;
        string confID;
        string _editItemID;       
        DataTable dtReq = null;
        Dictionary<string, string> filters;

        string _siteURL = SPContext.Current.Web.Url;

        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();
            if (Request.QueryString["WorkshopID"] != null)
            {
                _editItemID = Request.QueryString["WorkshopID"].ToString();
                
            }
            if (!Page.IsPostBack && _editItemID != null)
            {
                readItems(_editItemID);
                BindData_PSManagerFilter();
            }
        }

        protected void readItems(string _ItemID)
        {
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList olist = oWeb.Lists.TryGetList("Conference & Workshop"); 
                        SPQuery oQry = new SPQuery();
                        oQry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='WorkshopID' />
                                             <Value Type='Text'>" + _ItemID + @"</Value>
                                          </Eq>
                                       </Where>";
                        SPListItemCollection oitems = olist.GetItems(oQry);
                        if (oitems.Count > 0)
                        {
                            DataTable dtAtt = new DataTable();
                            dtAtt = oitems.GetDataTable();
                            lblconfID.Text = dtAtt.Rows[0]["WorkshopID"].ToString();
                            lblConfName.Text = dtAtt.Rows[0]["EventName"].ToString();
                            lblDuration.Text = dtAtt.Rows[0]["Duration"].ToString();
                            lblDate.Text = Convert.ToDateTime(dtAtt.Rows[0]["WStartDate"]).ToString("dd/MM/yyyy");
                            lblLocation.Text = dtAtt.Rows[0]["Location"].ToString();
                            
                        }
                        else
                        {
                            _ws.LogError("Error on ReadItem(ApprovePSHead)","No Items found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on ReadItem(ApprovePSHead)", ex.Message);
            }

        }

        protected void ChGrid_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.Trim().ToUpper())
            {
                case "VIEW":
                    Response.Redirect("ViewRequest.aspx?ViewID=" + e.CommandArgument.ToString(), true);
                    break;

                case "DELETE":
                    _ws.DeleteItem("WorkshopRequests", int.Parse(e.CommandArgument.ToString()));
                    BindData_PSManagerFilter();
                    break;
            }
        }

        protected void ChGrid_OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            // int ID = (int)ChGrid.DataKeys[e.RowIndex].Value;
            // _ws.DeleteItem("AttendanceLibrary", int.Parse(ID.ToString()));
            // BindData();
        }

        public void BindData_PSManagerFilter()
        {
            try
            {
                using (SPSite oSite = new SPSite(_siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lst = SPContext.Current.Web.Lists.TryGetList("WorkshopRequests");
                        SPQuery caml = new SPQuery();
                        caml.Query = @"<Where>
                                          <And>
                                             <Eq>
                                                <FieldRef Name='WorkshopRefID_x003a_WorkshopID' />
                                                <Value Type='Lookup'>" + lblconfID.Text.Trim() + @"</Value>
                                             </Eq>
                                             <Eq>
                                                <FieldRef Name='DelFlag' />
                                                <Value Type='Text'>0</Value>
                                             </Eq>
                                          </And>
                                       </Where>";
                        SPListItemCollection oItms=lst.GetItems(caml);
                        dtReq = oItms.GetDataTable();
                        if (dtReq != null)
                        {
                            DataView dv = new DataView(dtReq);
                            dv.Sort = "Site";
                            ChGrid.DataSource = dv.ToTable();
                            ChGrid.DataBind();
                            txtComment.Text = string.Empty;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on BindData_PSManagerFilter()", ex.Message);
            }
        }

        protected void ChGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ChGrid.PageIndex = e.NewPageIndex;
            BindData_PSManagerFilter();
        }

        protected void ChGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;

                LinkButton lnkView = e.Row.FindControl("lnkID") as LinkButton;
                lnkView.Text = dr["RequestID"].ToString();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            foreach (GridViewRow row in ChGrid.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chlApprove = row.FindControl("chkApprove") as CheckBox;
                    LinkButton lnkConfID = row.FindControl("lnkID") as LinkButton;
                    Label lblOverseas = row.FindControl("lblOverseas") as Label;
                    // int _wfLevel = int.Parse(lblWFLevel.Text);
                    if (chlApprove.Checked == true)
                    {
                        string ID = lnkConfID.CommandArgument;
                        _ws.UpdatePLNStatus(itemID: ID, comment: txtComment.Text, reqStatus: "Approved by PSHead", overseas: lblOverseas.Text);
                    }
                }
            }
            BindData_PSManagerFilter();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            
        }

        protected void btnAddParticipant_Click(object sender, EventArgs e)
        {
            this.Page.Response.Redirect("/Pages/Confrence_Workshop/OfflineRequest.aspx?WorkshopID="+_editItemID);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
           this.Page.Response.Redirect("/Pages/Confrence_Workshop/PSMView.aspx");
        }
    }
}
