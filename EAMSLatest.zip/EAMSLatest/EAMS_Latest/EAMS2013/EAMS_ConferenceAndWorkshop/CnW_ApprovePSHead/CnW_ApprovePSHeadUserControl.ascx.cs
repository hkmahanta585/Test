﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_ApprovePSHead
{
    public partial class CnW_ApprovePSHeadUserControl : UserControl
    {
        #region ---------Global Variables--------
        Workshop _ws;
        string confID;
        string _editItemID;
        string _level;
        DataTable dtReq = null;
        Dictionary<string, string> filters;
        string _SiteUrl = SPContext.Current.Web.Url;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();
            if (Request.QueryString["WorkshopID"] != null && Request.QueryString["Level"] == "PLAN")
            {
                _editItemID = Request.QueryString["WorkshopID"].ToString();
                _level = Request.QueryString["Level"].ToString();
            }
            else
            {
                _ws.LogError("Error on Passing avalid Level", "Level should be PLAN");
            }
            if (!Page.IsPostBack && _editItemID != null)
            {
                readItems(_editItemID);
                BindData_PSHeadFilter();
            }
        }

        protected void ChGrid_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            string newWindowUrl = string.Empty;
            string javaScript = string.Empty;
            switch (e.CommandName.Trim().ToUpper())
            {
                case "VIEW":
                    Response.Redirect("ViewRequest.aspx?ViewID=" + e.CommandArgument.ToString(), true);
                    break;

                case "DELETE":
                    //LinkButton btnDelete = e.Row.FindControl("btnDelete") as LinkButton;
                    LinkButton btnDelete = (LinkButton)e.CommandSource;
                    GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                    LinkButton lnkConfID = row.FindControl("lnkID") as LinkButton;

                    string _itemID = btnDelete.CommandArgument;
                    _ws.DeleteItem("WorkshopRequests", int.Parse(_itemID.ToString()));
                    _ws.AddApproverFeedBack("PlanNSFeedback", lnkConfID.Text, "Rejected by PSHead", txtComment.Text);//added by hkm
                    BindData_PSHeadFilter();
                    break;
            }
        }

        protected void ChGrid_OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            // int ID = (int)ChGrid.DataKeys[e.RowIndex].Value;
            //_ws.DeleteItem("WorkshopRequests", int.Parse(ID.ToString()));
            //BindData_PSHeadFilter();
        }

        public void BindData_PSHeadFilter()
        {
            try
            {
                using (SPSite oSite = new SPSite(_SiteUrl))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        string strLoggedinUser = oWeb.CurrentUser.Name;
                        SPList lst = oWeb.Lists.TryGetList("WorkshopRequests");
                        SPQuery oQuery = new SPQuery();
                        oQuery.Query = @"<Where>
                                    <And>
                                        <And>
                                              <And>
                                                 <Or>
                                                    <Or>
                                                       <Eq>
                                                          <FieldRef Name='ReqStatus' />
                                                          <Value Type='Text'>Pending with PSHead</Value>
                                                       </Eq>
                                                       <Eq>
                                                          <FieldRef Name='ReqStatus' />
                                                          <Value Type='Text'>Approved by HOD</Value>
                                                       </Eq>
                                                    </Or>
                                                    <Eq>
                                                          <FieldRef Name='ReqStatus' />
                                                          <Value Type='Text'>Resubmitted to PSHead</Value>
                                                     </Eq>
                                                 </Or>
                                                 <Eq>
                                                    <FieldRef Name='DelFlag' />
                                                    <Value Type='Text'>0</Value>
                                                 </Eq>
                                              </And>
                                              <Eq>
                                                 <FieldRef Name='RStatus' />
                                                 <Value Type='Text'>Open</Value>
                                              </Eq>
                                           </And>                                         
                                            <Eq>
                                                <FieldRef Name='WorkshopRefID_x003a_WorkshopID' />
                                                <Value Type='Lookup'>" + _editItemID + @"</Value>
                                           </Eq>
                                        </And>
                                </Where>";
                        SPListItemCollection listItems = lst.GetItems(oQuery);
                        DataTable dtPSHeadFilter = new DataTable();
                        dtPSHeadFilter = listItems.GetDataTable();
                        DataTable dtFilteredResult = new DataTable();



                        if (dtPSHeadFilter != null)
                        {
                            DataRow[] dtSelectedRows = dtPSHeadFilter.Select("PlanningHead = '" + strLoggedinUser + "'");
                            if (dtSelectedRows.Length > 0)
                            {
                                dtFilteredResult = dtSelectedRows.CopyToDataTable();

                            }
                        }
                        if (dtFilteredResult != null)
                        {
                            DataView dv = new DataView(dtFilteredResult);
                            dv.Sort = "Site";
                            dv.Sort = "ReqDate";
                            ChGrid.DataSource = dv.ToTable();
                            ChGrid.DataBind();
                            txtComment.Text = string.Empty;
                        }
                        else
                        {
                            _ws.LogError("Error on PSHead", "No Items found for Request ID :" + _editItemID);
                            ChGrid.DataSource = null;
                            ChGrid.DataBind();
                        }

                    }
                }
            }
            catch (Exception exp)
            {
                _ws.LogError("Error on PSHEAD BindData()", exp.Message);
            }
        }

        protected void ChGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ChGrid.PageIndex = e.NewPageIndex;
            BindData_PSHeadFilter();
        }

        protected void ChGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;

                LinkButton lnkView = e.Row.FindControl("lnkID") as LinkButton;
                lnkView.Text = dr["RequestID"].ToString();

                CheckBox CCheck = e.Row.FindControl("chkApprove") as CheckBox;
                Label lblChecked = e.Row.FindControl("lblChecked") as Label;
                LinkButton btnDelete = e.Row.FindControl("btnDelete") as LinkButton;

                if (!string.IsNullOrEmpty(dr["PLNCheck"].ToString()))
                {
                    if (dr["PLNCheck"].ToString().Equals("Approved", StringComparison.OrdinalIgnoreCase))
                    {
                        lblChecked.Visible = true;
                        //CCheck.Checked = true;
                        //CCheck.Enabled = false;
                        CCheck.Visible = false;
                        btnDelete.Enabled = false;
                    }
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (GridViewRow row in ChGrid.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chlApprove = row.FindControl("chkApprove") as CheckBox;
                        LinkButton lnkConfID = row.FindControl("lnkID") as LinkButton;
                        Label lblOverseas = row.FindControl("lblOverseas") as Label;
                        string reqStatus = string.Empty;
                        string strReqID = string.Empty;

                        if (chlApprove.Checked == true)
                        {
                            string ID = lnkConfID.CommandArgument;

                            using (SPSite oSite = new SPSite(_SiteUrl))
                            {
                                using (SPWeb oWeb = oSite.OpenWeb())
                                {
                                    SPList list = oWeb.Lists.TryGetList("WorkshopRequests");
                                    SPListItem item = list.GetItemById(Convert.ToInt32(ID));

                                    strReqID = lnkConfID.Text;// Convert.ToString(item["RequestID"]);//added by hkm
                                    if (lblOverseas.Text.Contains("Yes"))
                                    {

                                        if (item["Segment"].ToString().Contains("R&D"))
                                        {
                                            reqStatus = "Pending with RND Head";
                                        }
                                        else if (item["Site"].ToString().Contains("COE") && item["Sector"].ToString().Contains("Technology"))
                                        {
                                            reqStatus = "Pending with COE Head";
                                        }
                                        else
                                        {
                                            reqStatus = "Pending with Site President";
                                        }
                                    }
                                    _ws.UpdatePLNStatus(ID, txtComment.Text, reqStatus, lblOverseas.Text);
                                    _ws.AddApproverFeedBack("PlanNSFeedback", strReqID, "Approved by PSHead", txtComment.Text);//added by hkm
                                    txtComment.Text = "";
                                    //this.Page.Response.Redirect("/Pages/Confrence_Workshop/PSHView.aspx");
                                    //BindData_PSHeadFilter();
                                }
                            }
                        }
                        else
                        {
                            lblMassage.Text = "Please select any one request for approve";
                        }
                    }
                }
                this.Page.Response.Redirect("/Pages/Confrence_Workshop/PSHView.aspx");
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on PSHEAD Submit Button" + ex.Message, ex.StackTrace);
            }

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            this.Page.Response.Redirect("/Pages/Confrence_Workshop/PSHView.aspx");
        }

        protected void OkButton_Click(object sender, EventArgs e)
        {
            BindData_PSHeadFilter();

        }

        protected void readItems(string _ItemID)
        {
            try
            {
                using (SPSite oSite = new SPSite(_SiteUrl))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList olist = oWeb.Lists.TryGetList("Conference & Workshop");
                        SPQuery oQry = new SPQuery();
                        oQry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='WorkshopID' />
                                             <Value Type='Text'>" + _ItemID + @"</Value>
                                          </Eq>
                                       </Where>";
                        SPListItemCollection oitems = olist.GetItems(oQry);
                        if (oitems.Count > 0)
                        {
                            DataTable dtAtt = new DataTable();
                            dtAtt = oitems.GetDataTable();
                            lblconfID.Text = dtAtt.Rows[0]["WorkshopID"].ToString();
                            lblConfName.Text = dtAtt.Rows[0]["EventName"].ToString();
                            lblDate.Text = Convert.ToDateTime(dtAtt.Rows[0]["WStartDate"]).ToString("dd/MM/yyyy") + "-" + Convert.ToDateTime(dtAtt.Rows[0]["WEndDate"]).ToString("dd/MM/yyyy");
                            lblDuration.Text = dtAtt.Rows[0]["Duration"].ToString();
                            lblLocation.Text = dtAtt.Rows[0]["Location"].ToString();

                        }
                        else
                        {
                            _ws.LogError("Error on ReadItem(ApprovePSHead)", "No Items found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on ReadItem(ApprovePSHead)", ex.Message);
            }

        }

    }
}
