﻿using Microsoft.SharePoint;
using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_AdminDrive
{
    public partial class CnW_AdminDriveUserControl : UserControl
    {
        Workshop _ws;
        string siteURL = SPContext.Current.Web.Url;

        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();
            try
            {
                if (!this.Page.IsPostBack)
                {
                    PopulateSegmentDropdown();
                    PopulateSiteDropdown();
                }
            }
            catch (Exception ex)
            {                
                _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Page Load on Conference and Workshop");
            }
        }

        private void PopulateSiteDropdown()
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstSite = oWeb.Lists.TryGetList("Site");
                        //SPListItemCollection lstCollSegment = lstSegment.Items;
                        DataTable dtSite = lstSite.GetItems().GetDataTable();
                        ddlSite.DataSource = dtSite;
                        ddlSite.DataTextField = dtSite.Columns["Title"].ToString();
                        ddlSite.DataValueField = dtSite.Columns["ID"].ToString();
                        ddlSite.DataBind();
                        ddlSite.Items.Insert(0, "--Select--");
                    }
                }
            }
            catch (Exception ex)
            {

                _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Populate Site");
                throw ex;
            }
        }

        private void PopulateSegmentDropdown()
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstSegment = oWeb.Lists.TryGetList("Segment");                        
                        DataTable dtSegment = lstSegment.GetItems().GetDataTable();

                        if (dtSegment != null)
                        {
                            ddlSegment.DataSource = dtSegment;
                            ddlSegment.DataTextField = dtSegment.Columns["Title"].ToString();
                            ddlSegment.DataValueField = dtSegment.Columns["ID"].ToString();
                            ddlSegment.DataBind();
                            ddlSegment.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSegment.DataSource = Emptydt;
                            ddlSegment.DataBind();
                            ddlSegment.Items.Insert(0, "--Select--");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Populate Segment on CnW");
                throw ex;
            }
        }

        protected void ddlSegment_DataBound(object sender, EventArgs e)
        {
            //ddlSegment.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void ddlSector_DataBound(object sender, EventArgs e)
        {
            //ddlSector.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void ddlBusiness_DataBound(object sender, EventArgs e)
        {
            // ddlBusiness.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void ddlSite_DataBound(object sender, EventArgs e)
        {
            // ddlSite.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void ddlSegment_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSegmentValue = ddlSegment.SelectedItem.Text;
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstSector = oWeb.Lists.TryGetList("Sector");
                        //SPListItemCollection lstCollSegment = lstSegment.Items;
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='Segment' />
                                             <Value Type='Lookup'>" + strSegmentValue + @"</Value>
                                          </Eq>
                                       </Where>";
                        //qry.Query = "<Query><Where><Eq><FieldRef Name ='Segment' LookupId='true' /><Value Type ='Lookup'>"+strSegmentValue+"</Value></Eq></Where></Query>";
                        DataTable dtSector = lstSector.GetItems(qry).GetDataTable();
                        if (dtSector != null)
                        {
                            ddlSector.DataSource = dtSector;
                            ddlSector.DataTextField = dtSector.Columns["Title"].ToString();
                            ddlSector.DataValueField = dtSector.Columns["ID"].ToString();
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                            ddlRequest.DataSource = Emptydt;
                            ddlRequest.DataBind();
                            ddlRequest.Items.Insert(0, "--Select--");
                            lblComment.Text = string.Empty;
                            lblStatus.Text = string.Empty;
                            lblStatusDate.Text = string.Empty;
                            gvStatus.DataSource = Emptydt;
                            gvStatus.DataBind();
                            PopulateSiteDropdown();
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSector.DataSource = Emptydt;
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");


                            // DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                            ddlRequest.DataSource = Emptydt;
                            ddlRequest.DataBind();
                            ddlRequest.Items.Insert(0, "--Select--");
                            lblComment.Text = string.Empty;
                            lblStatus.Text = string.Empty;
                            lblStatusDate.Text = string.Empty;
                            gvStatus.DataSource = Emptydt;
                            gvStatus.DataBind();
                            PopulateSiteDropdown();
                        }
                        //GetApproverFlow();
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Segmwnt Index Change");

            }

            // ddlSector.Populateddl(ws: _ws, listName: "Sector", keyColumnName: "ID", valueColumnName: "Title", columnType: "Lookup", filter: new KeyValuePair<string, string>("Segment", ID));
        }

        protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSectorValue = ddlSector.SelectedItem.Text;
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstGroup = oWeb.Lists.TryGetList("Group");
                        //SPListItemCollection lstCollSegment = lstSegment.Items;
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='Sector' />
                                             <Value Type='Lookup'>" + strSectorValue + @"</Value>
                                          </Eq>
                                       </Where>";
                        //qry.Query = "<Query><Where><Eq><FieldRef Name ='Segment' LookupId='true' /><Value Type ='Lookup'>"+strSegmentValue+"</Value></Eq></Where></Query>";
                        DataTable dtGroup = lstGroup.GetItems(qry).GetDataTable();
                        if (dtGroup != null)
                        {
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = dtGroup;
                            ddlBusiness.DataTextField = dtGroup.Columns["Title"].ToString();
                            ddlBusiness.DataValueField = dtGroup.Columns["FunctionCOEHead"].ToString();
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                            ddlRequest.DataSource = Emptydt;
                            ddlRequest.DataBind();
                            ddlRequest.Items.Insert(0, "--Select--");
                            lblComment.Text = string.Empty;
                            lblStatus.Text = string.Empty;
                            lblStatusDate.Text = string.Empty;
                            gvStatus.DataSource = Emptydt;
                            gvStatus.DataBind();
                            PopulateSiteDropdown();
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                            ddlRequest.DataSource = Emptydt;
                            ddlRequest.DataBind();
                            ddlRequest.Items.Insert(0, "--Select--");
                            lblComment.Text = string.Empty;
                            lblStatus.Text = string.Empty;
                            lblStatusDate.Text = string.Empty;
                            gvStatus.DataSource = Emptydt;
                            gvStatus.DataBind();
                            PopulateSiteDropdown();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Sector Index Change");

            }
        }

        protected void ddlBusiness_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable Emptydt = new DataTable();
            ddlRequest.DataSource = Emptydt;
            ddlRequest.DataBind();
            ddlRequest.Items.Insert(0, "--Select--");
            lblComment.Text = string.Empty;
            lblStatus.Text = string.Empty;
            lblStatusDate.Text = string.Empty;
            gvStatus.DataSource = Emptydt;
            gvStatus.DataBind();
            PopulateSiteDropdown();
        }

        protected void ddlSite_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstExternalActivity = oWeb.Lists.TryGetList("WorkshopRequests");
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                       <And>
                                          <And>
                                             <And>
                                                <And>
                                                   <And>
                                                      <Eq>
                                                         <FieldRef Name='Segment' />
                                                         <Value Type='Text'>" + ddlSegment.SelectedItem.Text.ToString() + @"</Value>
                                                      </Eq>
                                                      <Eq>
                                                         <FieldRef Name='Sector' />
                                                         <Value Type='Text'>" + ddlSector.SelectedItem.Text.ToString() + @"</Value>
                                                      </Eq>
                                                   </And>
                                                   <Eq>
                                                      <FieldRef Name='Business' />
                                                      <Value Type='Text'>" + ddlBusiness.SelectedItem.Text.ToString() + @"</Value>
                                                   </Eq>
                                                </And>
                                                <Eq>
                                                   <FieldRef Name='Site' />
                                                   <Value Type='Text'>" + ddlSite.SelectedItem.Text.ToString() + @"</Value>
                                                </Eq>
                                             </And>
                                             <Eq>
                                                <FieldRef Name='RStatus' />
                                                <Value Type='Text'>Open</Value>
                                             </Eq>
                                          </And>
                                          <Eq>
                                             <FieldRef Name='DelFlag' />
                                             <Value Type='Text'>0</Value>
                                          </Eq>
                                       </And>
                                    </Where>";
                        DataTable dtExternalActivity = lstExternalActivity.GetItems(qry).GetDataTable();

                        if (dtExternalActivity != null)
                        {
                            ddlRequest.DataSource = dtExternalActivity;
                            ddlRequest.DataTextField = dtExternalActivity.Columns["RequestID"].ToString();
                            ddlRequest.DataValueField = dtExternalActivity.Columns["ID"].ToString();//Important
                            ddlRequest.DataBind();
                            ddlRequest.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlRequest.DataSource = Emptydt;
                            ddlRequest.DataBind();
                            ddlRequest.Items.Insert(0, "--Select--");
                            lblComment.Text = string.Empty;
                            lblStatus.Text = string.Empty;
                            lblStatusDate.Text = string.Empty;
                            gvStatus.DataSource = Emptydt;
                            gvStatus.DataBind();
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Site Index Change ");
            }
        }

        protected void ddlRequest_DataBound(object sender, EventArgs e)
        {

        }

        protected void ddlRequest_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlRequest.SelectedItem.Value != "0")
                {
                    using (SPSite oSite = new SPSite(siteURL))
                    {
                        using (SPWeb oWeb = oSite.OpenWeb())
                        {
                            SPList lstExternalActivity = oWeb.Lists.TryGetList("WorkshopRequests");
                            SPListItem lstItemExternalActivity = lstExternalActivity.GetItemById(Convert.ToInt32(ddlRequest.SelectedItem.Value.ToString()));

                            lblStatus.Text = lstItemExternalActivity["ReqStatus"].ToString();                            

                            if (!string.IsNullOrEmpty(Convert.ToString(lstItemExternalActivity["Comments"])))                            
                                lblComment.Text = lstItemExternalActivity["Comments"].ToString(); 
                            else
                                lblComment.Text = string.Empty;

                            if (!string.IsNullOrEmpty(Convert.ToString(lstItemExternalActivity["ReqDate"])))
                                lblStatusDate.Text =lstItemExternalActivity["ReqDate"].ToString();
                            else
                            {
                                lblStatusDate.Text = string.Empty;
                            }
                            ViewState["_Overseas"] = lstItemExternalActivity["WorkshopRefID_x003a_Overseas"].ToString();                           

                           // ViewState["_wflevel"] = int.Parse(lstItemExternalActivity["WFLevel"].ToString());
                            //ViewState["_coeFlag"] = lstItemExternalActivity["TECHCOEFlag"].ToString();                       

                            gvStatus.DataSource =_ws.GetRequestStatusDetails_Conf(Convert.ToString(ddlRequest.SelectedItem.Text));
                            gvStatus.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError(ex.Message + "\n\n" + ex.StackTrace, "Request Selected Index Change");

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string reqStatus = string.Empty;
                if (!(ddlRequest.SelectedItem.Text == string.Empty || ddlRequest.SelectedItem.Text == null || ddlRequest.SelectedItem.Text.Contains("--Select--")))
                {
                    using (SPSite oSite = new SPSite(siteURL))
                    {
                        using (SPWeb oWeb = oSite.OpenWeb())
                        {
                            if ((lblStatus.Text.Contains("Pending with L1")) || (lblStatus.Text.Contains("Pending by L1")) || (lblStatus.Text.Contains("Resubmitted to L1")))
                            {
                                #region ------------- AS a MANAGER APPROVAL-----------

                                if (ddlStatus.SelectedItem.Text.Contains("Approve"))
                                {
                                    //Update status in WorkshopRequests List (Main List)
                                    UpdateRequestStatus(oWeb, ddlStatus.SelectedItem.Text);
                                    //adding Item on ManagerFeedback list
                                    _ws.AddApproverFeedBack("MgrFeedback", ddlRequest.SelectedItem.Text, "Approved by L1", txtComment.Text);
                                }
                                else
                                {
                                    //Update status in WorkshopRequests List (Main List)
                                    UpdateRequestStatus(oWeb, ddlStatus.SelectedItem.Text);
                                    //adding Item on ManagerFeedback list
                                    _ws.AddApproverFeedBack("MgrFeedback", ddlRequest.SelectedItem.Text, "Rejected by L1", txtComment.Text);
                                }
                                #endregion
                            }
                            else if (lblStatus.Text.Contains("Approved by L1") || lblStatus.Text.Contains("Pending with HOD"))
                            {
                                #region -------------AS a HOD APPROVAL-------------

                                if (ddlStatus.SelectedItem.Text.Contains("Approve"))
                                {
                                    //Update status in WorkshopRequests List (Main List)
                                    UpdateRequestStatusHOD(oWeb, ddlStatus.SelectedItem.Text);
                                    //adding Item on HODFeedback list
                                    _ws.AddApproverFeedBack("HODFeedback", ddlRequest.SelectedItem.Text, "Approved by HOD", txtComment.Text);
                                }
                                else
                                {
                                    //Update status in WorkshopRequests List (Main List)
                                    UpdateRequestStatusHOD(oWeb, ddlStatus.SelectedItem.Text);
                                    //adding Item on HODFeedback list
                                    _ws.AddApproverFeedBack("HODFeedback", ddlRequest.SelectedItem.Text, "Rejected by HOD", txtComment.Text);
                                }
                                #endregion
                            }
                            else if ((lblStatus.Text.Contains("Approved by HOD")) || (lblStatus.Text.Contains("Pending with PSHead")) || (lblStatus.Text.Contains("Resubmitted to PSHead")))
                            {
                                #region ------------AS a PSHEAD APPROVAL-------------

                                string _Overseas = ViewState["_Overseas"].ToString().Split('#')[1];

                                if (ddlSegment.SelectedItem.Text.Contains("R&D"))
                                {
                                    reqStatus = "Pending with RND Head";
                                }
                                else if (ddlSite.SelectedItem.Text.Contains("COE") && ddlSector.SelectedItem.Text.Contains("Technology"))
                                {
                                    reqStatus = "Pending with COE Head";
                                }
                                else
                                {
                                    reqStatus = "Pending with Site President";
                                }
                                if (ddlStatus.SelectedItem.Text.Contains("Approve"))
                                {
                                    _ws.UpdatePLNStatus(ddlRequest.SelectedValue, txtComment.Text, reqStatus, _Overseas);
                                    _ws.AddApproverFeedBack("PlanNSFeedback", ddlRequest.SelectedItem.Text, "Approved by PSHead", txtComment.Text);
                                }
                                else
                                {
                                    _ws.DeleteItem("WorkshopRequests", Convert.ToInt32(ddlRequest.SelectedValue));
                                    // _ws.UpdatePLNStatusRejected(ddlRequest.SelectedValue, txtComment.Text, reqStatus, _Overseas);
                                    _ws.AddApproverFeedBack("PlanNSFeedback", ddlRequest.SelectedItem.Text, "Rejected by PSHead", txtComment.Text);
                                }

                                #endregion
                            }

                            else if(lblStatus.Text.Contains("Pending with RND Head"))
                            {
                                if (ddlStatus.SelectedItem.Text.Contains("Approve"))
                                {
                                    _ws.UpdateRnTStatus(itemID: ddlRequest.SelectedValue.ToString(), comment: txtComment.Text, rntCheck: "Approved", status: "Approved", reqStatus: "Approved by RnDHead ");
                                    _ws.AddApproverFeedBack("RNTFeedback", ddlRequest.SelectedItem.Text, "Approved by RnDHead", txtComment.Text);
                                }
                                else
                                {
                                    _ws.UpdateRnTStatusRejected(itemID: ddlRequest.SelectedValue.ToString(), comment: txtComment.Text, rntCheck: "Rejected", status: "Rejected", reqStatus: "Rejected by RnDHead ");
                                    _ws.AddApproverFeedBack("RNTFeedback", ddlRequest.SelectedItem.Text, "Rejected by RnDHead", txtComment.Text);
                                }
                            }

                            else if(lblStatus.Text.Contains("Pending with COE Head"))
                            {
                                string rStatus = "Open";
                                if (ddlStatus.SelectedItem.Text.Contains("Approve"))
                                {
                                    _ws.UpdateTechCOEStatus(itemID: ddlRequest.SelectedValue.ToString(), comment: txtComment.Text, techCheck: "Approved", status: "Approved", gmsFlag: "Approve", rStatus: rStatus, reqStatus: "Approved by COE Head");
                                    _ws.AddApproverFeedBack("COEFeedback", ddlRequest.SelectedItem.Text, "Approved by COEHead", txtComment.Text);
                                }
                                else
                                {
                                    _ws.UpdateTechCOEStatusRejected(itemID: ddlRequest.SelectedValue.ToString(), comment: txtComment.Text, techCheck: "Rejected", status: "Rejected", gmsFlag: "Reject", rStatus: "Closed", reqStatus: "Rejected by COE Head");
                                    _ws.AddApproverFeedBack("COEFeedback", ddlRequest.SelectedItem.Text, "Rejected by COEHead", txtComment.Text);
                                }
                            }
                            else if(lblStatus.Text.Contains("Pending with Site President"))
                            {
                                string rStatus = "Open";
                                if (ddlStatus.SelectedItem.Text.Contains("Approve"))
                                {
                                    _ws.UpdatePressidentStatus(itemID: ddlRequest.SelectedValue.ToString(), comment: txtComment.Text, techCheck: "Approved", status: "Approved", gmsFlag: "Approve", rStatus: rStatus, reqStatus: "Approved by Site President");
                                    _ws.AddApproverFeedBack("PRESSFeedback", ddlRequest.SelectedItem.Text, "Approved by Site President", txtComment.Text);
                                }
                                else
                                {
                                    _ws.UpdatePressidentStatusRejected(itemID: ddlRequest.SelectedValue.ToString(), comment: txtComment.Text, techCheck: "Rejected", status: "Rejected", gmsFlag: "Reject", rStatus: "Closed", reqStatus: "Rejected by Site President");
                                    _ws.AddApproverFeedBack("PRESSFeedback", ddlRequest.SelectedItem.Text, "Rejected by Site President", txtComment.Text);
                                }

                            }
                        }
                         Page.Response.Redirect("/Pages/Confrence_Workshop/Summary.aspx"); 
                    }
                }
               
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Submit button" + ex.Message, ex.StackTrace);
            }
        }        

        protected void btnClose_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect("/Pages/Confrence_Workshop/Summary.aspx");
        }

        private void UpdateRequestStatus(SPWeb oWeb,string status)
        {
            try
            {
                SPList list = oWeb.Lists.TryGetList("WorkshopRequests");
                SPListItem item = list.GetItemById(Convert.ToInt16(ddlRequest.SelectedItem.Value.ToString()));

                if (ddlStatus.SelectedItem.Text.Contains("Approve"))
                {
                    item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString()) + 1;
                    item["RStatus"] = "Open";
                    item["ReqStatus"] = "Approved by L1 ";
                }
                else if (ddlStatus.SelectedItem.Text.Contains("Rejected"))
                {
                    item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
                    item["RStatus"] = "Closed";
                    item["ReqStatus"] = "Rejected by L1";
                }
                item["Status"] = status;
                item["Comments"] = txtComment.Text;
                item["ApprDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
                item.Update();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        private void UpdateRequestStatusHOD(SPWeb oWeb, string status)
        {
            try
            {
                SPList list = oWeb.Lists.TryGetList("WorkshopRequests");
                SPListItem item = list.GetItemById(Convert.ToInt16(ddlRequest.SelectedItem.Value.ToString()));

                if (ddlStatus.SelectedItem.Text.Contains("Approve"))
                {
                    item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString()) + 1;
                    item["RStatus"] = "Open";
                    item["ReqStatus"] = "Approved by HOD ";
                }
                else if (ddlStatus.SelectedItem.Text.Contains("Rejected"))
                {
                    item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
                    item["RStatus"] = "Closed";
                    item["ReqStatus"] = "Rejected by HOD";
                }
                item["Status"] = status;
                item["Comments"] = txtComment.Text;
                item["ApprDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
                item.Update();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }


}
