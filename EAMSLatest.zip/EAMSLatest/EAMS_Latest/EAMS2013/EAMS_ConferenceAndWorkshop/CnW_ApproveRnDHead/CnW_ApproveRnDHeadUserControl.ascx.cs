﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_ApproveRnDHead
{
    public partial class CnW_ApproveRnDHeadUserControl : UserControl
    {
        #region ---------Global Variables------------
        EAMS_ConferenceAndWorkshop.Workshop _ws = new Workshop();
       // Workshop _ws;
        string confID;
        string _editItemID;
        string _level;
        DataTable dtReq = null;
        Dictionary<string, string> filters;
        string _siteURL = SPContext.Current.Web.Url;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {            
            if (!Page.IsPostBack)
            {
                _ws = new Workshop();
                if (Request.QueryString["WorkshopID"] != null && Request.QueryString["Level"] == "RnD")
                {
                    _editItemID = Request.QueryString["WorkshopID"].ToString();
                    _level = Request.QueryString["Level"].ToString();
                }
                else
                {
                    _ws.LogError("Error on Passing avalid Level", "Level should be RnD");
                }
                readItems(_editItemID);
                BindData_RnDHeadFilter();
            } 
        }       

       
        public void BindData_RnDHeadFilter()
        {
            try
            {
                using (SPSite oSite = new SPSite(_siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lst = SPContext.Current.Web.Lists.TryGetList("WorkshopRequests");
                        string strLoggedInUser = Convert.ToString(oWeb.CurrentUser.Name);
                        SPQuery caml = new SPQuery();
                        caml.Query = @"   <Where>
                                            <And>
                                               <And>
                                                  <And>
                                                     <Eq>
                                                        <FieldRef Name='RNDHead' />
                                                        <Value Type='User'>" + strLoggedInUser + @"</Value>
                                                     </Eq>
                                                     <Eq>
                                                        <FieldRef Name='RNDCheck' />
                                                        <Value Type='Text'>Yes</Value>
                                                     </Eq>
                                                  </And>
                                                  <Eq>
                                                     <FieldRef Name='PLNCheck' />
                                                     <Value Type='Text'>Approved</Value>
                                                  </Eq>
                                               </And>
                                                <Eq>
                                                   <FieldRef Name='WorkshopRefID_x003a_WorkshopID' />
                                                   <Value Type='Lookup'>" + _editItemID + @"</Value>
                                                </Eq>
                                            </And>
                                         </Where>"; 







//@"<Where>
//                                                <And>
//                                                   <And>
//                                                      <Eq>
//                                                         <FieldRef Name='WorkshopRefID_x003a_WorkshopID' />
//                                                         <Value Type='Lookup'>" + _editItemID +@"</Value>
//                                                      </Eq>
//                                                      <Eq>
//                                                         <FieldRef Name='PLNCheck' />
//                                                         <Value Type='Text'>Approved</Value>
//                                                      </Eq>
//                                                   </And>
//                                                   <Eq>
//                                                      <FieldRef Name='RNDCheck' />
//                                                      <Value Type='Text'>Yes</Value>
//                                                   </Eq>
//                                                </And>
//                                             </Where>";


                       

//                        caml.Query = @"<Where>
//                                                 <And>
//                                                    <Eq>
//                                                        <FieldRef Name='PLNCheck' />
//                                                        <Value Type='Text'>Approved</Value>
//                                                    </Eq>                                                    
//                                                     <Eq>
//                                                        <FieldRef Name='WorkshopRefID_x003a_WorkshopID' />
//                                                        <Value Type='Lookup'>" + _editItemID + @"</Value>
//                                                    </Eq>
//                                                </And>                                                                                                                 
//                                        </Where>";
                        dtReq = lst.GetItems(caml).GetDataTable();
                        if (dtReq != null)
                        {
                            DataView dv = new DataView(dtReq);
                            dv.Sort = "Site";
                            ChGrid.DataSource = dv.ToTable();
                            ChGrid.DataBind();
                            txtApprove.Text = string.Empty;
                            txtReject.Text = string.Empty;
                        }
                        else
                        {
                            ChGrid.DataSource = null;
                            ChGrid.DataBind();
                            _ws.LogError("Error on RnD Head", "No Items found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on BindData_RnDHeadFilter()", ex.Message);
            }

        }

        protected void ChGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ChGrid.PageIndex = e.NewPageIndex;
            BindData_RnDHeadFilter();
        }

        protected void ChGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRow dr = ((DataRowView)e.Row.DataItem).Row;

                LinkButton lnkView = e.Row.FindControl("lnkID") as LinkButton;
                lnkView.Text = dr["RequestID"].ToString();

                CheckBox chkApprove = e.Row.FindControl("chkApprove") as CheckBox;
                CheckBox chkReject = e.Row.FindControl("chkReject") as CheckBox;

                Label lblApproved = e.Row.FindControl("lblApproved") as Label;
                Label lblRejected = e.Row.FindControl("lblRejected") as Label;

                if (!string.IsNullOrEmpty(dr["RNDCheck"].ToString()))
                {
                    if (dr["RNDCheck"].ToString().Equals("Approved", StringComparison.OrdinalIgnoreCase))
                    {
                        chkApprove.Visible = false;
                        lblApproved.Visible = true;
                        chkReject.Enabled = false;
                    }
                }
                if (!string.IsNullOrEmpty(dr["RNDCheck"].ToString()))
                {
                    if (dr["RNDCheck"].ToString().Equals("Rejected", StringComparison.OrdinalIgnoreCase))
                    {
                        chkReject.Visible = false;
                        lblRejected.Visible = true;
                        chkApprove.Enabled = false;
                    }
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {

                foreach (GridViewRow row in ChGrid.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chlApprove = row.FindControl("chkApprove") as CheckBox;
                        CheckBox chkReject = row.FindControl("chkReject") as CheckBox;
                        LinkButton lnkConfID = row.FindControl("lnkID") as LinkButton;
                        string ID = lnkConfID.CommandArgument;
                        string reqID = lnkConfID.Text;//added by hkm

                        if (chlApprove.Checked == true && chlApprove.Enabled == true)
                        {
                            if (txtApprove.Text.Length > 0)
                            {
                                _ws.UpdateRnTStatus(itemID: ID, comment: txtApprove.Text, rntCheck: "Approved", status: "Approved", reqStatus: "Approved by RnDHead ");
                                _ws.AddApproverFeedBack("RNTFeedback", reqID, "Approved by RnDHead", txtApprove.Text);//added by hkm
                            }
                            else
                            {
                                lblMassage.Text = "Please enter Approval comments";

                            }
                        }
                        if (chkReject.Checked == true && chkReject.Enabled == true)
                        {
                            if (txtReject.Text.Length > 0)
                            {
                                _ws.UpdateRnTStatusRejected(itemID: ID, comment: txtReject.Text, rntCheck: "Rejected", status: "Rejected", reqStatus: "Rejected by RnDHead ");
                                _ws.AddApproverFeedBack("RNTFeedback", reqID, "Rejected by RnDHead", txtReject.Text);//added by hkm
                            }
                            else
                            {
                                lblMassage.Text = "Please enter Rejection comments";

                            }
                        }
                        
                    }
                }
                //BindData_RnDHeadFilter();
                this.Page.Response.Redirect("/Pages/Confrence_Workshop/RDHeadPendingView.aspx");
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on RnD Head Submit Button" + ex.Message, ex.StackTrace);
            }
           
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            this.Page.Response.Redirect("/Pages/Confrence_Workshop/RDHeadPendingView.aspx");
        }

        protected void readItems(string _ItemID)
        {
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList olist = oWeb.Lists.TryGetList("Conference & Workshop");
                        SPQuery oQry = new SPQuery();
                        oQry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='WorkshopID' />
                                             <Value Type='Text'>" + _ItemID + @"</Value>
                                          </Eq>
                                       </Where>";
                        SPListItemCollection oitems = olist.GetItems(oQry);
                        if (oitems.Count > 0)
                        {
                            DataTable dtAtt = new DataTable();
                            dtAtt = oitems.GetDataTable();
                            lblconfID.Text = dtAtt.Rows[0]["WorkshopID"].ToString();
                            lblConfName.Text = dtAtt.Rows[0]["EventName"].ToString();
                            lblDuration.Text = dtAtt.Rows[0]["Duration"].ToString();
                            lblDate.Text = Convert.ToDateTime(dtAtt.Rows[0]["WStartDate"]).ToString("dd/MM/yyyy") + "-" + Convert.ToDateTime(dtAtt.Rows[0]["WEndDate"]).ToString("dd/MM/yyyy");
                            lblLocation.Text = dtAtt.Rows[0]["Location"].ToString();

                        }
                        else
                        {
                            _ws.LogError("Error on ReadItem(ApprovePSHead)", "No Items found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on ReadItem(RnD Head)", ex.Message);
            }

        }

        protected void ChGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.Trim().ToUpper())
            {
                case "VIEW":
                    this.Page.Response.Redirect("ViewRequest.aspx?ViewID=" + e.CommandArgument.ToString(), true);
                    break;
            }
        }
    }
}
