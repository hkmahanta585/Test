﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Linq;
using Microsoft.Office.Server.UserProfiles;
using System.IO;

namespace EAMS_ConferenceAndWorkshop.CnW_OfflineRequest
{
    public partial class CnW_OfflineRequestUserControl : UserControl
    {

        #region -----------Private Variables-------------
        Workshop _ws;
        string _editItemID;
        string ItemID = string.Empty;
        #endregion

        #region ----------Global Variable---------------
        string _manager = string.Empty;
        string requestId = string.Empty;
        string _WRequest = "";
        string _siteURL = SPContext.Current.Web.Url;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _ws = new Workshop();

                if (Request.QueryString["WorkshopID"] != null)
                {
                    _editItemID = Convert.ToString(Request.QueryString["WorkshopID"]);

                }
                if (!IsPostBack)
                {
                    #region -------Populate Segment and Site----------
                    //Populate Segment
                    PopulateSegmentDropdown(SPContext.Current.Web);
                    //Populate Site
                    PopulateSiteDropdown(SPContext.Current.Web);
                    txtRequestID.Text = Convert.ToString(Request.QueryString["WorkshopID"]) + "-XXX";
                    #endregion


                    if (_editItemID != null)
                    {
                        PopulatePageControlsWithExisting(_editItemID);
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Page load OfflineRequset For confID :" + _editItemID + "", ex.Message);
            }
        }

        public void PopulatePageControlsWithExisting(string _confID)
        {
            getConfIDDetails(_confID);            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (!_ws.CheckEmpExist(txtEmpCode.Text, txtProgramTitle.Text))
                {
                    using (SPSite osite = new SPSite(_siteURL))
                    {
                        using (SPWeb oWeb = osite.OpenWeb())
                        {
                            SPList olist = oWeb.Lists.TryGetList("WorkshopRequests");
                            SPListItem fileItem = olist.AddItem();
                            fileItem.Update();

                            requestId = Convert.ToString(Request.QueryString["WorkshopID"]) + "-" + fileItem.ID.ToString("000");
                            fileItem["Title"] = requestId;
                            fileItem["RequestID"] = requestId;

                            fileItem["Segment"] = ddlSegment.SelectedItem.Text;
                            fileItem["Site"] = ddlSite.SelectedItem.Text;
                            fileItem["Sector"] = ddlSector.SelectedItem.Text;
                            fileItem["Business"] = ddlBusiness.SelectedItem.Text;

                            ItemID = ViewState["ItemID"].ToString();
                            fileItem["WorkshopRefID"] = new SPFieldLookupValue(ItemID.ToString());
                            fileItem["ApprovalFor"] = txtSeekingforapproval.Text;

                            #region------------Getting Approver Head------------------
                            //----------------Danger Zone----------------------

                            //Level 1 :- current user manager 
                            fileItem.Fields["Manager"].ReadOnlyField = false;
                            fileItem["Manager"] = _ws.getMgr(SPContext.Current.Web.CurrentUser.LoginName).ID;

                            SPUser siteHead;
                            //Level 2 :- COE Function Head / Site CTS Head (Site = "COE") 
                            if (Check(ddlSite.SelectedValue, _ws.getID("Site", new KeyValuePair<string, string>("Title", "COE")).ToString()))
                            {
                                siteHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                            }
                            else
                            {
                                siteHead = _ws.getSiteSectorHead("SiteSectorHead", ddlSite.SelectedItem.ToString(), ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "SiteSectorHead");
                            }
                            //RNTFlag (denote wether Segment Head is RnD Head or Not)
                            if (Check(ddlSegment.SelectedValue, _ws.getID("Segment", new KeyValuePair<string, string>("Title", "R&D")).ToString()))
                            {
                                siteHead = _ws.getUserFromList("Group", new KeyValuePair<string, string>("Title", ddlBusiness.SelectedItem.ToString()), "FunctionCOEHead");
                            }
                            fileItem.Fields["HOD"].ReadOnlyField = false;
                            fileItem["HOD"] = siteHead.ID;

                            //Level 3 :- Planning & Stratagy Head
                            SPUser _planningHead = _ws.GetListValue("Sector", ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "PSHead");
                            fileItem.Fields["PlanningHead"].ReadOnlyField = false;
                            fileItem["PlanningHead"] = _planningHead.ID;

                            //--------PSHead ASSISTANT---------
                            SPUser _planningHeadAssistant = _ws.GetListValue("Sector", ddlSector.SelectedItem.ToString(), ddlSegment.SelectedItem.ToString(), "PSHeadAssistant");
                            fileItem.Fields["PSHeadAssistant"].ReadOnlyField = false;
                            fileItem["PSHeadAssistant"] = _planningHeadAssistant.ID;

                            //Segment Flag for RnD Head
                            if (Check(ddlSegment.SelectedValue, _ws.getID("Segment", new KeyValuePair<string, string>("Title", "R&D")).ToString()))
                            {
                                fileItem["RNDCheck"] = "Yes";
                            }
                            else
                            {
                                fileItem["RNDCheck"] = "No";
                            }

                            //PS Manager
                            fileItem["PSManager"] = oWeb.CurrentUser.ID;

                            //----------COE Head--------------
                            SPUser _coeHead = _ws.getUserFromList("Sector", new KeyValuePair<string, string>("Title", ddlSector.SelectedItem.ToString()), "COEHead");
                            fileItem.Fields["COEHead"].ReadOnlyField = false;
                            fileItem.Fields["COEHead"].Update();
                            fileItem["COEHead"] = _coeHead.ID;

                            //--------COEHead ASSISTANT---------
                            SPUser _coeHeadAssistant = _ws.getUserFromList("Sector", new KeyValuePair<string, string>("Title", ddlSector.SelectedItem.ToString()), "COEHeadAssistant");
                            fileItem.Fields["COEHeadAssistant"].ReadOnlyField = false;
                            fileItem["COEHeadAssistant"] = _coeHeadAssistant.ID;

                            //------------Site President----------- 
                            SPUser _sitePresident = _ws.getUserFromList("Site", new KeyValuePair<string, string>("Title", ddlSite.SelectedItem.ToString()), "SitePresident");
                            fileItem.Fields["SitePresident"].ReadOnlyField = false;
                            fileItem["SitePresident"] = _sitePresident.ID;

                            //-----------Site President assistant-------------  
                            SPUser _sitePresidentAssistant = _ws.getUserFromList("Site", new KeyValuePair<string, string>("Title", ddlSite.SelectedItem.ToString()), "SitePresidentAssistant");
                            fileItem.Fields["SitePresidentAssistant"].ReadOnlyField = false;
                            fileItem["SitePresidentAssistant"] = _sitePresidentAssistant.ID;

                            //Level 5 :- GMS / RnD Head
                            SPUser segHead = _ws.getUserFromList("Segment", new KeyValuePair<string, string>("Title", ddlSegment.SelectedItem.Text.Trim()), "SeniorManagement");
                            fileItem.Fields["RNDHead"].ReadOnlyField = false;
                            fileItem.Fields["RNDHead"].Update();
                            fileItem["RNDHead"] = segHead.ID;

                            //---------RNDHead Assistant-----------------
                            SPUser _RnDHeadAssitant = _ws.getUserFromList("Segment", new KeyValuePair<string, string>("Title", ddlSegment.SelectedItem.Text.Trim()), "SeniorManagementAssistant");
                            fileItem.Fields["RNDHeadAssistant"].ReadOnlyField = false;
                            fileItem["RNDHeadAssistant"] = _RnDHeadAssitant.ID;



                            if (ddlSite.SelectedValue.Equals(_ws.getID("Site", new KeyValuePair<string, string>("Title", "COE")).ToString()))
                            {
                                fileItem["TechCOEFlag"] = "Yes";
                            }
                            else
                            {
                                fileItem["TechCOEFlag"] = "No";
                            }


                            //--------------End Of Danger Zone-------------------------------------------
                            #endregion

                            #region -------Other fields-----------
                            SPUser userReq = oWeb.EnsureUser(cppUser.InitialUserAccounts.Split('|')[1]);
                            fileItem["Requestor"] = userReq.ID;

                            fileItem["EmpCode"] = txtEmpCode.Text;
                            fileItem["EmpName"] = cppUser.AllEntities[0].DisplayText;

                            fileItem["RStatus"] = "Open";
                            fileItem["Status"] = "Proposed";
                            fileItem["DelFlag"] = "0";
                            fileItem["WFLevel"] = "2";
                            //fileItem["TechCOEFlag"] = "No";
                            //fileItem["RNDCheck"] = "No";

                            fileItem["UserType"] = "Normal Requestor";
                            fileItem["Pending"] = "No";
                            fileItem["SendMail"] = "Off";
                            fileItem["PLNCheck"] = "No";
                            fileItem["ReqStatus"] = "Pending with PSHead";
                            fileItem["ReqDate"] = DateTime.Now.ToString("dd-MMM-yyyy");

                            #endregion

                            saveFile(oWeb, requestId);
                            fileItem.Update();

                            lblMsg.Text = "Request has been created successfully.";

                            cppUser.AllEntities.Clear();
                            txtEmpCode.Text = "";

                        }
                    }

                }
                else
                {
                    lblMsg.Text = "Employee already exist";
                    cppUser.AllEntities.Clear();
                    txtEmpCode.Text = "";
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Submit Offline Rerquest", ex.Message);
            }

        }

        #region ---------Event Handlers------------

        public bool Check(string A1, string A2)
        {
            if (A1.Equals(A2, StringComparison.OrdinalIgnoreCase))
                return true;
            else
                return false;
        }

        protected void ddlSegment_SelectedIndexChanged(object sender, EventArgs e)
        {
            string segmentId = ddlSegment.SelectedItem.Text; ;
            PopulateSector(segmentId);
        }

        protected void ddlSector_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sectorName = ddlSector.SelectedItem.Text;
            PopulateGroup(sectorName);
        }

        protected void lnkAttachFile_Click(object sender, EventArgs e)
        {
            using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPList list = oWeb.Lists.TryGetList("WorkshopRequestsDocs");
                    SPListItem item = list.GetItemById(Convert.ToInt32(_editItemID));

                    // Access the file
                    SPFile file = item.File;
                    string path = file.Url.ToString();
                    if (file != null)
                    {

                        byte[] bytes = file.OpenBinary();
                        byte[] fileData = bytes;

                        Response.Clear();
                        Response.Buffer = true;
                        Response.ClearHeaders();

                        string fileName = item.File.Name;
                        Response.ContentType = FileUtility.GetMIMEType(fileName);

                        String userAgent = Request.Headers.Get("User-Agent");
                        if (userAgent.Contains("MSIE 7.0"))
                        {
                            fileName = fileName.Replace(" ", "%20");
                        }
                        Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

                        Response.OutputStream.Write(fileData, 0, fileData.Length);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }

        #endregion

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            this.Page.Response.Redirect("/Pages/Confrence_Workshop/ParticipantPSMgr.aspx?WorkshopID=" + _editItemID, false);
        }

        #region -------------Methods------------------

        private void PopulateSegmentDropdown(SPWeb oWeb)
        {
            _ws = new Workshop();
            try
            {
                SPList lstSegment = oWeb.Lists.TryGetList("Segment");
                DataTable dtSegment = _ws.PopulateSegmentDropdown(oWeb);// lstSegment.GetItems().GetDataTable();

                if (dtSegment != null)
                {
                    ddlSegment.DataSource = dtSegment;
                    ddlSegment.DataTextField = dtSegment.Columns["Title"].ToString();
                    ddlSegment.DataValueField = dtSegment.Columns["ID"].ToString();
                    ddlSegment.DataBind();
                    ddlSegment.Items.Insert(0, "--Select--");
                }
                else
                {
                    DataTable Emptydt = new DataTable();
                    ddlSegment.DataSource = Emptydt;
                    ddlSegment.DataBind();
                    ddlSegment.Items.Insert(0, "--Select--");
                }

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate PopulateSegmentDropdown", ex.Message);
                throw ex;
            }
        }

        private void PopulateSector(string strSegment)
        {
            _ws = new Workshop();
            string strSegmentValue = strSegment;
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        //SPList lstSector = oWeb.Lists.TryGetList("Sector");
                        //SPQuery qry = new SPQuery();
                        //qry.Query = @"<Where><Eq><FieldRef Name='Segment'/><Value Type='Lookup'>" + strSegmentValue + "</Value></Eq></Where>";
                        DataTable dtSector = _ws.PopulateSectorDropdown(oWeb, strSegment);// lstSector.GetItems(qry).GetDataTable();
                        if (dtSector != null)
                        {
                            ddlSector.DataSource = dtSector;
                            ddlSector.DataTextField = dtSector.Columns["Title"].ToString();
                            ddlSector.DataValueField = dtSector.Columns["ID"].ToString();
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");

                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlSector.DataSource = Emptydt;
                            ddlSector.DataBind();
                            ddlSector.Items.Insert(0, "--Select--");

                            // DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate sector", ex.Message); throw ex;
            }

        }

        private void PopulateGroup(string strSector)
        {
            _ws = new Workshop();
            string strSectorValue = strSector;
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        //SPList lstGroup = oWeb.Lists.TryGetList("Group");
                        //SPQuery qry = new SPQuery();
                        //qry.Query = @"<Where><Eq><FieldRef Name='Sector'/><Value Type='Lookup'>" + strSectorValue + @"</Value></Eq></Where>";
                        DataTable dtGroup = _ws.PopulateGroupDropdown(oWeb, strSector);//.GetItems(qry).GetDataTable();
                        if (dtGroup != null)
                        {
                            ddlBusiness.DataSource = dtGroup;
                            ddlBusiness.DataTextField = dtGroup.Columns["Title"].ToString();
                            ddlBusiness.DataValueField = dtGroup.Columns["ID"].ToString();
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            DataTable Emptydt = new DataTable();
                            ddlBusiness.DataSource = Emptydt;
                            ddlBusiness.DataBind();
                            ddlBusiness.Items.Insert(0, "--Select--");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate Group", ex.Message);
            }
        }

        private void PopulateSiteDropdown(SPWeb oWeb)
        {
            _ws = new Workshop();
            try
            {
                //SPList lstSite = oWeb.Lists.TryGetList("Site");
                DataTable dtSite = _ws.PopulateSiteDropdown(oWeb);// lstSite.GetItems().GetDataTable();
                ddlSite.DataSource = dtSite;
                ddlSite.DataTextField = dtSite.Columns["Title"].ToString();
                ddlSite.DataValueField = dtSite.Columns["ID"].ToString();
                ddlSite.DataBind();
                ddlSite.Items.Insert(0, "--Select--");

            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Populate PopulateSiteDropdown", ex.Message); throw ex;
            }
        }

        private void saveFile(SPWeb oWeb, string reqID)
        {
            SPList list = oWeb.Lists.TryGetList("WorkshopRequestsDocs");
            string newfile = string.Empty, fileName = string.Empty, _fileUrl = string.Empty;
            byte[] contentByteArray;
            SPFile file = null;
            if (fldFileUpload.HasFile)
            {
                Stream fStream = fldFileUpload.PostedFile.InputStream;
                contentByteArray = new byte[fStream.Length];
                fStream.Close();

                fileName = reqID + "_" + fldFileUpload.FileName;
                _fileUrl = list.RootFolder.Url + "/" + fileName;
                file = list.RootFolder.Files.Add(_fileUrl, contentByteArray, false);

                SPListItem fileItem = file.Item;
                fileItem["RequestID"] = reqID;
                fileItem.Fields["Requestor"].ReadOnlyField = false;
                fileItem["Requestor"] = oWeb.CurrentUser.ID;
                fileItem.Update();
            }
            else
            {
                _ws.LogError("No File uploaded by the User", "No file uploaded by User");
            }



        }

        public void GetApproverFlow()
        {
            try
            {
                lblSiteHead.Text = "";
                using (SPSite oSite = new SPSite(_siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        //---------------- Getting PS Head Details------------
                        SPList lstSector = oWeb.Lists.TryGetList("Sector");
                        SPQuery qrySector = new SPQuery();
                        qrySector.Query = @"<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + ddlSector.SelectedItem.Text + @"</Value></Eq></Where>";
                        DataTable dtSector = lstSector.GetItems(qrySector).GetDataTable();
                        DataRow drSector = dtSector.Rows[0];
                        SPUser PSHead = SPContext.Current.Web.EnsureUser(Convert.ToString(drSector["PSHead"]));
                        lblSiteHead.Text = "Approval Flow :- PS Head(" + PSHead.Name.ToString() + ")---> (Subsequent Approval Based on Workshop Location...)";
                    }
                }
            }
            catch (Exception ex)
            {
                lblSiteHead.Text = "Approver not available";
                //_ws.LogError("Error on GetApproverFlow()", ex.Message);
                throw ex;
            }

        }

        protected void getConfIDDetails(string _ItemID)
        {
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList olist = oWeb.Lists.TryGetList("Conference & Workshop");
                        SPQuery oQry = new SPQuery();
                        oQry.Query = @"<Where>
                                          <Eq>
                                             <FieldRef Name='WorkshopID' />
                                             <Value Type='Text'>" + _ItemID + @"</Value>
                                          </Eq>
                                       </Where>";
                        SPListItemCollection oitems = olist.GetItems(oQry);
                        if (oitems.Count > 0)
                        {
                            DataTable dtAtt = new DataTable();
                            dtAtt = oitems.GetDataTable();
                            //Default fields------------                           
                            txtSeekingforapproval.Text = dtAtt.Rows[0]["Category"].ToString();
                            txtProgramTitle.Text = dtAtt.Rows[0]["EventName"].ToString();
                            txtOrganized.Text = dtAtt.Rows[0]["OrganizedBy"].ToString();
                            txtLocation.Text = dtAtt.Rows[0]["Location"].ToString();
                            txtProgramDuration.Text = dtAtt.Rows[0]["Duration"].ToString();

                            ViewState["ItemID"] = dtAtt.Rows[0]["ID"].ToString();
                            //ViewState["Overseas"] = dtAtt.Rows[0]["Overseas"].ToString();

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on getConfIDDetails()" + ex.Message, ex.StackTrace);
            }
        }

        #endregion

        protected void ddlSite_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetApproverFlow();
        }
    }
}
