﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Linq;
using System.Collections.Generic;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;


namespace EAMS_ConferenceAndWorkshop.CnW_ConferenceList
{
    public partial class CnW_ConferenceListUserControl : UserControl
    {
        #region -----------Variables------------
        Workshop _ws;
        string _year = string.Empty;
        string _confName = string.Empty;
        Dictionary<string, string> filters;
        bool searchFlag = false;
        bool flag = true;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();
            if (!Page.IsPostBack)
            {
                
                ViewState["Year"] = System.DateTime.Now.Year.ToString();
                BindData(System.DateTime.Now.Year.ToString(), _confName);
               
                ddlYear.Items.Add(DateTime.Now.Year.ToString()); 
                ddlYear.Items.Add((DateTime.Now.Year -1).ToString());
                ddlYear.Items.Add((DateTime.Now.Year + 1).ToString());
                ddlYear.Items.Add((DateTime.Now.Year + 2).ToString());
            }
        }

        public void BindData(string year, string confName)
        {
            DataTable filterTable = new DataTable();
            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList olist = oWeb.Lists.TryGetList("Conference & Workshop");

                        if (!string.IsNullOrEmpty(confName) && !string.IsNullOrEmpty(year))
                        {
                            filterTable = BindFilter(confName, year, olist);
                            if (filterTable != null)
                            {
                                gvGroup.DataSource = filterTable;
                                gvGroup.DataBind();
                            }
                            else
                            {
                                gvGroup.DataSource = null;
                                gvGroup.DataBind();
                            }
                        }
                        else
                        {
                            filterTable = BindFilter(confName, year, olist);
                            if (filterTable != null)
                            {
                                gvGroup.DataSource = filterTable;
                                gvGroup.DataBind();
                            }
                            else
                            {
                                gvGroup.DataSource = null;
                                gvGroup.DataBind();
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on readItem ", ex.Message);
                throw ex;
            }

        }

        public DataTable BindFilter(string filterParameter, string filterYear, SPList olist)
        {
            DataTable dtFilter = new DataTable();
            try
            {
                SPQuery oQry = new SPQuery();
                oQry.ViewFields = @"<FieldRef Name='ID'/><FieldRef Name='WorkshopID'/>
                                    <FieldRef Name='Title'/><FieldRef Name='EventName'/><FieldRef Name='OrganizedBy'/>
                                    <FieldRef Name='WStartDate'/><FieldRef Name='WEndDate'/><FieldRef Name='Duration'/>
                                    <FieldRef Name='ConfYear'/><FieldRef Name='Location'/><FieldRef Name='Overseas'/>";

                String querytoGetData = String.Empty;
                querytoGetData = @"<Where>";

                if (!string.IsNullOrEmpty(filterParameter))
                {
                    querytoGetData += @"<And>
                                         <Contains>
                                            <FieldRef Name='Title' />
                                            <Value Type='Text'>" + filterParameter + @"</Value>
                                         </Contains>
                                         <Eq>
                                            <FieldRef Name='ConfYear' />
                                            <Value Type='Text'>" + filterYear + @"</Value>
                                         </Eq>
                                      </And>";
                }
                else
                {
                    querytoGetData += @"<Eq>
                                            <FieldRef Name='ConfYear' />
                                            <Value Type='Text'>" + filterYear + @"</Value>
                                        </Eq>";
                }
                querytoGetData += @"</Where> 
                                    <OrderBy>
                                        <FieldRef Name='WStartDate' Ascending='FALSE' />
                                    </OrderBy>";
                oQry.Query = querytoGetData;
                SPListItemCollection oitemsConfName = olist.GetItems(oQry);

                if (oitemsConfName.Count > 0)
                    dtFilter = oitemsConfName.GetDataTable();
                else
                    dtFilter = null;
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on BindFilter() ", "No Items found of Parameter :" + filterParameter + " and " + filterYear);
                throw ex;
            }
            return dtFilter;
        }

        protected void gvGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            searchFlag = false;
            gvGroup.PageIndex = e.NewPageIndex;
            BindData(Convert.ToString(ViewState["Year"]), Convert.ToString(ViewState["ConfName"]));
        }

        protected void btnYes_Click(object sender, EventArgs e)
        {
            //_ws.DeleteItem("Conference & Workshop", int.Parse(ViewState["_itemID"].ToString()));
            //searchFlag = false;
            //BindData(ViewState["Year"].ToString(), ViewState["ConfName"].ToString());
        }

        protected void gvGroup_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    DataRow dr = ((DataRowView)e.Row.DataItem).Row;
                    LinkButton lnkView = e.Row.FindControl("lnkView") as LinkButton;
                    lnkView.Text = dr["WorkshopID"].ToString();

                    if (!string.IsNullOrEmpty(dr["WStartDate"].ToString()))
                    {
                        DateTime startDate = Convert.ToDateTime(dr["WStartDate"]);
                        DateTime toDay = DateTime.Now;
                        if (startDate < toDay && flag == true)
                        {
                            e.Row.ToolTip = "OldConferences";
                            foreach (TableCell cell in e.Row.Cells)
                            {
                                cell.ToolTip = "OldConferences";
                            }
                            flag = false;
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                throw exp;
            }

        }

        protected void gvGroup_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.Trim().ToUpper())
            {
                case "VIEW":
                    Response.Redirect("ConfrenceEdit.aspx?EditID=" + e.CommandArgument.ToString(), true);
                    break;
            }
        }

        protected void gvGroup_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvGroup.EditIndex = e.NewEditIndex;
            BindData(ViewState["Year"].ToString(), ViewState["ConfName"].ToString());
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                _year = ddlYear.SelectedItem.Text;// (ddlYear.SelectedItem.Value.Length > 0 ? ddlYear.SelectedItem.Value : string.Empty);
                _confName = (txtConfname.Text.Length > 0 ? txtConfname.Text : string.Empty);

                if (!string.IsNullOrEmpty(_year))
                {
                    ViewState["Year"] = _year;
                    ViewState["ConfName"] = _confName;
                    searchFlag = true;
                    BindData(_year, _confName);
                }
                else
                {
                    ViewState["ConfName"] = _confName;
                    searchFlag = false;
                    BindData(_year, _confName);
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on Search Result. ", ex.Message);
            }
        }

        protected void btnAddnewConf_Click(object sender, EventArgs e)
        {
            this.Page.Response.Redirect("/Pages/Confrence_Workshop/Confrence.aspx");
        }

        protected void gvGroup_PreRender(object sender, EventArgs e)
        {
            if (gvGroup.Rows.Count > 0)
            {
                gvGroup.UseAccessibleHeader = true;
                gvGroup.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
        }      

    }
}
