﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_ViewReport
{
    public partial class CnW_ViewReportUserControl : UserControl
    {
        #region ============Global Variable==============
        
        string siteURL = SPContext.Current.Web.Url.ToString();
        string _reportID = string.Empty;
        Workshop _ws=new Workshop();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.Request.QueryString["ReportID"] != null)
            {
                _reportID = Page.Request.QueryString["ReportID"].ToString();
            }

            if (!this.Page.IsPostBack)
            {
                if (_reportID != null)
                {
                    FillExisitngRecord(_reportID);
                }
            }
        }

        private void FillExisitngRecord(string _reportID)
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstReports = oWeb.Lists.TryGetList("WorkshopDocs");
                        SPListItem itemReport = lstReports.GetItemById(Convert.ToInt32(_reportID.ToString()));                       
                        lblRequestID.Text =Convert.ToString(itemReport["RequestID"]);
                        lblEmpCode.Text = Convert.ToString(itemReport["EmpCode"]);
                        lblEmpName.Text = Convert.ToString(itemReport["EmpName"]);
                        //SPFieldUser userField = (SPFieldUser)itemReport.Fields.GetField("Requstor");
                        //SPFieldUserValue userFieldValue = (SPFieldUserValue)userField.GetFieldValue(itemReport["Requstor"].ToString());
                        //SPUser user = userFieldValue.User;
                        //lblEmpName.Text = user.Name.ToString();
                        lblConfID.Text = Convert.ToString(itemReport["ConfID"]);
                        lblConferenceName.Text =Convert.ToString( itemReport["EventName"]);
                        lblLocation.Text =Convert.ToString( itemReport["Location"]);
                        lblProgramDuration.Text = itemReport["StartDate"].ToString() + " - " + itemReport["EndDate"].ToString() + " (" + itemReport["Duration"].ToString() + ")";
                        if (itemReport["FileLeafRef"].ToString().ToLower().Contains("xxxxx"))
                        {
                            lnkAttachedFile.Text = string.Empty;
                        }
                        else
                        {
                            lnkAttachedFile.Text = itemReport["FileLeafRef"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on FillExisitngRecord()", ex.Message);
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstReports = oWeb.Lists.TryGetList("WorkshopDocs");
                        SPListItem itemReport = lstReports.GetItemById(Convert.ToInt32(_reportID.ToString()));
                        itemReport["Status"] = (rdbConfLevel1.Checked == true ? "Level1" : "Level2");
                        itemReport["Remarks"] = txtComment.Text;
                        itemReport.Update();

                        this.Page.Response.Redirect("TripReportView.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on btnSubmit_Click()", ex.Message);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect("/Pages/Confrence_Workshop/TripReportView.aspx", true);
        }

        protected void lnkAttachedFile_Click(object sender, EventArgs e)
        {
            _ws = new Workshop();
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {

                        string qryReportID = Page.Request.QueryString["ReportID"].ToString();
                        //SPList docLib = web.Lists["LECINVList"];
                        SPList lstWorkshopDocs = oWeb.Lists.TryGetList("WorkshopDocs");
                        SPListItem item = lstWorkshopDocs.GetItemById(Convert.ToInt32(qryReportID));
                        // Access the file
                        SPFile file = item.File;
                        string path = file.Url.ToString();

                        if (file != null)
                        {
                            byte[] bytes = file.OpenBinary();
                            byte[] fileData = bytes;

                            Page.Response.Clear();
                            Page.Response.Buffer = true;
                            Page.Response.ClearHeaders();

                            string fileName = item.File.Name;
                            Page.Response.ContentType =FileUtility.GetMIMEType(fileName);

                            String userAgent = Page.Request.Headers.Get("User-Agent");
                            if (userAgent.Contains("MSIE 7.0"))
                            {
                                fileName = fileName.Replace(" ", "%20");
                            }
                            Page.Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

                            Page.Response.OutputStream.Write(fileData, 0, fileData.Length);
                            Page.Response.Flush();
                            Page.Response.End();
                            btnCancel.Focus();
                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on lnkAttachedFile_Click()", ex.Message);
            }

        }
       
    }
}
