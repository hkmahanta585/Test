﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Linq;

namespace EAMS_ConferenceAndWorkshop.CnW_Approve
{
    public partial class CnW_ApproveUserControl : UserControl
    {
        #region -------Private Members------------
        string _editItemID;
        string _level;
        Workshop _ws;
        
        int _wfLevel;
        string _role;
        string siteURL = SPContext.Current.Web.Url;
        #endregion


        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();

            if (Request.QueryString["ApproveID"] != null && (Request.QueryString["Level"] == "MGR" || Request.QueryString["Level"] == "HOD"))
            {
                _editItemID = Request.QueryString["ApproveID"].ToString();
                _level = Request.QueryString["Level"].ToString();
            }
            else
            {
                _ws.LogError("ERROR on Parameter", "Parameter should be HOD or MGR");
            }            

            if (!IsPostBack)
            {
                PopulatePageWithData(_editItemID);
            }
        }

        private void PopulatePageWithData(string _editID)
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList lstWorkshopRequests = oWeb.Lists.TryGetList("WorkshopRequests");
                        SPListItem oItem = lstWorkshopRequests.GetItemById(Convert.ToInt32(_editID));

                        #region ------------FETCHING ITEMS FROM LIST--------------

                        lblRequestID.Text = oItem["RequestID"].ToString();
                        ViewState["ReqID"] = oItem["RequestID"].ToString();
                        lblSegment.Text = oItem["Segment"].ToString();
                        lblSector.Text = oItem["Sector"].ToString();
                        lblBusiness.Text = oItem["Business"].ToString();
                        lblSite.Text = oItem["Site"].ToString();
                        lblEmpName.Text = oItem["Requestor"].ToString();
                       // lblEmpName.Text = oItem["EmpName"].ToString();
                        lblEmpCode.Text = oItem["EmpCode"].ToString();
                        lblSeekApproval.Text = oItem["ApprovalFor"].ToString();

                        lblOrganizedBy.Text = oItem["WorkshopRefID_x003a_Organized_x0"].ToString().Split('#')[1];
                        lblkeyReason.Text = oItem["KeyReason"].ToString();

                        lblvalue.Text = oItem["ValueField"].ToString();
                        if (oItem["BudgetAllocated"].ToString().Contains("Yes"))
                        {
                            lblbudget.Text = oItem["BudgetAllocated"].ToString() + ":- " + oItem["BudgetDesc"].ToString();
                        }
                        else
                        {
                            lblbudget.Text = oItem["BudgetAllocated"].ToString() + "Budget Allocated";
                        }
                        lblProgramTitle.Text = oItem["WorkshopRefID_x003a_NameSDate"].ToString().Split('#')[1];
                        lblLocation.Text = oItem["WorkshopRefID_x003a_Location"].ToString().Split('#')[1];
                        lblFeeAccomodation.Text = oItem["Fee"].ToString();
                        lblAccomodation.Text = oItem["Accommodation"].ToString();
                        lblProgramDuration.Text = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("ID", oItem["WorkshopRefID"].ToString().Split('#')[1]), "WStartDate") + " - " + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("ID", oItem["WorkshopRefID"].ToString().Split('#')[1]), "WEndDate") + " (" + oItem["WorkshopRefID_x003a_Duration"].ToString().Split('#')[1] + ")";
                       
                        if (!string.IsNullOrEmpty(Convert.ToString(oItem["WFLevel"])))
                        {
                            _wfLevel = Convert.ToInt32(oItem["WFLevel"]);
                        }
                        lnkAttachedFile.Text = _ws.fileAttached(oWeb, Convert.ToString(oItem["RequestID"]));

                        #endregion

                        ViewState["_wfLevel"] = _wfLevel.ToString();
                        //Approval Status -------------
                        gvStatus.DataSource = _ws.GetRequestStatusDetails_Conf(Convert.ToString(oItem["RequestID"]));
                        gvStatus.DataBind();
                        //Control flipflop---------------
                        HideControls();
                    }
                }
            }

            catch (Exception ex)
            {
                _ws.LogError("Error on PopulatePageWithData()", ex.Message);
            }
        }

        private void HideControls()
        {
            string comment = string.Empty;
            string status = string.Empty;
            //switch (wFLevel)
            switch (_level.Trim().ToUpper())
            {
                case "MGR":
                    comment = _ws.GetFeedBack(listName: "MgrFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                    status = _ws.GetFeedBack(listName: "MgrFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                    break;
                case "HOD":
                    comment = _ws.GetFeedBack(listName: "HODFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                    status = _ws.GetFeedBack(listName: "HODFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                    break;


                case "PLAN":
                    comment = _ws.GetFeedBack(listName: "PlanNSFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                    status = _ws.GetFeedBack(listName: "PlanNSFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                    break;
                case "RNT":
                    comment = _ws.GetFeedBack(listName: "RNTFeedback", returnColumn: "Comment", requestID: lblRequestID.Text);
                    status = _ws.GetFeedBack(listName: "RNTFeedback", returnColumn: "Status", requestID: lblRequestID.Text);
                    break;
            }

            if (status.Contains("Pending") || string.IsNullOrEmpty(status))
            {
                ddlStatus.Visible = true;
                txtComment.Visible = true;
                ddlStatus.SelectedItem.Text = string.IsNullOrEmpty(status) ? "Pending" : status;
                txtComment.Text = comment;
            }
            else
            {
                ddlStatus.Visible = false;
                txtComment.Visible = false;
                divStatus.InnerText = status;
                divComment.InnerText = comment;
                btnApprove.Visible = false;
                btnReject.Text = "OK";
            }

        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            using (SPSite osite = new SPSite(siteURL))
            {
                using (SPWeb oWeb = osite.OpenWeb())
                {
                    string listTitle;
                    switch (int.Parse(ViewState["_wfLevel"].ToString()))
                    {
                        case 0:
                            listTitle = "MgrFeedback";
                            _role = "by L1";
                            break;
                        case 11:
                            listTitle = "MgrFeedback";
                            _role = "by L1";
                            break;
                        case 21:
                            listTitle = "MgrFeedback";
                            _role = "by L1";
                            break;

                        case 1:
                            listTitle = "HODFeedback";
                            _role = "by HOD";
                            break;
                        case 12:
                            listTitle = "HODFeedback";
                            _role = "by HOD";
                            break;
                        case 22:
                            listTitle = "HODFeedback";
                            _role = "by HOD";
                            break;

                        default:
                            //listTitle = "RNTFeedback";
                            //_role = "by R&T Head";
                             listTitle = "HODFeedback";
                            _role = "by HOD";

                            break;
                    }
                    SPList list = oWeb.Lists.TryGetList(listTitle);
                    SPListItem item = list.AddItem();
                    item["Title"] = lblRequestID.Text;
                    item["Status"] = ddlStatus.SelectedItem.Text;
                    item["Comment"] = txtComment.Text;
                    item.Update();                      
                    //Update status in WorkshopRequests List (Main List)
                    UpdateRequestStatus(oWeb);
                    this.Page.Response.Redirect("Summary.aspx");
                }
            }
        }

        private void UpdateRequestStatus(SPWeb oWeb)
        {
            try
            {
                SPList list = oWeb.Lists.TryGetList("WorkshopRequests");
                SPListItem item = list.GetItemById(int.Parse(_editItemID));

                if (ddlStatus.SelectedItem.Text.Equals("Pending", StringComparison.OrdinalIgnoreCase))
                {
                    item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
                    item["RStatus"] = "Open";
                    item["ReqStatus"] = "Pending " + _role;
                }
                else if (ddlStatus.SelectedItem.Text.Equals("Rejected", StringComparison.OrdinalIgnoreCase))
                {
                    item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString());
                    item["RStatus"] = "Closed";
                    item["ReqStatus"] = "Rejected " + _role;
                }
                else
                {
                    item["WFLevel"] = Int32.Parse(item["WFLevel"].ToString()) + 1;
                    item["RStatus"] = "Open";
                    item["ReqStatus"] = "Approved " + _role;
                }

                item["Pending"] = (_level.Trim().ToUpper() == "MGR" ? "yes" : "No");
                item["Status"] = ddlStatus.SelectedItem.Text;
                item["Comments"] = txtComment.Text;
                item["ApprDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
                item.Update();
            }
            catch (Exception exp)
            {
                _ws.LogError("Error on UpdateRequestStatus()", exp.Message);
                throw exp;
            }

        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            Response.Redirect("Summary.aspx");
        }

        protected void lnkAttachedFile_Click(object sender, EventArgs e)
        { 
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        string qryRequestID = ViewState["ReqID"].ToString();
                        SPDocumentLibrary lstWorkshopRequestsDocs = oWeb.Lists.TryGetList("WorkshopRequestsDocs") as SPDocumentLibrary;
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                      <Eq>
                                         <FieldRef Name='RequestID' />
                                         <Value Type='Text'>" + qryRequestID + @"</Value>
                                      </Eq>
                                   </Where><OrderBy><FieldRef Name='Modified' Ascending='FALSE' /></OrderBy>";
                        SPListItemCollection oitems = lstWorkshopRequestsDocs.GetItems(qry);
                        foreach (SPListItem item in oitems)
                        {
                            SPFile file = item.File;
                            string path = file.Url.ToString();

                            if (file != null)
                            {
                                byte[] bytes = file.OpenBinary();
                                byte[] fileData = bytes;

                                Page.Response.Clear();
                                Page.Response.Buffer = true;
                                Page.Response.ClearHeaders();

                                string fileName = item.File.Name;
                                Page.Response.ContentType =FileUtility.GetMIMEType(fileName);

                                String userAgent = Page.Request.Headers.Get("User-Agent");
                                if (userAgent.Contains("MSIE 7.0"))
                                {
                                    fileName = fileName.Replace(" ", "%20");
                                }
                                Page.Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

                                Page.Response.OutputStream.Write(fileData, 0, fileData.Length);
                                Page.Response.Flush();
                                Page.Response.End();

                                break;
                            }

                        }
                    }
                }
            }
            catch (SPException ex)
            {
                _ws.LogError("Error on File Downloding", ex.Message);
            }

        }

       /* public static String GetMIMEType(String filepath)
        {
            System.Security.Permissions.RegistryPermission regPerm =
                new System.Security.Permissions.RegistryPermission(System.Security.Permissions.RegistryPermissionAccess.Read, "\\HKEY_CLASSES_ROOT");
            Microsoft.Win32.RegistryKey classesRoot = Microsoft.Win32.Registry.ClassesRoot;
            System.IO.FileInfo fi = new System.IO.FileInfo(filepath);

            string dotExt = fi.Extension.ToLower();
            Microsoft.Win32.RegistryKey typeKey = classesRoot.OpenSubKey("MIME\\Database\\Content Type");
            foreach (string keyname in typeKey.GetSubKeyNames())
            {
                Microsoft.Win32.RegistryKey curKey = classesRoot.OpenSubKey("MIME\\Database\\Content Type\\" + keyname);

                if (curKey.GetValue("Extension") != null && curKey.GetValue("Extension").ToString().ToLower() == dotExt)
                {
                    return keyname;
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".docx")
                {
                    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".xlsx")
                {
                    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".zip")
                {
                    return "application/octet-stream";
                }

            }
            return string.Empty;
        }*/
    }
}
