﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Linq;

namespace EAMS_ConferenceAndWorkshop.CnW_ViewRequest
{
    public partial class CnW_ViewRequestUserControl : UserControl
    {
        string _editItemID;
        Workshop _ws;
        string siteURL = SPContext.Current.Web.Url.ToString();
      
        protected void Page_Load(object sender, EventArgs e)
        {
            _ws = new Workshop();
            if (Request.QueryString["ViewID"] != null)
            {
                _editItemID = Request.QueryString["ViewID"].ToString();
            }
            if (!IsPostBack && _editItemID != null)
            {
                PopulatePageWithData(_editItemID);
            }
        }
        protected void PopulatePageWithData(string _editID)
        {
            using (SPSite oSite = new SPSite(siteURL))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPList lstWorkshopRequests = oWeb.Lists.TryGetList("WorkshopRequests");
                    SPListItem oItem = lstWorkshopRequests.GetItemById(Convert.ToInt32(_editID));

                    #region ------------READING ITEMS--------------

                    lblRequestID.Text = oItem["RequestID"].ToString();
                    ViewState["ReqID"] = oItem["RequestID"].ToString();//Needs for file attachment,plz dont delete
                    lblSegment.Text = oItem["Segment"].ToString();
                    lblSector.Text = oItem["Sector"].ToString();
                    lblBusiness.Text = oItem["Business"].ToString();
                    lblSite.Text = oItem["Site"].ToString();
                    lblEmpName.Text = oItem["Requestor"].ToString();
                  
                    lblSeekApproval.Text = Convert.ToString(oItem["ApprovalFor"]);

                    lblOrganizedBy.Text = oItem["WorkshopRefID_x003a_Organized_x0"].ToString().Split('#')[1];

                    lblkeyReason.Text = Convert.ToString(oItem["KeyReason"]);
                    lblvalue.Text =Convert.ToString( oItem["ValueField"]);

                    if (Convert.ToString(oItem["BudgetAllocated"]).Contains("Yes"))
                        lblbudget.Text = Convert.ToString(oItem["BudgetAllocated"]) + ":- " + Convert.ToString(oItem["BudgetDesc"]);
                    else
                        lblbudget.Text = Convert.ToString(oItem["BudgetAllocated"]) + "Budget Allocated";

                    lblStatusDate.Text = Convert.ToString(oItem["ApprDate"]);
                    lblProgramTitle.Text = oItem["WorkshopRefID_x003a_NameSDate"].ToString().Split('#')[1];
                    lblLocation.Text = oItem["WorkshopRefID_x003a_Location"].ToString().Split('#')[1];

                    lblFee.Text = Convert.ToString(oItem["Fee"]);
                    lblFeeAccomodation.Text = Convert.ToString(oItem["Accommodation"]);
                    lblProgramDuration.Text = _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("ID", oItem["WorkshopRefID"].ToString().Split('#')[1]), "WStartDate") + " - " + _ws.getColumnValue("Conference & Workshop", new KeyValuePair<string, string>("ID", oItem["WorkshopRefID"].ToString().Split('#')[1]), "WEndDate") + " (" + oItem["WorkshopRefID_x003a_Duration"].ToString().Split('#')[1] + ")";

                    lblEmpName.Text = Convert.ToString(oItem["EmpName"]);
                    lblEmpCode.Text = Convert.ToString(oItem["EmpCode"]);
                    lblStatus.Text = Convert.ToString(oItem["ReqStatus"]);
                    lblComment.Text = Convert.ToString(oItem["Comments"]);

                    lnkAttachedFile.Text = _ws.fileAttached(oWeb, Convert.ToString(oItem["RequestID"]));

                    #endregion

                    gvStatus.DataSource = _ws.GetRequestStatusDetails_Conf(Convert.ToString(oItem["RequestID"]));
                    gvStatus.DataBind();
                }
            }

        }

        protected void lnkAttachedFile_Click(object sender, EventArgs e)
        {
            try
            {
                using (SPSite oSite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        string qryRequestID = ViewState["ReqID"].ToString(); 
                        SPDocumentLibrary lstWorkshopRequestsDocs = oWeb.Lists.TryGetList("WorkshopRequestsDocs") as SPDocumentLibrary;
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                      <Eq>
                                         <FieldRef Name='RequestID' />
                                         <Value Type='Text'>" + qryRequestID + @"</Value>
                                      </Eq>
                                   </Where><OrderBy><FieldRef Name='Modified' Ascending='FALSE' /></OrderBy>";
                        SPListItemCollection oitems = lstWorkshopRequestsDocs.GetItems(qry);
                        foreach (SPListItem item in oitems)
                        {
                            SPFile file = item.File;
                            string path = file.Url.ToString();

                            if (file != null)
                            {
                                byte[] bytes = file.OpenBinary();
                                byte[] fileData = bytes;

                                Page.Response.Clear();
                                Page.Response.Buffer = true;
                                Page.Response.ClearHeaders();

                                string fileName = item.File.Name;
                                Page.Response.ContentType = GetMIMEType(fileName);

                                String userAgent = Page.Request.Headers.Get("User-Agent");
                                if (userAgent.Contains("MSIE 7.0"))
                                {
                                    fileName = fileName.Replace(" ", "%20");
                                }
                                Page.Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);

                                Page.Response.OutputStream.Write(fileData, 0, fileData.Length);
                                Page.Response.Flush();
                                Page.Response.End();
                                
                                break;
                            }

                        }
                        


                    }


                }


            }
            catch (Exception ex)
            {

                throw;
            }

        }

        public static String GetMIMEType(String filepath)
        {
            System.Security.Permissions.RegistryPermission regPerm =
                new System.Security.Permissions.RegistryPermission(System.Security.Permissions.RegistryPermissionAccess.Read, "\\HKEY_CLASSES_ROOT");
            Microsoft.Win32.RegistryKey classesRoot = Microsoft.Win32.Registry.ClassesRoot;
            System.IO.FileInfo fi = new System.IO.FileInfo(filepath);

            string dotExt = fi.Extension.ToLower();
            Microsoft.Win32.RegistryKey typeKey = classesRoot.OpenSubKey("MIME\\Database\\Content Type");
            foreach (string keyname in typeKey.GetSubKeyNames())
            {
                Microsoft.Win32.RegistryKey curKey = classesRoot.OpenSubKey("MIME\\Database\\Content Type\\" + keyname);

                if (curKey.GetValue("Extension") != null && curKey.GetValue("Extension").ToString().ToLower() == dotExt)
                {
                    return keyname;
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".docx")
                {
                    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".xlsx")
                {
                    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }
                if (curKey.GetValue("Extension") != null && dotExt == ".zip")
                {
                    return "application/octet-stream";
                }

            }
            return string.Empty;
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Pages/Confrence_Workshop/Summary.aspx");
        }

        
    }
}
