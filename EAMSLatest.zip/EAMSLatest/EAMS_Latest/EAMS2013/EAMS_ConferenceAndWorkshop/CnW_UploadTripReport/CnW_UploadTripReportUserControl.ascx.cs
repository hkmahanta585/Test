﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;

namespace EAMS_ConferenceAndWorkshop.CnW_UploadTripReport
{
    public partial class CnW_UploadTripReportUserControl : UserControl
    {
        string siteURL = SPContext.Current.Web.Url.ToString();
        Workshop _ws;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                populateRequestID();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            _ws = new Workshop();
            try
            {
                using (SPSite osite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = osite.OpenWeb())
                    {
                        SPList lstExtUploadDocs = oWeb.Lists.TryGetList("WorkshopDocs");

                        byte[] contentByteArray;
                        string newfile = string.Empty;
                        string fileName = string.Empty;
                        bool overwrite = true;

                        #region------uploding file------------------
                        if (fldFileUpload.HasFile)
                        {
                            contentByteArray = new byte[fldFileUpload.PostedFile.ContentLength];
                            newfile = fldFileUpload.PostedFile.FileName;
                            fileName = ddlRequestID.SelectedItem.Text.Trim() + "_" + fldFileUpload.FileName;
                            fldFileUpload.PostedFile.InputStream.Read(contentByteArray, 0, fldFileUpload.PostedFile.ContentLength - 1);
                            SPFile file = null;
                            file = lstExtUploadDocs.RootFolder.Files.Add(fileName, contentByteArray, overwrite);
                            file.Update();

                            SPListItem fileItem = file.Item;

                            fileItem["RequestID"] = ddlRequestID.SelectedItem.Text;
                            string confID = _ws.getColumnValue("WorkshopRequests", new KeyValuePair<string, string>("RequestID", ddlRequestID.SelectedItem.Text), "WorkshopRefID_x003a_WorkshopID");
                            confID = confID.Split('#')[1];
                            fileItem["ConfID"] = confID;

                            #region ---------Getting Location,Duration...----------

                            SPList lstCnW = oWeb.Lists.TryGetList("Conference & Workshop");
                            SPQuery qry = new SPQuery();
                            qry.Query = @"<Where><Eq>
                                                    <FieldRef Name='WorkshopID' />
                                                    <Value Type='Text'>" + confID + @"</Value>
                                                </Eq></Where>";
                            SPListItemCollection lstItemCol = lstCnW.GetItems(qry);
                            if (lstItemCol.Count > 0)
                            {
                                fileItem["Location"] = Convert.ToString(lstItemCol[0]["Location"]);
                                fileItem["Duration"] = Convert.ToString(lstItemCol[0]["Duration"]);
                                fileItem["StartDate"] = Convert.ToString(lstItemCol[0]["WStartDate"]);
                                fileItem["EndDate"] = Convert.ToString(lstItemCol[0]["WEndDate"]);
                                fileItem["EventName"] = Convert.ToString(lstItemCol[0]["Title"]);
                            }
                            #endregion

                            #region ---------Getting Approver Details-------------

                            SPList lstWR = oWeb.Lists.TryGetList("WorkshopRequests");
                            SPQuery qryWR = new SPQuery();
                            qryWR.Query = @"<Where><Eq>
                                                    <FieldRef Name='RequestID' />
                                                    <Value Type='Text'>" + ddlRequestID.SelectedItem.Text + @"</Value>
                                                </Eq></Where>";
                            SPListItemCollection lstItemColWR = lstWR.GetItems(qryWR);
                            if (lstItemColWR.Count > 0)
                            {
                                fileItem.Fields["Manager"].ReadOnlyField = false;
                                fileItem["Manager"] = new SPFieldUserValue(oWeb, Convert.ToString(lstItemColWR[0]["Manager"]));
                                fileItem.Fields["COEHead"].ReadOnlyField = false;
                                fileItem["COEHead"] = new SPFieldUserValue(oWeb, Convert.ToString(lstItemColWR[0]["COEHead"]));
                                fileItem.Fields["PlanningHead"].ReadOnlyField = false;
                                fileItem["PlanningHead"] = new SPFieldUserValue(oWeb, Convert.ToString(lstItemColWR[0]["PlanningHead"]));
                                fileItem.Fields["SiteHead"].ReadOnlyField = false;
                                fileItem["SiteHead"] = new SPFieldUserValue(oWeb, Convert.ToString(lstItemColWR[0]["HOD"]));
                                fileItem.Fields["SitePresident"].ReadOnlyField = false;
                                fileItem["SitePresident"] = new SPFieldUserValue(oWeb, Convert.ToString(lstItemColWR[0]["SitePresident"]));
                                fileItem.Fields["SegHead"].ReadOnlyField = false;
                                fileItem["SegHead"] = new SPFieldUserValue(oWeb, Convert.ToString(lstItemColWR[0]["RNDHead"]));
                                fileItem["EmpCode"] = Convert.ToString(lstItemColWR[0]["EmpCode"]);
                            }

                            #endregion

                            fileItem["EmpName"] = oWeb.CurrentUser.Name;
                            fileItem["Requstor"] = oWeb.EnsureUser(oWeb.CurrentUser.Name);
                            fileItem["DelFlag"] = "0";
                            fileItem["Status"] = "Close";
                            fileItem["UpldComments"] = txtComments.Text;
                            fileItem["UpldDate"] = DateTime.Now.ToString("dd-MMM-yyyy");
                            fileItem.Update();
                            _ws.LogError("File Uploaded Successfully", "File Uploaded Successfully");
                            Page.Response.Redirect("/Pages/Confrence_Workshop/TripReport.aspx", true);

                        }
                        #endregion
                    }
                }
            }

            catch (SPException ex)
            {
                _ws.LogError("Error on btnSubmit_Click()", ex.Message);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect("/Pages/Confrence_Workshop/TripReport.aspx", true);
        }
        protected void ddlRequestID_SelectedIndexChanged(object sender, EventArgs e)
        {
            //DataTable dt = ViewState["MNP"] as DataTable;
            try
            {

                using (SPSite osite = new SPSite(siteURL))
                {
                    using (SPWeb oweb = osite.OpenWeb())
                    {
                        SPList lstWorkshopRequets = oweb.Lists.TryGetList("WorkshopRequests");
                        SPListItem lstItem = lstWorkshopRequets.GetItemById(Convert.ToInt32(ddlRequestID.SelectedItem.Value));
                        lblTitle1.Text = lstItem["WorkshopRefID_x003a_EventName"].ToString().Split('#')[1];
                        lblStatus.Text = lstItem["ReqStatus"].ToString();
                    }
                }
            }
            catch(SPException ex)
            {
                _ws.LogError("ddlRequestID_SelectedIndexChanged", ex.Message);
            }

            
        }
        private void populateRequestID()
        {
            try
            {
                 
                using (SPSite osite = new SPSite(siteURL))
                {
                    using (SPWeb oweb = osite.OpenWeb())
                    {
                        string strLoggedInUser = Convert.ToString(oweb.CurrentUser.Name);
                        SPList spList = oweb.Lists.TryGetList("WorkshopRequests");
                        SPQuery qry = new SPQuery();
                        qry.Query = @"<Where>
                                          <And>
                                             <Or>
                                                <Eq>
                                                   <FieldRef Name='RStatus' />
                                                   <Value Type='Text'>Open</Value>
                                                </Eq>
                                                <Eq>
                                                   <FieldRef Name='RStatus' />
                                                   <Value Type='Text'>Completed</Value>
                                                </Eq>
                                             </Or>
                                             <Eq>
                                                <FieldRef Name='Requestor' />
                                                <Value Type='User'>"+ strLoggedInUser +@"</Value>
                                             </Eq>
                                          </And>
                                       </Where>"; 
                        SPListItemCollection oItems = spList.GetItems(qry);
                        if (oItems.Count > 0)
                        {
                            //ViewState["MNP"] = oItems.GetDataTable();
                            ddlRequestID.DataSource = oItems.GetDataTable();
                            ddlRequestID.DataTextField = "RequestID";
                            ddlRequestID.DataValueField = "ID";
                            ddlRequestID.DataBind();
                            ddlRequestID.Items.Insert(0, "--Select--");
                        }
                        else
                        {
                            ddlRequestID.Items.Insert(0, "--Select--");
                            lblMessage.Text = "You don't have RequestID.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on populateRequestID()", ex.Message);
            }
        }


        public string getColumnValue(string _givelistName, KeyValuePair<string, string> filter, string returnColumn)
        {
            string value = string.Empty;
            try
            {
                using (SPSite osite = new SPSite(siteURL))
                {
                    using (SPWeb oWeb = osite.OpenWeb())
                    {

                        SPList lst = oWeb.Lists.TryGetList(_givelistName);
                        SPQuery caml = new SPQuery();
                        caml.ViewXml = "<View>" +
                                            "<Query>" +
                                                "<Where>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name =" + filter.Key + "/>" +
                                                        "<Value Type = 'Text'>" + filter.Value + "</Value>" +
                                                    "</Eq>" +
                                                "</Where>" +
                                             "</Query>" +
                                          "</View>";
                        SPListItemCollection lstItemCol = lst.GetItems(caml);

                        value = Convert.ToString(lstItemCol[0][returnColumn]);
                    }
                }
            }
            catch (Exception ex)
            {
                _ws.LogError("Error on getColumnValue()", ex.Message);
                value = string.Empty;
            }
            return value;
        }


    }
}
