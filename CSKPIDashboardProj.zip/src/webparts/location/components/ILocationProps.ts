import {ILocationDataProvider} from '../service/DataProvider/ILocationDataProvider';
export interface ILocationProps {
  description: string; 
  dataprovider:ILocationDataProvider;
  
}
