export interface ILocation{
    Title:string;
}