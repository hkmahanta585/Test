declare interface ILocationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'LocationWebPartStrings' {
  const strings: ILocationWebPartStrings;
  export = strings;
}
