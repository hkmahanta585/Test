export interface IItemOperationarea {
    ID: number;
    Title: string;
    Sequence: any;
  }