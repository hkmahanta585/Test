import { IOperationDataProvider } from '../service/DataProvider/IOperationDataProvider';
export interface IOperationAreaProps {
  description: string;
  dataprovider:IOperationDataProvider;
}
