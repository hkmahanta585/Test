declare interface IOperationAreaWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'OperationAreaWebPartStrings' {
  const strings: IOperationAreaWebPartStrings;
  export = strings;
}
