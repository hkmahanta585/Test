export interface IIteamKPI {
    KPIID:number;
    Title:string;
    Metric:string;
    Sequence:any;
    OperationAreaTitle:string;
    OperationAreaID:number;
    KPITargetConfig:string;
    Target:string;
    KPIMatrixID:number;
}
/*
export interface IOperationArea{
    ID:number;
    Title:string;
}
*/ 
