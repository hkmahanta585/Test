declare interface IKpiMetricsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'KpiMetricsWebPartStrings' {
  const strings: IKpiMetricsWebPartStrings;
  export = strings;
}
