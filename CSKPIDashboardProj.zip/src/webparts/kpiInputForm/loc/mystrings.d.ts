declare interface IKpiInputFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'KpiInputFormWebPartStrings' {
  const strings: IKpiInputFormWebPartStrings;
  export = strings;
}
