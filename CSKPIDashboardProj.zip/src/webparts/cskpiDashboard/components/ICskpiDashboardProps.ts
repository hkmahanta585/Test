export interface ICskpiDashboardProps {
  description: string;
}
