declare interface ICskpiDashboardWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CskpiDashboardWebPartStrings' {
  const strings: ICskpiDashboardWebPartStrings;
  export = strings;
}
